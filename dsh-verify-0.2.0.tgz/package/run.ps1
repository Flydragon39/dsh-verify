<#
.SYNOPSIS
  dsh-verify one-click launcher (PowerShell).

.DESCRIPTION
  The same convenience surface as run.cmd, for PowerShell users. It finds its
  own tool root from its own location, locates a Node runtime (DSH_NODE, then
  PATH, then the runtime DSH ships), and hands every argument to the launcher.

  This is an EXTERNAL tool: it is not a DSH plugin and not an agent preset.
  DSH never loads it, and it never modifies your DSH configuration.

.EXAMPLE
  .\run.ps1
  .\run.ps1 quick --probe
  .\run.ps1 doctor
  .\run.ps1 --profile desktop --format markdown --output report.md

.NOTES
  If PowerShell refuses to run this file, either unblock it once:
      Unblock-File .\run.ps1
  or run it with the execution policy bypassed for this call only:
      powershell -ExecutionPolicy Bypass -File .\run.ps1
#>
[CmdletBinding()]
param(
  [Parameter(ValueFromRemainingArguments = $true)]
  [string[]] $Arguments
)

$ErrorActionPreference = 'Stop'

# Tool root is this script's directory, so the checkout works wherever it sits.
$ToolRoot = $PSScriptRoot
$Launcher = Join-Path $ToolRoot 'bin\dsh-verify-launcher.mjs'

function Resolve-NodeRuntime {
  if ($env:DSH_NODE -and (Test-Path -LiteralPath $env:DSH_NODE)) {
    return @{ Path = $env:DSH_NODE; Source = 'DSH_NODE' }
  }

  $onPath = Get-Command node -ErrorAction SilentlyContinue
  if ($onPath) { return @{ Path = $onPath.Source; Source = 'PATH' } }

  # DSH ships its own Node runtime; use it when PATH has none.
  $bundled = Join-Path $env:USERPROFILE '.dsh\dsh-runtimes\dsh-primary-runtime\dependencies\node\bin\node.exe'
  if (Test-Path -LiteralPath $bundled) { return @{ Path = $bundled; Source = 'bundled runtime' } }

  return $null
}

if (-not (Test-Path -LiteralPath $Launcher)) {
  Write-Host ''
  Write-Host '  dsh-verify: launcher payload is missing.' -ForegroundColor Red
  Write-Host "  Expected: $Launcher"
  Write-Host '  The checkout looks incomplete; re-copy the tool folder.'
  Write-Host ''
  exit 2
}

$node = Resolve-NodeRuntime
if (-not $node) {
  Write-Host ''
  Write-Host '  dsh-verify: no Node.js runtime found.' -ForegroundColor Red
  Write-Host ''
  Write-Host '  Checked: $env:DSH_NODE, then "node" on PATH, then the runtime DSH'
  Write-Host "           ships at $env:USERPROFILE\.dsh\dsh-runtimes\...\node\bin\node.exe"
  Write-Host ''
  Write-Host '  Install Node 18+ from https://nodejs.org, or set $env:DSH_NODE to a'
  Write-Host '  node.exe, then run this file again.'
  Write-Host ''
  exit 2
}

Write-Verbose "using node from $($node.Source): $($node.Path)"

# Open the interactive menu only for a bare invocation, which is what a
# double-click produces. A leading flag (`--help`, `--version`, ...) is not a
# request for the menu — it belongs to the verifier and is passed straight
# through, matching how bin/dsh-verify-launcher.mjs classifies its arguments.
$argList = @()
if ($Arguments) { $argList = @($Arguments) }
$openInteractiveMenu = ($argList.Count -eq 0)
if ($openInteractiveMenu) { $argList = @('menu') }

& $node.Path $Launcher @argList
$code = $LASTEXITCODE

# Keep the window open when this was launched by a double-click, which passes
# no arguments. An explicit command means a real shell, so never pause there.
if (-not $env:DSH_VERIFY_NO_PAUSE -and $openInteractiveMenu -and $Host.Name -eq 'ConsoleHost') {
  Write-Host ''
  Write-Host '  Press Enter to close...' -NoNewline
  [void] (Read-Host)
}

exit $code
