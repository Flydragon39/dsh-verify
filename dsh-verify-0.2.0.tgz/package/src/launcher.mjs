/**
 * Zero-configuration launcher for `dsh-verify`.
 *
 * This module exists so the tool is usable without remembering a path, a Node
 * runtime, or a flag set. It is a *convenience surface only*: it never changes
 * what verification means, and it never writes anything except the report files
 * the underlying CLI already writes.
 *
 * Two design constraints, both inherited from the tool's own plan:
 *
 * 1. **It must not become a DSH plugin or mode.** Nothing in this file
 *    registers with a Cordis composition, imports `@deepseek-ai/*`, or is
 *    referenced from any `cordis.patch.yml` or agent preset. `dsh` is never
 *    asked to load `dsh-verify`. The dependency arrow points outwards: this
 *    tool observes DSH, DSH knows nothing about this tool. A verifier that
 *    could be broken by the same update it is meant to detect would be useless,
 *    which is why the plan's first hard constraint is independence.
 *
 * 2. **It must not need a PATH entry or a global install.** The `run.cmd` /
 *    `run.ps1` shims beside this file find their own tool root from their own
 *    location, so the checkout is already "installed" wherever it sits. The
 *    optional `install-path` command only adds a convenience shim to a
 *    directory the user already has on PATH; it is never required.
 *
 * @module dsh-verify/launcher
 */

import { spawnSync } from 'node:child_process';
import { existsSync, mkdirSync, rmSync, writeFileSync, openSync, closeSync, readFileSync } from 'node:fs';
import { dirname, join, resolve } from 'node:path';
import { fileURLToPath } from 'node:url';
import { homedir, tmpdir } from 'node:os';

import { resolveDshHome, locateInstall } from './paths.mjs';
import { listProfiles, pickProfile, TOOL } from './verify.mjs';
import { readJsonOrNull, shortPath } from './fsutil.mjs';

const HERE = dirname(fileURLToPath(import.meta.url));
/** The tool root: the directory containing `bin/`, `src/` and this file's parent. */
export const TOOL_ROOT = resolve(HERE, '..');
const CLI = join(TOOL_ROOT, 'bin', 'dsh-verify.mjs');

/** Minimum Node major this tool runs on, from package.json's `engines`. */
const MIN_NODE_MAJOR = 18;

/** Locations worth checking when `node` is not on PATH. */
const NODE_FALLBACKS = [
  join(homedir(), '.dsh', 'dsh-runtimes', 'dsh-primary-runtime', 'dependencies', 'node', 'bin', 'node.exe'),
  join(homedir(), '.dsh', 'dsh-runtimes', 'dsh-primary-runtime', 'dependencies', 'node', 'bin', 'node'),
  'C:\\Program Files\\nodejs\\node.exe',
];

// ── Console helpers ─────────────────────────────────────────────────────────

const useColor = process.stdout.isTTY === true && process.env.NO_COLOR === undefined;
const paint = (code, text) => (useColor ? `\u001b[${code}m${text}\u001b[0m` : text);
const bold = (text) => paint('1', text);
const dim = (text) => paint('2', text);
const green = (text) => paint('32', text);
const yellow = (text) => paint('33', text);
const red = (text) => paint('31', text);
const cyan = (text) => paint('36', text);

/** True when this process is running on Windows. */
export const isWindows = process.platform === 'win32';

// ── Node resolution ─────────────────────────────────────────────────────────

/**
 * Run a command and capture its stdout synchronously.
 *
 * Some confined sandboxes refuse to hand a child a pipe (`EPERM` on the spawn)
 * while a real file descriptor is still allowed. Without a fallback every probe
 * below would report "not found" on exactly the machines this tool is meant to
 * diagnose, which would be a false report rather than a failed check. The first
 * attempt uses pipes as usual; only when the spawn itself fails does this
 * redirect the child into a temporary file and read it back.
 *
 * @param {string} command
 * @param {string[]} args
 * @returns {{ status: number|null, stdout: string, stderr: string, error: string|null }}
 */
function runCaptureSync(command, args) {
  const direct = spawnSync(command, args, { encoding: 'utf8', windowsHide: true });
  if (!direct.error) return { status: direct.status, stdout: direct.stdout ?? '', stderr: direct.stderr ?? '', error: null };

  const capture = join(tmpdir(), `dsh-verify-probe-${process.pid}-${Date.now().toString(36)}.txt`);
  let fd;
  try {
    fd = openSync(capture, 'w');
    const redirected = spawnSync(command, args, { windowsHide: true, stdio: ['ignore', fd, fd] });
    if (redirected.error) return { status: null, stdout: '', stderr: '', error: redirected.error.message };
    let text = '';
    try { text = readFileSync(capture, 'utf8'); } catch { text = ''; }
    // stdout and stderr share the file: the last of the two is what the probes
    // read anyway, and every caller here only consumes stdout.
    return { status: redirected.status, stdout: text, stderr: '', error: null };
  } catch (error) {
    return { status: null, stdout: '', stderr: '', error: error.message };
  } finally {
    if (fd !== undefined) { try { closeSync(fd); } catch { /* already closed */ } }
    try { rmSync(capture, { force: true }); } catch { /* best effort */ }
  }
}

/**
 * Find a Node executable able to run the tool.
 *
 * A `.cmd` shim that assumes `node` is on PATH fails on exactly the machines
 * least likely to have it. DSH ships its own Node runtime, so that is checked
 * before giving up.
 *
 * @returns {{ path: string, source: string, version: string|null }}
 */
export function findNode() {
  const candidates = [];
  if (process.env.DSH_NODE) candidates.push({ path: process.env.DSH_NODE, source: 'DSH_NODE' });
  // `process.execPath` is the runtime already running this file: by definition
  // it works. It is last only so an explicit DSH_NODE still wins.
  for (const path of NODE_FALLBACKS) candidates.push({ path, source: 'bundled runtime' });
  candidates.push({ path: process.execPath, source: 'this process' });

  for (const candidate of candidates) {
    if (!candidate.path) continue;
    if (!existsSync(candidate.path)) continue;
    const probe = runCaptureSync(candidate.path, ['--version']);
    if (probe.status === 0) {
      return { path: candidate.path, source: candidate.source, version: probe.stdout.trim() };
    }
  }
  return { path: null, source: null, version: null };
}

// ── Environment inspection ──────────────────────────────────────────────────

/**
 * Inspect everything the tool needs, without verifying anything.
 *
 * This is the "did I set this up right?" answer: harness home, installation,
 * profiles, presets directory, Node runtime. It is intentionally the same
 * environment guard `verify()` applies, surfaced before a run rather than
 * inside one.
 *
 * @param {{ dshHome?: string, install?: string }} [options]
 * @returns {object}
 */
export function inspectEnvironment(options = {}) {
  const home = resolveDshHome(options.dshHome);
  const install = locateInstall(home.exists ? home.path : '', options.install);
  const profiles = home.exists ? listProfiles(home.path) : [];
  const chosen = options.profile
    ? { profile: options.profile, source: 'requested' }
    : pickProfile(home.exists ? home.path : '');

  const userPresetDir = home.exists ? join(home.path, '.agent-presets') : '';
  const settingsPath = home.exists ? join(home.path, 'settings.yaml') : '';

  return {
    node: findNode(),
    toolRoot: TOOL_ROOT,
    toolVersion: TOOL.version,
    dshHome: { path: home.path, source: home.source, exists: home.exists },
    install: {
      found: install.found,
      anchor: install.anchor,
      version: install.version,
      candidates: install.candidates ?? [],
    },
    profiles,
    chosen,
    userPresetDir: userPresetDir ? { path: userPresetDir, exists: existsSync(userPresetDir) } : null,
    settings: settingsPath ? { path: settingsPath, exists: existsSync(settingsPath) } : null,
    dshOnPath: whichDsh(),
  };
}

/** Locate a `dsh` executable on PATH, for the version probe only. */
function whichDsh() {
  const probe = runCaptureSync(isWindows ? 'where' : 'which', ['dsh']);
  if (probe.status !== 0) return null;
  const first = probe.stdout.split(/\r?\n/).map((s) => s.trim()).filter(Boolean)[0];
  return first ?? null;
}

// ── Commands ────────────────────────────────────────────────────────────────

/** `doctor`: print the environment guard's findings and a verdict. */
export function commandDoctor(options = {}, out = process.stdout) {
  const env = inspectEnvironment(options);
  const style = options.pretty !== false;
  const line = (label, value, note) => {
    const pad = label.padEnd(16);
    const suffix = note ? `  ${style ? dim(note) : note}` : '';
    out.write(`  ${style ? bold(pad) : pad} ${value}${suffix}\n`);
  };

  out.write(`\n${style ? bold(`${TOOL.name} ${TOOL.version}`) : TOOL.name} — environment readiness\n\n`);

  const nodeOk = env.node.version !== null && Number(env.node.version.replace(/^v/, '').split('.')[0]) >= MIN_NODE_MAJOR;
  line('Node', env.node.version ?? 'NOT FOUND', nodeOk ? `(${env.node.source})` : 'need >= 18');
  line('Tool root', shortPath(env.toolRoot));
  line('Harness home', env.dshHome.exists ? shortPath(env.dshHome.path) : 'NOT FOUND', env.dshHome.exists ? `(${env.dshHome.source})` : 'set DSH_HOME or pass --dsh-home');
  line(
    'DSH install',
    env.install.found ? env.install.version || '(version unreadable)' : 'NOT FOUND',
    env.install.found ? shortPath(env.install.anchor) : 'pass --install',
  );

  const profilesText = env.profiles.length === 0
    ? (style ? yellow('(none)') : '(none)')
    : env.profiles.join(', ');
  line('Profiles', profilesText, `default: ${env.chosen.profile} (${env.chosen.source})`);

  line('User presets', env.userPresetDir && env.userPresetDir.exists ? shortPath(env.userPresetDir.path) : '(none)', 'legacy < 0.2.0 only');
  line('dsh on PATH', env.dshOnPath ? shortPath(env.dshOnPath) : '(none)', 'only used by --version-probe');

  // The readiness verdict: exactly the two conditions that block a run.
  const blockers = [];
  if (!nodeOk) blockers.push('no usable Node >= 18');
  if (!env.dshHome.exists) blockers.push('harness home not found');
  if (!env.install.found) blockers.push('DSH installation not found');
  if (env.profiles.length === 0) blockers.push('no profile directory to verify');

  out.write('\n');
  if (blockers.length === 0) {
    out.write(`  ${style ? green('READY') : 'READY'} — run ${style ? cyan('dsh-verify quick') : 'dsh-verify quick'} (or ${style ? cyan('run.cmd') : 'run.cmd'}) for a first check.\n`);
  } else {
    out.write(`  ${style ? red('NOT READY') : 'NOT READY'} — ${blockers.join('; ')}\n`);
    out.write(`  ${style ? dim('Nothing was verified. Fix the above and re-run doctor.') : 'Nothing was verified.'}\n`);
  }
  if (env.profiles.length > 1) {
    out.write(`  ${style ? dim(`More than one profile exists; pick one with --profile. Available: ${env.profiles.join(', ')}`) : ''}\n`);
  }
  out.write('\n');
  return blockers.length === 0 ? 0 : 2;
}

/** `menu`: an interactive picker, for double-clicking `run.cmd`. */
export async function commandMenu(input = {}, out = process.stdout, ask = null) {
  const env = inspectEnvironment(input);
  out.write(`\n${bold(`${TOOL.name} ${TOOL.version}`)} — ${env.dshHome.exists ? shortPath(env.dshHome.path) : 'no harness home'}`);
  out.write(env.install.found ? ` · DSH ${env.install.version || '?'}\n\n` : '\n\n');

  if (env.profiles.length === 0) {
    out.write(`${red('No profile found.')} Nothing can be verified yet.\n\n`);
    return commandDoctor(input, out);
  }

  const actions = [
    {
      key: '1', label: '快速校验 (static)',
      detail: 'compose the tree, check contracts and bindings; no subprocesses',
      run: () => runCli(['--profile', env.chosen.profile]),
    },
    {
      key: '2', label: '完整校验 (--probe)',
      detail: 'also import every plugin in an isolated process',
      run: () => runCli(['--profile', env.chosen.profile, '--probe']),
    },
    {
      key: '3', label: '仅模式校验 (--modes-only)',
      detail: 'agent-preset modes only',
      run: () => runCli(['--profile', env.chosen.profile, '--modes-only']),
    },
    {
      key: '4', label: '保存基线 (baseline save)',
      detail: 'snapshot now, diff after the next DSH update',
      run: () => runCli(['baseline', 'save', '--profile', env.chosen.profile, '--output', join('.dsh-verify', 'baseline.json')]),
    },
    {
      key: '5', label: '与基线对比 (baseline diff)',
      detail: 'what changed since the snapshot',
      run: () => runCli(['--profile', env.chosen.profile, '--baseline', join('.dsh-verify', 'baseline.json')]),
    },
    {
      key: '6', label: '环境自检 (doctor)',
      detail: 'paths, versions, profiles',
      run: () => commandDoctor(input, out),
    },
    {
      key: '7', label: '生成 Markdown 报告',
      detail: 'writes report.md next to the tool',
      run: () => runCli(['--profile', env.chosen.profile, '--probe', '--format', 'markdown', '--output', join(TOOL_ROOT, 'report.md')]),
    },
  ];

  for (const action of actions) out.write(`  ${bold(action.key)}) ${action.label}  ${dim(action.detail)}\n`);
  out.write(`  ${bold('q')}) 退出\n\n`);
  out.write(`  ${dim(`profile: ${env.chosen.profile}${env.profiles.length > 1 ? ` (of ${env.profiles.join(', ')})` : ''}`)}\n`);
  out.write(`  ${dim(`plugin scope: the rows you installed; add --all for the platform's own`)}\n\n`);

  const question = ask ?? defaultAsk;
  const answer = (await question('选择 [1-7, q]: ')).trim().toLowerCase();
  if (answer === 'q' || answer === '') return 0;

  const action = actions.find((a) => a.key === answer);
  if (!action) {
    out.write(`${yellow(`Unrecognised choice ${JSON.stringify(answer)}.`)}\n`);
    return 2;
  }
  return action.run();
}

/** Read one line from stdin without pulling in a dependency. */
function defaultAsk(prompt) {
  return new Promise((resolvePromise) => {
    process.stdout.write(prompt);
    process.stdin.setEncoding('utf8');
    process.stdin.once('data', (chunk) => resolvePromise(String(chunk)));
  });
}

/**
 * Run the underlying CLI in this process.
 *
 * In-process rather than `spawn`, so the exit code and the stdio plumbing are
 * exactly the ones the direct CLI produces — a launcher that could disagree
 * with the real tool would be worse than no launcher.
 */
export async function runCli(argv, out = process.stdout) {
  const { main } = await import('./cli.mjs');
  void out;
  return main(argv);
}

/** `quick`: the one-command path, with auto-detected profile. */
export async function commandQuick(argv, out = process.stdout) {
  const env = inspectEnvironment();
  if (!env.dshHome.exists || !env.install.found || env.profiles.length === 0) {
    out.write(`${red('Environment is not ready; nothing was verified.')}\n`);
    return commandDoctor({}, out);
  }
  if (!argv.includes('--profile')) argv = ['--profile', env.chosen.profile, ...argv];
  out.write(`${dim(`profile: ${env.chosen.profile} · DSH ${env.install.version || '?'} · ${shortPath(env.dshHome.path)}`)}\n`);
  return runCli(argv, out);
}

// ── Self test ───────────────────────────────────────────────────────────────

/** `self-test`: prove the entry points and modules are wired correctly. */
export async function commandSelfTest(out = process.stdout) {
  const results = [];
  const check = (name, fn) => {
    try {
      const detail = fn();
      results.push({ name, ok: detail !== false, detail: detail === true || detail === undefined ? '' : String(detail) });
    } catch (error) {
      results.push({ name, ok: false, detail: error.message });
    }
  };

  check('tool root resolves', () => (existsSync(CLI) ? `${shortPath(CLI)}` : false));
  check('node >= 18', () => {
    const node = findNode();
    if (!node.version) return false;
    const major = Number(node.version.replace(/^v/, '').split('.')[0]);
    return major >= MIN_NODE_MAJOR ? `${node.version} (${node.source})` : false;
  });
  check('CLI --version', () => {
    const r = runCaptureSync(process.execPath, [CLI, '--version']);
    return r.status === 0 ? r.stdout.trim() : false;
  });
  check('CLI --help', () => {
    const r = runCaptureSync(process.execPath, [CLI, '--help']);
    return r.status === 0 && r.stdout.includes('dsh-verify') ? 'usage printed' : false;
  });
  check('prompt subcommand', () => {
    const r = runCaptureSync(process.execPath, [CLI, 'prompt']);
    return r.status === 0 && r.stdout.length > 500 ? `${r.stdout.length} bytes` : false;
  });
  check('harness home readable', () => {
    const env = inspectEnvironment();
    return env.dshHome.exists ? shortPath(env.dshHome.path) : 'not found (doctor will explain)';
  });
  check('package.json engines honoured', () => {
    const pkg = readJsonOrNull(join(TOOL_ROOT, 'package.json'));
    return pkg?.bin?.['dsh-verify'] ? 'bin declared' : false;
  });
  check('no DSH plugin surface', () => {
    // The independence guarantee, asserted rather than asserted-in-prose: the
    // manifest must declare no Cordis/DSH entry point at all.
    const pkg = readJsonOrNull(join(TOOL_ROOT, 'package.json'));
    const offenders = [];
    if (pkg?.dsh !== undefined) offenders.push('"dsh" key');
    if (pkg?.cordis !== undefined) offenders.push('"cordis" key');
    if (pkg?.main && /cordis/i.test(String(pkg.main))) offenders.push('cordis main');
    for (const file of ['cordis.patch.yml', 'agent.cordis.yml', 'preset.yml']) {
      if (existsSync(join(TOOL_ROOT, file))) offenders.push(file);
    }
    return offenders.length === 0 ? 'no dsh/cordis manifest keys, no composition files' : `FOUND: ${offenders.join(', ')}`;
  });

  out.write(`\n${bold(`${TOOL.name} self-test`)}\n\n`);
  let failed = 0;
  for (const r of results) {
    if (!r.ok) failed += 1;
    out.write(`  ${r.ok ? green('ok  ') : red('FAIL')}  ${r.name.padEnd(30)} ${dim(r.detail)}\n`);
  }
  out.write(`\n  ${failed === 0 ? green('all checks passed') : red(`${failed} check(s) failed`)}\n\n`);
  return failed === 0 ? 0 : 1;
}

// ── PATH helper (optional, never required) ──────────────────────────────────

/**
 * Install a `dsh-verify` shim into a directory that is already on PATH.
 *
 * This is the only command in the launcher that writes outside the tool's own
 * report files, so it refuses to run without an explicit `--dir`, prints the
 * exact path it will touch, and supports `--remove` to undo it.
 *
 * @returns {number} exit code.
 */
export function commandInstallPath(options = {}, out = process.stdout) {
  const dir = options.dir ? resolve(options.dir) : null;

  if (options.remove) {
    const targets = [join(options.dir ?? TOOL_ROOT, 'dsh-verify.cmd'), join(options.dir ?? TOOL_ROOT, 'dsh-verify')];
    let removed = 0;
    for (const target of targets) {
      if (target.startsWith(TOOL_ROOT)) continue;
      if (existsSync(target)) { rmSync(target, { force: true }); removed += 1; out.write(`  removed ${shortPath(target)}\n`); }
    }
    out.write(removed === 0 ? '  nothing to remove\n' : `  ${removed} shim(s) removed\n`);
    return 0;
  }

  if (!dir) {
    out.write(`\n${bold('install-path')} needs an explicit destination, because it writes a file.\n\n`);
    out.write(`  ${bold('Recommended')} — use the shims that already ship with the tool:\n`);
    out.write(`    ${cyan(shortPath(join(TOOL_ROOT, 'run.cmd')))}                ${dim('# double-click or run from anywhere')}\n`);
    out.write(`    ${cyan(`"${join(TOOL_ROOT, 'run.cmd')}" doctor`)}   ${dim('# any CLI argument is passed through')}\n\n`);
    out.write(`  ${bold('Optional')} — put a shim on PATH so the bare name works:\n`);
    out.write(`    ${cyan('dsh-verify-launcher install-path --dir <a directory already on PATH>')}\n`);
    out.write(`    ${dim('e.g. a directory listed in PATH, such as ~/bin or %LOCALAPPDATA%\\Microsoft\\WindowsApps')}\n\n`);
    out.write(`  ${bold('Remove it again')}:\n`);
    out.write(`    ${cyan('dsh-verify-launcher install-path --dir <same directory> --remove')}\n\n`);
    return 2;
  }

  if (!existsSync(dir)) {
    try {
      mkdirSync(dir, { recursive: true });
    } catch (error) {
      out.write(`  ${red('cannot create')} ${shortPath(dir)}: ${error.message}\n`);
      return 2;
    }
  }

  const written = [];
  if (isWindows) {
    const shim = join(dir, 'dsh-verify.cmd');
    writeFileSync(shim, cmdShim(), 'utf8');
    written.push(shim);
  }
  const posix = join(dir, 'dsh-verify');
  writeFileSync(posix, posixShim(), { encoding: 'utf8', mode: 0o755 });
  written.push(posix);

  for (const path of written) out.write(`  wrote ${shortPath(path)}\n`);
  out.write(`\n  ${green('done')} — run ${cyan('dsh-verify --help')} in a new shell.\n`);
  out.write(`  ${dim('The shim calls this checkout in place; nothing was installed globally.')}\n\n`);
  return 0;
}

/** A `.cmd` shim that defers to `run.cmd` in the tool root. */
function cmdShim() {
  return [
    '@echo off',
    'rem Generated by dsh-verify-launcher install-path. Safe to delete.',
    `call "${join(TOOL_ROOT, 'run.cmd')}" %*`,
    'exit /b %ERRORLEVEL%',
    '',
  ].join('\r\n');
}

/** A POSIX shim that defers to `run.ps1`-equivalent Node entry. */
function posixShim() {
  return [
    '#!/bin/sh',
    '# Generated by dsh-verify-launcher install-path. Safe to delete.',
    `exec "${process.execPath}" "${CLI}" "$@"`,
    '',
  ].join('\n');
}

// ── CLI parsing ─────────────────────────────────────────────────────────────

const LAUNCHER_USAGE = `dsh-verify launcher — quick-run surface

Usage
  dsh-verify-launcher <command> [options]

Commands
  quick          verify with an auto-detected profile (the everyday command)
  doctor         show environment readiness; verify nothing
  menu           interactive picker (what run.cmd does when double-clicked)
  self-test      prove the launcher, Node runtime and CLI are wired correctly
  install-path   optionally add a dsh-verify shim to a directory on PATH
  help           this text

Everything after the command is passed straight to the verifier, so all of its
flags work: --probe, --all, --only, --modes-only, --format, --baseline, ...
Run \`dsh-verify --help\` for the full flag list.

Examples
  dsh-verify-launcher quick
  dsh-verify-launcher quick --probe
  dsh-verify-launcher doctor
  dsh-verify-launcher quick --format junit --output results.xml

This is a standalone external tool. It is NOT a DSH plugin and NOT an agent
preset; DSH never loads it, and it never modifies your DSH configuration.
`;

/**
 * Launcher entry point.
 *
 * Argument classification is deliberately narrow: only a leading *non-flag*
 * token selects a launcher command. A leading flag could only ever belong to
 * the verifier (`--help`, `--version`, `--profile`, ...), so it is passed
 * through — treating it as "no command" and opening the menu would swallow it.
 * A bare invocation is the one case that wants the menu, because that is what a
 * double-click produces.
 *
 * @param {string[]} argv
 * @returns {Promise<number>} exit code.
 */
export async function launch(argv = []) {
  const first = argv[0];
  const namedCommand = first !== undefined && !first.startsWith('-');
  const command = namedCommand ? first : (argv.length === 0 ? 'menu' : null);
  const rest = namedCommand ? argv.slice(1) : argv;

  switch (command) {
    case 'help':
      process.stdout.write(LAUNCHER_USAGE);
      return 0;
    case 'doctor':
      return commandDoctor(parseLauncherFlags(rest));
    case 'menu':
      return commandMenu();
    case 'quick':
      return commandQuick(rest);
    case 'self-test':
      return commandSelfTest();
    case 'install-path':
      return commandInstallPath(parseLauncherFlags(rest));
    default:
      // Either a leading flag or a verifier subcommand ("baseline", "prompt").
      // The verifier owns those, including `--help` and `--version`.
      return runCli(argv);
  }
}

/** The launcher's own flags; everything else belongs to the verifier. */
function parseLauncherFlags(argv) {
  const options = {};
  for (let i = 0; i < argv.length; i += 1) {
    const token = argv[i];
    if (token === '--dir') { options.dir = argv[i + 1]; i += 1; continue; }
    if (token.startsWith('--dir=')) { options.dir = token.slice(6); continue; }
    if (token === '--dsh-home') { options.dshHome = argv[i + 1]; i += 1; continue; }
    if (token.startsWith('--dsh-home=')) { options.dshHome = token.slice(11); continue; }
    if (token === '--install') { options.install = argv[i + 1]; i += 1; continue; }
    if (token.startsWith('--install=')) { options.install = token.slice(10); continue; }
    if (token === '--remove') { options.remove = true; continue; }
    if (token === '--plain') { options.pretty = false; continue; }
  }
  return options;
}
