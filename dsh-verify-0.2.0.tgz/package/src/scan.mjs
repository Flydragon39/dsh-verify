/**
 * A small JavaScript lexer used to find *call sites* in plugin sources without
 * executing them.
 *
 * All the verifier needs from a plugin's source is "which things does this file
 * register, and under what name?" A naive regex is unsafe here: prompt text in
 * a real preset contains thousands of characters of quoted prose with braces
 * and parentheses, and a pattern match inside that prose would invent
 * artifacts that do not exist. So this module first classifies every character
 * as code or not-code (strings, template literals, comments, regex literals),
 * and only then matches and balances parentheses over code positions.
 *
 * @module dsh-verify/scan
 */

const CODE = 0;
const STRING = 1;
const TEMPLATE = 2;
const COMMENT = 3;
const REGEX = 4;

/** Characters after which a `/` begins a regex literal rather than division. */
const REGEX_PRECEDERS = new Set([
  '(', ',', '=', ':', '[', '!', '&', '|', '?', '{', '}', ';', '+', '-', '*', '%', '~', '^', '<', '>', '\n',
]);

const KEYWORDS_BEFORE_REGEX = new Set([
  'return', 'typeof', 'instanceof', 'in', 'of', 'new', 'delete', 'void', 'throw', 'case', 'do', 'else', 'yield', 'await',
]);

/**
 * Classify each character of `source`.
 *
 * @param {string} source
 * @returns {{ kinds: Uint8Array, length: number }}
 */
export function classify(source) {
  const kinds = new Uint8Array(source.length);
  const n = source.length;
  let i = 0;
  let lastCodeChar = '';
  let lastWord = '';

  const markPlain = (from, to) => {
    for (let k = from; k < to; k += 1) kinds[k] = CODE;
  };

  while (i < n) {
    const ch = source[i];

    // Line comment.
    if (ch === '/' && source[i + 1] === '/') {
      const start = i;
      while (i < n && source[i] !== '\n') i += 1;
      for (let k = start; k < i; k += 1) kinds[k] = COMMENT;
      continue;
    }

    // Block comment.
    if (ch === '/' && source[i + 1] === '*') {
      const start = i;
      i += 2;
      while (i < n && !(source[i] === '*' && source[i + 1] === '/')) i += 1;
      i = Math.min(n, i + 2);
      for (let k = start; k < i; k += 1) kinds[k] = COMMENT;
      continue;
    }

    // Single- and double-quoted strings.
    if (ch === '"' || ch === "'") {
      const quote = ch;
      const start = i;
      i += 1;
      while (i < n) {
        if (source[i] === '\\') { i += 2; continue; }
        if (source[i] === quote) { i += 1; break; }
        if (source[i] === '\n') { i += 1; break; } // unterminated: stop at EOL
        i += 1;
      }
      for (let k = start; k < i; k += 1) kinds[k] = STRING;
      lastCodeChar = quote;
      lastWord = '';
      continue;
    }

    // Template literal, including nested `${ ... }`.
    if (ch === '`') {
      const start = i;
      i += 1;
      let depth = 0;
      while (i < n) {
        if (source[i] === '\\') { i += 2; continue; }
        if (depth === 0 && source[i] === '`') { i += 1; break; }
        if (source[i] === '$' && source[i + 1] === '{') { depth += 1; i += 2; continue; }
        if (depth > 0 && source[i] === '}') { depth -= 1; i += 1; continue; }
        i += 1;
      }
      for (let k = start; k < i; k += 1) kinds[k] = TEMPLATE;
      lastCodeChar = '`';
      lastWord = '';
      continue;
    }

    // Regex literal vs division.
    if (ch === '/') {
      const prev = lastCodeChar;
      const isRegex = prev === '' || REGEX_PRECEDERS.has(prev) || KEYWORDS_BEFORE_REGEX.has(lastWord);
      if (isRegex) {
        const start = i;
        i += 1;
        let inClass = false;
        while (i < n) {
          const c = source[i];
          if (c === '\\') { i += 2; continue; }
          if (c === '[') inClass = true;
          else if (c === ']') inClass = false;
          else if (c === '/' && !inClass) { i += 1; break; }
          else if (c === '\n') break;
          i += 1;
        }
        while (i < n && /[a-z]/i.test(source[i])) i += 1;
        for (let k = start; k < i; k += 1) kinds[k] = REGEX;
        lastCodeChar = '/';
        lastWord = '';
        continue;
      }
    }

    // Ordinary code character.
    kinds[i] = CODE;
    if (!/\s/.test(ch)) {
      lastCodeChar = ch;
      if (/[A-Za-z0-9_$]/.test(ch)) lastWord += ch;
      else lastWord = '';
    } else if (ch === '\n') {
      lastWord = '';
    }
    i += 1;
  }

  // `markPlain` is retained for clarity of intent even though the fast path
  // above writes CODE directly.
  void markPlain;
  return { kinds, length: n };
}

/**
 * Find every call site of `pattern` and return its balanced argument text.
 *
 * @param {string} source - the file text.
 * @param {Uint8Array} kinds - classification from {@link classify}.
 * @param {RegExp} pattern - a global regex matched against code positions only.
 * @returns {Array<{ index: number, callee: string, args: string, argsStart: number, argsEnd: number, objectLiteral: string|null }>}
 */
export function findCallSites(source, kinds, pattern) {
  const sites = [];
  const regex = new RegExp(pattern.source, pattern.flags.includes('g') ? pattern.flags : `${pattern.flags}g`);
  let match;
  while ((match = regex.exec(source)) !== null) {
    if (kinds[match.index] !== CODE) continue;

    // Find the opening parenthesis that follows the callee.
    let i = match.index + match[0].length;
    while (i < source.length && (kinds[i] !== CODE || /\s/.test(source[i]))) i += 1;
    if (source[i] !== '(') continue;

    const argsStart = i + 1;
    let depth = 0;
    let end = -1;
    for (let k = i; k < source.length; k += 1) {
      if (kinds[k] !== CODE) continue;
      const c = source[k];
      if (c === '(' || c === '[' || c === '{') depth += 1;
      else if (c === ')' || c === ']' || c === '}') {
        depth -= 1;
        if (depth === 0) { end = k; break; }
      }
    }
    if (end === -1) continue;

    const args = source.slice(argsStart, end);
    const objectLiteral = /^\s*\{/.test(args) ? args.trim() : null;
    sites.push({
      index: match.index,
      callee: match[0],
      args,
      argsStart,
      argsEnd: end,
      objectLiteral,
    });
  }
  return sites;
}

/**
 * Read one top-level property from an object-literal source fragment.
 *
 * Scans only depth-1 keys, so `{ config: { name: 'inner' } }` never reports the
 * nested `name`. Values are returned as raw source text; callers decide how to
 * interpret them.
 *
 * @param {string} objectSource - text beginning with `{`.
 * @param {string} property - the property name to find.
 * @param {Uint8Array} kinds - classification for `objectSource` only.
 * @returns {{ raw: string, start: number, end: number } | null}
 */
export function readObjectProperty(objectSource, property, kinds) {
  if (typeof objectSource !== 'string' || !objectSource.startsWith('{')) return null;
  const n = objectSource.length;
  let depth = 0;

  for (let i = 0; i < n; i += 1) {
    if (kinds[i] !== CODE) continue;
    const ch = objectSource[i];
    if (ch === '{' || ch === '[' || ch === '(') { depth += 1; continue; }
    if (ch === '}' || ch === ']' || ch === ')') { depth -= 1; continue; }
    if (depth !== 1) continue;

    // A key position: start of the object body, or just after a comma at depth 1.
    const isKeyStart = (() => {
      let j = i - 1;
      while (j >= 0 && (kinds[j] !== CODE || /\s/.test(objectSource[j]))) j -= 1;
      return j < 0 || objectSource[j] === '{' || objectSource[j] === ',';
    })();
    if (!isKeyStart) continue;

    const keyMatch = /^([A-Za-z_$][\w$]*|'[^']*'|"[^"]*")\s*:/.exec(objectSource.slice(i));
    if (!keyMatch) continue;
    const key = keyMatch[1].replace(/^['"]|['"]$/g, '');
    if (key !== property) {
      i += keyMatch[0].length - 1;
      continue;
    }

    // Value runs until the next depth-1 comma or the closing brace.
    let start = i + keyMatch[0].length;
    let d = 1;
    let end = n - 1;
    for (let k = start; k < n; k += 1) {
      if (kinds[k] !== CODE) continue;
      const c = objectSource[k];
      if (c === '{' || c === '[' || c === '(') d += 1;
      else if (c === '}' || c === ']' || c === ')') {
        d -= 1;
        if (d === 0) { end = k; break; }
      } else if (c === ',' && d === 1) { end = k; break; }
    }
    return { raw: objectSource.slice(start, end).trim(), start, end };
  }
  return null;
}

/** Interpret a source fragment as a string literal when it is one. */
export function asStringLiteral(raw) {
  if (typeof raw !== 'string') return null;
  const text = raw.trim();
  if (text.length >= 2 && text[0] === '"' && text[text.length - 1] === '"') {
    return text.slice(1, -1).replace(/\\(.)/g, (_, c) => (c === 'n' ? '\n' : c === 't' ? '\t' : c));
  }
  if (text.length >= 2 && text[0] === "'" && text[text.length - 1] === "'") {
    return text.slice(1, -1).replace(/\\'/g, "'").replace(/\\\\/g, '\\');
  }
  if (text.length >= 2 && text[0] === '`' && text[text.length - 1] === '`') {
    return text.slice(1, -1);
  }
  return null;
}

/** True when a source fragment looks like an object literal. */
export function isObjectLiteral(raw) {
  return typeof raw === 'string' && /^\s*\{/.test(raw);
}

/** True when a source fragment looks like an array literal. */
export function isArrayLiteral(raw) {
  return typeof raw === 'string' && /^\s*\[/.test(raw);
}

/** Extract the string literals from an array-literal source fragment. */
export function readStringArray(raw) {
  if (!isArrayLiteral(raw)) return [];
  const out = [];
  const re = /'([^']*)'|"([^"]*)"|`([^`]*)`/g;
  let m;
  while ((m = re.exec(raw)) !== null) out.push(m[1] ?? m[2] ?? m[3]);
  return out;
}
