/**
 * The verifier: environment guard, snapshot, stepped verification, verdict.
 *
 * The orchestration is deliberately linear — guard, compose, verify plugins,
 * verify modes, optionally diff — because the plan's guarantee of termination
 * rests on there being no exploration loop anywhere in the pipeline.
 *
 * @module dsh-verify/verify
 */

import { join, resolve } from 'node:path';
import { fileURLToPath } from 'node:url';
import { homedir, tmpdir } from 'node:os';
import { spawn } from 'node:child_process';
import { openSync, closeSync, rmSync, readdirSync } from 'node:fs';
import { Budget } from './budget.mjs';
import { resolveDshHome, locateInstall, resolveDshCommand } from './paths.mjs';
import { composeProfile, indexRowsByName, GATE } from './compose.mjs';
import { scanPluginArtifacts, ARTIFACT } from './artifacts.mjs';
import { resolvePackage, shortPath, readTextOrNull } from './fsutil.mjs';
import { parseYaml } from './yaml.mjs';
import { STATUS, LAYER, row, worstStatus, verifyPlugin, verifyMode } from './ladder.mjs';
import {
  resolvePresetRoots, discoverPresets, sortPresets, checkPresetHealth, presetSurface, USER_PRESET_DIR,
} from './modes.mjs';
import { readBaseline, diffBaseline } from './baseline.mjs';

export const TOOL = { name: 'dsh-verify', version: '0.2.0', plan: 'DSH 插件与模式完整性校验方案（最终版）' };

/** Defaults mirroring the plan's stated budget. */
export const DEFAULTS = Object.freeze({
  calls: 20,
  seconds: 180,
  profile: 'web',
  probeTimeoutMs: 15000,
});

/**
 * The profile names a harness home actually contains, sorted.
 *
 * @param {string} dshHome - resolved harness home.
 * @returns {string[]} directory names under `profiles/`.
 */
export function listProfiles(dshHome) {
  try {
    return readdirSync(join(dshHome, 'profiles'), { withFileTypes: true })
      .filter((entry) => entry.isDirectory())
      .map((entry) => entry.name)
      .sort();
  } catch {
    return [];
  }
}

/**
 * The profile to verify when the user did not name one.
 *
 * `web` is DSH's shipped template, so it is the right guess only when it
 * exists. On a real harness home it frequently does not — `dsh-desktop` and
 * `dsh-pocket` create their own — and verifying a profile that is not there
 * produces a `FAILED` row that describes the default rather than the
 * installation. Choosing a profile that does exist keeps the default run
 * meaningful; `--profile` still overrides it.
 *
 * @param {string} dshHome
 * @returns {{ profile: string, source: 'requested'|'only-profile'|'default-exists'|'default' }}
 */
export function pickProfile(dshHome) {
  const available = listProfiles(dshHome);
  if (available.includes(DEFAULTS.profile)) {
    return { profile: DEFAULTS.profile, source: 'default-exists', available };
  }
  if (available.length >= 1) return { profile: available[0], source: 'auto-detected', available };
  return { profile: DEFAULTS.profile, source: 'default', available };
}

/**
 * Run a child process with a hard timeout, returning its output rather than
 * throwing. Used for every dynamic probe; nothing here streams to the user.
 *
 * @param {string} command
 * @param {string[]} args
 * @param {{ timeoutMs?: number, env?: Record<string, string>, cwd?: string, captureFile?: string|null }} [options]
 * @returns {Promise<{ ok: boolean, code: number|null, stdout: string, stderr: string, error: string|null, timedOut: boolean, capture: 'pipe'|'file' }>}
 */
export function runProcess(command, args, options = {}) {
  return runProcessWithCapture(command, args, options, 'pipe').then((result) => {
    if (result.error === null || !options.captureFile) return result;
    if (!/EPERM|EACCES|ENOTSUP|not permitted/i.test(result.error)) return result;
    // A confined sandbox may refuse to hand a pipe to the child. Retry once
    // with the child's output redirected to a real file the parent owns.
    return runProcessWithCapture(command, args, options, 'file');
  });
}

function runProcessWithCapture(command, args, options, capture) {
  const timeoutMs = options.timeoutMs ?? DEFAULTS.probeTimeoutMs;

  return new Promise((resolvePromise) => {
    let settled = false;
    const finish = (value) => {
      if (settled) return;
      settled = true;
      resolvePromise({ capture, ...value });
    };

    const stdio = capture === 'file' && options.captureFile
      ? fileStdio(options.captureFile)
      : ['ignore', 'pipe', 'pipe'];

    let child;
    try {
      child = spawn(command, args, {
        cwd: options.cwd,
        env: { ...process.env, ...(options.env ?? {}) },
        stdio,
        windowsHide: true,
        shell: process.platform === 'win32' && /\.(cmd|bat)$/i.test(command),
      });
    } catch (error) {
      closeStdio(stdio);
      finish({ ok: false, code: null, stdout: '', stderr: '', error: error.message, timedOut: false });
      return;
    }

    let stdout = '';
    let stderr = '';
    const cap = 512 * 1024;
    child.stdout?.on('data', (chunk) => { if (stdout.length < cap) stdout += chunk.toString('utf8'); });
    child.stderr?.on('data', (chunk) => { if (stderr.length < cap) stderr += chunk.toString('utf8'); });

    const timer = setTimeout(() => {
      try { child.kill('SIGKILL'); } catch { /* already gone */ }
      closeStdio(stdio);
      finish({ ok: false, code: null, stdout, stderr, error: `timed out after ${timeoutMs}ms`, timedOut: true });
    }, timeoutMs);

    /** Settle once, closing descriptors and reading back a file capture. */
    const settle = (value) => {
      clearTimeout(timer);
      closeStdio(stdio);
      if (capture === 'file' && options.captureFile) {
        finish({ ...value, stdout: readTextOrNull(options.captureFile) ?? '', stderr: '' });
        return;
      }
      finish(value);
    };

    child.on('error', (error) => settle({ ok: false, code: null, stdout, stderr, error: error.message, timedOut: false }));
    child.on('close', (code) => settle({
      ok: code === 0, code, stdout, stderr, error: code === 0 ? null : `exit code ${code}`, timedOut: false,
    }));
  });
}

/** Open a capture file and build the three-element stdio array for it. */
function fileStdio(path) {
  try {
    const fd = openSync(path, 'w');
    return ['ignore', fd, fd];
  } catch {
    return ['ignore', 'ignore', 'ignore'];
  }
}

/** Close any file descriptors a stdio array owns. */
function closeStdio(stdio) {
  if (!Array.isArray(stdio)) return;
  for (const slot of stdio) {
    if (typeof slot === 'number') {
      try { closeSync(slot); } catch { /* already closed */ }
    }
  }
}

/** Strip ANSI escapes and control characters so probe output stays reportable. */
export function cleanOutput(text) {
  return String(text ?? '')
    .replace(/\u001B\[[0-9;?]*[A-Za-z]/g, '')
    .replace(/[\u0000-\u0008\u000B\u000C\u000E-\u001F]/g, '')
    .trim();
}

/**
 * The environment guard (plan §4 and §1).
 *
 * Exactly one question is asked: can DSH be located and can its version be
 * read? A failure here is `BLOCKED`, and per the plan the run stops rather than
 * expanding into a platform health check.
 *
 * @param {object} options
 * @param {string} options.dshHome
 * @param {string} options.dshHomeSource
 * @param {any} options.install
 * @param {import('./budget.mjs').Budget} options.budget
 * @param {boolean} options.useVersionProbe
 * @returns {Promise<{ blocked: boolean, reason: string|null, version: string, versionSource: string, probes: any[] }>}
 */
export async function environmentGuard(options) {
  const { dshHome, dshHomeSource, install, budget, useVersionProbe } = options;
  const probes = [];

  if (!dshHome) {
    probes.push({ label: 'harness home', ok: false, detail: 'no DSH home directory found' });
    return { blocked: true, reason: 'harness home not found', version: '', versionSource: '', probes };
  }
  probes.push({ label: 'harness home', ok: true, detail: `${shortPath(dshHome)} (${dshHomeSource})` });

  if (!install.found) {
    probes.push({
      label: 'installation',
      ok: false,
      detail: install.explicitFailed
        ? `--install ${shortPath(install.anchor)} does not contain node_modules/@deepseek-ai/dsh`
        : `no @deepseek-ai/dsh package under any candidate root (${install.candidates.length} checked)`,
    });
    return { blocked: true, reason: install.explicitFailed ? 'the requested installation was not found' : 'DSH installation not found', version: '', versionSource: '', probes };
  }
  probes.push({ label: 'installation', ok: true, detail: `${shortPath(install.anchor)} (v${install.version || '?'})` });

  if (!useVersionProbe) {
    probes.push({ label: 'version', ok: true, detail: `${install.version || 'unknown'} (from the installed package manifest)` });
    return { blocked: false, reason: null, version: install.version, versionSource: 'package manifest', probes };
  }

  const command = resolveDshCommand(install);
  if (!budget.spend('environment guard: dsh --version')) {
    probes.push({ label: 'version', ok: false, detail: 'budget exhausted before the version probe' });
    return { blocked: true, reason: 'budget exhausted during the environment guard', version: '', versionSource: '', probes };
  }
  const result = await runProcess(command.command, [...command.args, '--version'], { timeoutMs: 10000 });
  const version = cleanOutput(result.stdout) || cleanOutput(result.stderr);
  if (!result.ok || version === '') {
    probes.push({
      label: 'version',
      ok: false,
      detail: `\`${command.command} --version\` failed (${result.error ?? 'no output'}) via ${command.source}`,
    });
    return { blocked: true, reason: 'the DSH CLI did not answer --version', version: install.version, versionSource: 'package manifest', probes };
  }
  probes.push({ label: 'version', ok: true, detail: `${version.split('\n')[0]} (via ${command.source})` });
  return { blocked: false, reason: null, version: version.split('\n')[0].trim(), versionSource: 'dsh --version', probes };
}

/** `systemPrompt` → `systemprompt`, `system-prompt` → `systemprompt`. */
function normalizeServiceKey(value) {
  return String(value ?? '').toLowerCase().replace(/[-_.]/g, '');
}

/** A per-run cache of package scans, so a package is read at most once. */
function makeScanCache(rootOptions) {
  const bySpecifier = new Map();
  const byPackageDir = new Map();

  const get = (specifier) => {
    if (bySpecifier.has(specifier)) return bySpecifier.get(specifier);
    const resolved = resolvePackage(specifier, rootOptions.roots);
    if (!resolved) { bySpecifier.set(specifier, null); return null; }

    // Several rows may mount one package through different subpaths; scanning
    // its sources once and sharing the result keeps the run linear.
    let scan = byPackageDir.get(resolved.packageDir);
    if (scan === undefined) {
      try {
        scan = scanPluginArtifacts({ name: resolved.pkgName, dir: resolved.packageDir, packageJson: resolved.packageJson });
      } catch {
        scan = null;
      }
      byPackageDir.set(resolved.packageDir, scan);
    }
    const value = scan ? { ...scan, name: specifier, resolution: resolved } : null;
    bySpecifier.set(specifier, value);
    return value;
  };

  return { get, size: () => bySpecifier.size };
}

/**
 * Is this composed row part of the platform rather than a user plugin?
 *
 * The plan is explicit that the platform is an environment guard, not a
 * verification target: "插件和模式是主角，平台只做环境守卫". Sweeping all
 * eighty-odd platform rows by default would bury the handful of rows the user
 * actually installed, so the default scope is the user's own plugins and
 * `--all` opts into the full tree.
 *
 * @param {string|null} specifier
 * @returns {boolean}
 */
export function isPlatformRow(specifier) {
  if (typeof specifier !== 'string') return true;
  if (specifier.startsWith('cordis:')) return true;
  return specifier.startsWith('@deepseek-ai/') || specifier === '@deepseek-ai';
}

/**
 * Verify a plugin's mount behaviour in an isolated child process.
 *
 * The probe imports the plugin's entry module with a minimal stub context and
 * reports whether doing so threw. It runs in a separate process so a plugin
 * that corrupts global state, blocks, or calls `process.exit` cannot affect the
 * verifier or its report.
 *
 * @param {object} options
 * @param {string} options.probeScript - absolute path to `probes/mount-smoke.mjs`.
 * @param {import('./budget.mjs').Budget} options.budget
 * @param {string[]} [options.resolveRoots] - the profile's module roots, so the
 *   probe can recognise a peer that the harness supplies but it cannot resolve.
 * @returns {(plugin: any) => Promise<{ ok: boolean, error: string|null, skipped?: string, inconclusive?: boolean }>}
 */
export function makeMountProbe(options) {
  const { probeScript, budget } = options;
  const root = options.captureDir ?? tmpdir();
  const resolveRoots = options.resolveRoots ?? [];

  return async (plugin) => {
    const stamp = `${process.pid}-${(probeCounter += 1)}-${Date.now().toString(36)}`;
    const captureFile = join(root, `dsh-verify-probe-${stamp}.json`);
    const args = [probeScript, '--plugin', plugin.dir, '--name', plugin.name, '--out', captureFile];
    for (const dir of resolveRoots) args.push('--resolve-root', dir);
    const result = await runProcess(
      process.execPath,
      args,
      { timeoutMs: DEFAULTS.probeTimeoutMs, captureFile },
    );

    let payload = null;
    const text = cleanOutput(result.stdout);
    if (text !== '') {
      try {
        payload = JSON.parse(text.split('\n').filter(Boolean).pop() ?? 'null');
      } catch {
        payload = null;
      }
    }
    // The probe writes its payload to both stdout and `--out`, so whichever
    // channel the sandbox actually permitted can supply the result. Reading the
    // file only when stdout was empty keeps stdout authoritative.
    if (payload === null) {
      const fromFile = cleanOutput(readTextOrNull(captureFile) ?? '');
      if (fromFile !== '') {
        try {
          payload = JSON.parse(fromFile.split('\n').filter(Boolean).pop() ?? 'null');
        } catch {
          payload = null;
        }
      }
    }
    try { rmSync(captureFile, { force: true }); } catch { /* best effort */ }

    // The probe failing to *run* says nothing about the plugin. Reporting it as
    // FAILED would be a false accusation, so it is surfaced as inconclusive and
    // the ladder records UNKNOWN instead.
    if (payload === null) {
      const detail = result.timedOut
        ? `the probe did not finish within ${DEFAULTS.probeTimeoutMs}ms`
        : `the probe process could not be run or produced no result (${result.error ?? 'unknown'})`;
      return { ok: false, inconclusive: true, error: detail, skipped: detail };
    }

    void budget;
    return {
      ok: payload.ok === true,
      error: payload.error ?? null,
      skipped: payload.skipped,
      inconclusive: payload.inconclusive === true,
    };
  };
}

let probeCounter = 0;

/**
 * Run a full verification.
 *
 * @param {object} [options]
 * @param {string} [options.profile] - profile name to compose.
 * @param {string} [options.dshHome] - explicit harness home.
 * @param {string} [options.install] - explicit install anchor.
 * @param {string} [options.dshBin] - explicit `dsh` command.
 * @param {string[]} [options.overlays] - extra `--patch` files.
 * @param {string[]} [options.only] - restrict to these plugin names or row ids.
 * @param {string[]} [options.modes] - restrict to these mode ids.
 * @param {boolean} [options.includeModes] - verify modes.
 * @param {boolean} [options.modesOnly] - verify only modes.
 * @param {boolean} [options.probe] - run the sandbox mount probe.
 * @param {number} [options.budgetCalls]
 * @param {number} [options.budgetSeconds]
 * @param {string} [options.baselinePath] - baseline to diff against.
 * @param {string} [options.probeScript] - override the probe script path.
 * @param {string} [options.mode] - label recorded in the report.
 * @returns {Promise<any>}
 */
export async function verify(options = {}) {
  const budget = new Budget({ calls: options.budgetCalls ?? DEFAULTS.calls, seconds: options.budgetSeconds ?? DEFAULTS.seconds });
  const label = options.mode ?? (options.modesOnly ? 'modes-only' : options.probe ? 'full' : 'static');

  const dshHomeInfo = resolveDshHome(options.dshHome);
  const install = locateInstall(dshHomeInfo.exists ? dshHomeInfo.path : '', options.install);

  // An explicit `--profile` is an instruction; otherwise choose one that exists.
  const chosen = options.profile
    ? { profile: options.profile, source: 'requested', available: dshHomeInfo.exists ? listProfiles(dshHomeInfo.path) : [] }
    : (dshHomeInfo.exists ? pickProfile(dshHomeInfo.path) : { profile: DEFAULTS.profile, source: 'default', available: [] });

  const guard = await environmentGuard({
    dshHome: dshHomeInfo.exists ? dshHomeInfo.path : '',
    dshHomeSource: dshHomeInfo.source,
    install,
    budget,
    // A version probe costs one call out of the plan's twenty; it is only worth
    // spending when the caller asked for dynamic work.
    useVersionProbe: options.versionProbe === true,
  });

  const environment = {
    dshHome: dshHomeInfo.exists ? dshHomeInfo.path : '',
    dshHomeSource: dshHomeInfo.source,
    installAnchor: install.anchor,
    installCandidates: install.candidates,
    dshVersion: guard.version || install.version,
    dshVersionSource: guard.versionSource,
    guardProbes: guard.probes,
  };

  const result = {
    tool: TOOL,
    environment,
    options: {
      profile: chosen.profile,
      profileSource: chosen.source,
      availableProfiles: chosen.available,
      mode: label,
      probe: options.probe === true,
      only: options.only ?? [],
      all: options.all === true,
      modes: options.modes ?? [],
      overlays: options.overlays ?? [],
      includeModes: options.includeModes !== false && !options.modesOnly,
      modesOnly: options.modesOnly === true,
    },
    profiles: [],
    modes: null,
    diff: null,
    budget: budget.snapshot(),
    summary: { blocked: false, blockedReason: null, failed: 0, degraded: 0, unknown: 0, deferred: 0, pass: 0, passMounted: 0, items: 0 },
  };

  if (guard.blocked) {
    result.summary.blocked = true;
    result.summary.blockedReason = guard.reason;
    result.budget = budget.snapshot();
    return result;
  }

  const profileName = chosen.profile;
  const probeScript = options.probeScript ?? fileURLToPath(new URL('../probes/mount-smoke.mjs', import.meta.url));

  // ── Compose the profile tree (L0's source of truth) ───────────────────────
  if (!result.options.modesOnly) {
    const composition = composeProfile({
      dshHome: dshHomeInfo.path,
      profile: profileName,
      installAnchor: install.anchor,
      overlays: options.overlays ?? [],
    });
    const table = await verifyProfilePlugins({
      composition, budget, install, options, probeScript,
    });
    result.profiles.push(table);
  }

  // ── Modes ─────────────────────────────────────────────────────────────────
  let rosterConfig = null;
  if (!result.options.modesOnly && result.profiles[0]?.composition?.ok) {
    const rosterRow = result.profiles[0].composition.rows.get('agent-presets');
    rosterConfig = rosterRow?.config ?? null;
  } else if (result.options.modesOnly) {
    const composition = composeProfile({ dshHome: dshHomeInfo.path, profile: profileName, installAnchor: install.anchor });
    rosterConfig = composition.rows.get('agent-presets')?.config ?? null;
  }

  if (result.options.includeModes || result.options.modesOnly) {
    result.modes = await verifyModes({
      dshHome: dshHomeInfo.path,
      install,
      rosterConfig,
      budget,
      // Pass the resolved profile through: `verifyModes` uses it to build the
      // module-resolution roots for the preset rows it scans.
      options: { ...options, profile: profileName },
    });
  }

  // ── Baseline diff ─────────────────────────────────────────────────────────
  if (options.baselinePath) {
    const loaded = readBaseline(options.baselinePath);
    result.diff = loaded.ok
      ? diffBaseline(loaded.baseline, result)
      : { changes: [], counts: {}, isEmpty: true, error: loaded.error };
  }

  // ── Aggregate ─────────────────────────────────────────────────────────────
  for (const table of result.profiles) {
    result.summary.failed += table.verdicts.failed;
    result.summary.degraded += table.verdicts.degraded;
    result.summary.unknown += table.verdicts.unknown;
    result.summary.pass += table.verdicts.pass;
    result.summary.passMounted += table.verdicts.passMounted;
    result.summary.deferred += table.verdicts.deferred;
    result.summary.items += table.rows.length;
  }
  if (result.modes) {
    result.summary.failed += result.modes.verdicts.failed;
    result.summary.degraded += result.modes.verdicts.degraded;
    result.summary.unknown += result.modes.verdicts.unknown;
    result.summary.pass += result.modes.verdicts.pass;
    result.summary.passMounted += result.modes.verdicts.passMounted;
    result.summary.deferred += result.modes.verdicts.deferred;
    result.summary.items += result.modes.rows.length;
  }

  result.budget = budget.snapshot();
  return result;
}

/**
 * Count statuses into the report's per-suite verdict block.
 *
 * A `deferred` row is UNKNOWN for a reason a flag can fix (a static run not
 * probing mounts) rather than something a human must investigate. It keeps its
 * UNKNOWN status — the plan is explicit that UNKNOWN is first-class — but it is
 * counted separately so it neither drives the exit code nor buries the findings
 * that do.
 */
function tally(rows) {
  const verdicts = { pass: 0, passMounted: 0, degraded: 0, failed: 0, unknown: 0, deferred: 0 };
  for (const item of rows) {
    if (item.status === STATUS.PASS) verdicts.pass += 1;
    else if (item.status === STATUS.PASS_MOUNTED) verdicts.passMounted += 1;
    else if (item.status === STATUS.DEGRADED) verdicts.degraded += 1;
    else if (item.status === STATUS.FAILED) verdicts.failed += 1;
    else if (item.detail?.deferred === true) verdicts.deferred += 1;
    else verdicts.unknown += 1;
  }
  return verdicts;
}

/**
 * Render one composition problem as a report row.
 *
 * The mapping is deliberately blunt: every kind here means "a declared input
 * did not make it into the tree", so the status is FAILED rather than
 * DEGRADED, and the layer says where it happened — L0 for a bundle package
 * that is simply not installed, L1 for a layer that exists but does not load.
 */
function compositionProblemRow(problem) {
  const path = problem.path ? shortPath(problem.path) : null;
  switch (problem.kind) {
    case 'bundle-unresolved':
      return row(
        `composition:bundle ${problem.bundle}`,
        'composition',
        STATUS.FAILED,
        LAYER.L0,
        `bundle ${problem.bundle} is declared by the profile but is not installed, so the rows it introduces are absent from the composed tree`,
      );
    case 'bundle-patch-invalid':
      return row(`composition:bundle ${problem.bundle}`, 'composition', STATUS.FAILED, LAYER.L1, problem.error);
    case 'bundle-patch-missing':
      return row(
        `composition:bundle ${problem.bundle}`,
        'composition',
        STATUS.FAILED,
        LAYER.L1,
        `bundle ${problem.bundle} declares patch ${path ?? '(unknown)'}, which does not exist`,
      );
    case 'bundle-patch-error':
      return row(`composition:bundle ${problem.bundle}`, 'composition', STATUS.FAILED, LAYER.L1, `${path ?? 'patch'}: ${problem.error}`);
    case 'profile-patch-error':
      return row('composition:profile cordis.patch.yml', 'composition', STATUS.FAILED, LAYER.L1, problem.error);
    case 'home-patch-error':
      return row('composition:home cordis.patch.yml', 'composition', STATUS.FAILED, LAYER.L1, problem.error);
    case 'overlay-patch-error':
      return row(`composition:overlay ${path ?? '(unknown)'}`, 'composition', STATUS.FAILED, LAYER.L1, problem.error);
    default:
      return row(`composition:${problem.kind}`, 'composition', STATUS.FAILED, LAYER.L1,
        problem.error ?? problem.path ?? problem.bundle ?? 'unrecognised composition problem');
  }
}

/** Verify every plugin in one composed profile. */
async function verifyProfilePlugins(input) {
  const { composition, budget, install, options, probeScript } = input;
  const rows = [];

  if (!composition.ok) {
    rows.push(row(composition.profile, 'profile', STATUS.FAILED, LAYER.L0, composition.error.message));
    const verdicts = tally(rows);
    return { profile: composition.profile, composition, rows, verdicts, summary: { failed: verdicts.failed, degraded: 0, unknown: 0 } };
  }

  // A layer that could not be read leaves the tree incomplete: the rows it
  // would have contributed are simply absent, and every PASS below is then a
  // claim about a tree DSH never builds. That is the silent failure this tool
  // exists to surface, so these become ordinary rows — the verdict, the exit
  // code, the text report and the JUnit export then agree by construction
  // instead of each needing its own copy of the check.
  for (const problem of composition.problems) rows.push(compositionProblemRow(problem));

  const nameIndex = indexRowsByName(composition.rows);

  // A DSH service key is a composed row id, not a package name, so injections
  // are matched against both indexes (normalized for systemPrompt/system-prompt).
  const rowIdIndex = new Map();
  for (const rowRecord of composition.rows.values()) {
    rowIdIndex.set(normalizeServiceKey(rowRecord.id), rowRecord);
  }

  const scanCache = makeScanCache({ roots: composition.resolutionRoots });

  // Tool names across the whole tree, so a duplicate registration is visible.
  const toolOwners = new Map();
  const capabilityIndex = new Map();
  for (const [specifier] of nameIndex) {
    const scan = scanCache.get(specifier);
    if (!scan) continue;
    for (const artifact of scan.artifacts) {
      if (artifact.type !== ARTIFACT.TOOL || !artifact.detail.named) continue;
      const owners = toolOwners.get(artifact.name) ?? [];
      if (!owners.includes(specifier)) owners.push(specifier);
      toolOwners.set(artifact.name, owners);
    }
    for (const capability of scan.capabilities) {
      const owners = capabilityIndex.get(capability.id) ?? [];
      if (!owners.includes(specifier)) owners.push(specifier);
      capabilityIndex.set(capability.id, owners);
    }
  }

  const only = new Set(options.only ?? []);
  const includePlatform = options.all === true || only.size > 0;
  const probe = options.probe
    ? makeMountProbe({ probeScript, budget, resolveRoots: composition.resolutionRoots })
    : null;
  let skippedPlatform = 0;

  for (const rowRecord of composition.rows.values()) {
    if (!budget.check()) {
      rows.push(row(rowRecord.name ?? rowRecord.id, 'plugin', STATUS.UNKNOWN, LAYER.L0, 'wall-clock budget exhausted before this row was inspected'));
      continue;
    }
    if (only.size > 0) {
      if (!only.has(rowRecord.id) && !only.has(rowRecord.name)) continue;
    } else if (!includePlatform && isPlatformRow(rowRecord.name)) {
      // Platform rows are the environment, not the subject: counted and
      // reported, but not verified row by row unless --all is given.
      skippedPlatform += 1;
      continue;
    }

    const resolution = rowRecord.name
      ? (scanCache.get(rowRecord.name)?.resolution ?? resolvePackage(rowRecord.name, composition.resolutionRoots))
      : null;
    const scan = rowRecord.name ? scanCache.get(rowRecord.name) : null;

    const outcome = await verifyPlugin({
      rowRecord: { ...rowRecord, profile: composition.profile },
      scan,
      resolution,
      nameIndex,
      rowIdIndex,
      capabilityIndex,
      toolOwners,
      probe,
      budget,
    });
    rows.push(...outcome.rows);
  }

  // Capability bindings: a config value that names a provider nothing publishes.
  rows.push(...checkCapabilityBindings(composition, capabilityIndex, scanCache));

  // A run that verified no plugin at all must say so. On a stock harness every
  // composed row is the platform's own, so the default scope has nothing to
  // check; printing "No findings" there reads as a pass for a deployment that
  // was never examined. Deferred, like the other "could not look" rows, so the
  // exit code stays about findings.
  if (!includePlatform && only.size === 0 && skippedPlatform > 0) {
    const verified = rows.some((r) => r.type === 'plugin');
    if (!verified) {
      rows.push(row(
        'plugins',
        'plugin',
        STATUS.UNKNOWN,
        LAYER.L0,
        `every one of the ${skippedPlatform} composed row(s) is a platform package, so nothing outside the platform was verified`
          + ' — either this deployment installs no plugins of its own yet, or the rows are declared where this build does not look'
          + ' (pass `--all` to verify the platform rows too)',
        { discoveryGap: true, deferred: true },
      ));
    }
  }

  const verdicts = tally(rows);
  return {
    profile: composition.profile,
    composition,
    rows,
    verdicts,
    skippedPlatform,
    includePlatform,
    summary: { failed: verdicts.failed, degraded: verdicts.degraded, unknown: verdicts.unknown },
  };
}

/**
 * Verify that every provider reference in the composed config has a publisher.
 *
 * This is the check that catches the plan's headline failure mode most
 * directly. `web.searchProvider: ddg` is a *string* naming a capability a
 * search plugin publishes at mount time; if that plugin silently stops
 * loading, the string still parses, the tree still composes, and nothing
 * reports an error — the search simply falls back to a different engine. Only
 * a cross-check between the config value and the set of registered capability
 * ids makes that visible.
 *
 * @param {any} composition
 * @param {Map<string, string[]>} capabilityIndex - capability id → owning plugin specifiers.
 * @param {{ get: (specifier: string) => any }} scanCache
 * @returns {any[]}
 */
export function checkCapabilityBindings(composition, capabilityIndex, scanCache) {
  const rows = [];
  const BINDING_KEYS = /(Provider|ProviderId)$/;

  for (const rowRecord of composition.rows.values()) {
    if (rowRecord.gate === GATE.DISABLED) continue;
    const config = rowRecord.config;
    if (config === null || typeof config !== 'object' || Array.isArray(config)) continue;

    for (const [key, value] of Object.entries(config)) {
      if (!BINDING_KEYS.test(key) || typeof value !== 'string' || value === '') continue;

      const owners = capabilityIndex.get(value) ?? [];
      const item = `${rowRecord.id} :: ${key}`;
      if (owners.length > 0) {
        rows.push(row(item, 'binding', STATUS.PASS, LAYER.L3, `"${value}" is published by ${owners.join(', ')}`));
        continue;
      }

      // Some providers are published by the host rather than a plugin row; the
      // row's own package is the best available evidence either way.
      const ownerScan = rowRecord.name ? scanCache.get(rowRecord.name) : null;
      const declaresProvider = ownerScan
        ? ownerScan.artifacts.some((a) => a.type === ARTIFACT.SERVICE && a.detail.role === 'register' && /Provider\b/.test(a.detail.verb ?? ''))
        : false;

      rows.push(row(
        item,
        'binding',
        declaresProvider ? STATUS.UNKNOWN : STATUS.DEGRADED,
        LAYER.L3,
        `"${value}" matches no capability id published by any composed plugin`
          + (declaresProvider
            ? `; ${rowRecord.name} does register a provider but its id could not be read statically, so this may be a false alarm`
            : `; ${rowRecord.name ?? 'the row'} registers no provider at all, so this reference is dangling`),
      ));
    }
  }

  return rows;
}

/** Discover, health-check and verify every mode. */
async function verifyModes(input) {
  const { dshHome, install, rosterConfig, budget, options } = input;
  const harnessBase = install.anchor;
  // `verify()` resolves the effective profile into `options.profile` before
  // this runs, so the module-resolution roots below match the profile whose
  // plugin rows were composed.
  const profileName = options.profile ?? DEFAULTS.profile;

  const roots = resolvePresetRoots({
    dshHome,
    homeDirectory: homedir(),
    installAnchor: install.anchor,
    rosterConfig,
  });

  const { presets, problems } = discoverPresets({ roots, harnessBase });
  const ordered = sortPresets(presets);

  // The default mode comes from the composition, then the settings document.
  let defaultId = typeof rosterConfig?.default === 'string' ? rosterConfig.default : null;
  const settingsSection = readSettingsSection(dshHome, 'agent-presets');
  if (settingsSection && typeof settingsSection.default === 'string') defaultId = settingsSection.default;

  const scanCache = makeScanCache({
    roots: [
      ...(install.anchor ? [join(install.anchor, 'node_modules')] : []),
      join(dshHome, 'profiles', profileName, '.dsh-module-fallback', 'node_modules'),
      join(dshHome, 'profiles', profileName, 'node_modules'),
    ],
  });

  const healthOf = (preset) => checkPresetHealth(preset, harnessBase);
  const surfaceOf = (preset) => presetSurface({
    rows: healthOf(preset).rows,
    cache: scanCache,
    resolveRow: (specifier) => scanCache.get(specifier),
  });

  const wanted = new Set(options.modes ?? []);
  const rows = [];
  const verified = [];

  // Pass one: every mode's health and surface, so the default's surface is
  // known before any diff is computed. A *shadowed* preset is kept in the run
  // rather than filtered out: it is precisely the silent failure this tool
  // exists to surface, and dropping it would hide the one case where a mode
  // directory is present, valid, and still never appears.
  const surfaces = new Map();
  for (const preset of ordered) {
    if (wanted.size > 0 && !wanted.has(preset.id)) continue;
    if (!budget.check()) {
      rows.push(row(`mode:${preset.id}`, 'mode', STATUS.UNKNOWN, LAYER.L0, 'wall-clock budget exhausted before this mode was inspected'));
      continue;
    }
    if (preset.shadowed) {
      verified.push({ preset, health: null, surface: null });
      continue;
    }
    const health = healthOf(preset);
    const surface = surfaceOf(preset);
    surfaces.set(preset.id, surface);
    verified.push({ preset, health, surface });
  }

  const defaultSurface = surfaces.get(defaultId) ?? null;

  // Pass two: the ladder, now with the real default surface in hand.
  for (const entry of verified) {
    const outcome = await verifyMode({
      preset: entry.preset,
      harnessBase,
      defaultId,
      defaultSurface,
      surfaceOf: () => entry.surface ?? { tools: [], prompts: [], services: [], packages: [], unscanned: [] },
      healthOf: () => entry.health,
      budget,
    });
    entry.status = outcome.status;
    rows.push(...outcome.rows);
  }

  // Finding zero presets is a result in its own right, and silence here would
  // read as a pass. Two causes are indistinguishable from the file system
  // alone, so both are named rather than guessed between.
  if (presets.length === 0) {
    rows.push(row(
      'modes',
      'mode',
      STATUS.UNKNOWN,
      LAYER.L0,
      'no agent preset was discovered in any root, so mode verification examined nothing'
        + ' — either this deployment genuinely has no preset yet, or DSH >= 0.2.0 declares'
        + ' its presets as `dsh-agent-preset` rows inside the composition instead of as'
        + ` ${USER_PRESET_DIR}/<id>/ directories, which this build of the tool does not yet scan`,
      // `deferred` keeps it out of the exit code for the same reason the L1
      // mount rows carry it: a run that could not look is not a finding. The
      // report still prints it, under NOTE.
      { discoveryGap: true, deferred: true },
    ));
  }

  const verdicts = tally(rows);
  return {
    roots,
    presets,
    problems,
    defaultId,
    defaultSurface,
    verified,
    rows,
    verdicts,
    summary: { failed: verdicts.failed, degraded: verdicts.degraded, unknown: verdicts.unknown },
  };
}

/** Read one section of `$DSH_HOME/settings.yaml`, or null. */
export function readSettingsSection(dshHome, section) {
  const text = readTextOrNull(join(dshHome, 'settings.yaml'));
  if (text === null) return null;
  let parsed;
  try {
    parsed = parseYaml(text);
  } catch {
    return null;
  }
  const value = parsed?.[section];
  return value && typeof value === 'object' && !Array.isArray(value) ? value : null;
}

export { worstStatus, STATUS, LAYER };
