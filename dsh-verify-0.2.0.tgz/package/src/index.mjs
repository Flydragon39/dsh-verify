/**
 * Public API.
 *
 * The CLI is a thin shell over these exports, so an independent agent session
 * or a CI script can import the same verification instead of shelling out.
 *
 * @example
 * import { verify, render, exitCodeFor } from 'dsh-verify';
 * const result = await verify({ profile: 'web', includeModes: true });
 * console.log(render(result, 'markdown'));
 * process.exitCode = exitCodeFor(result.summary);
 *
 * @module dsh-verify
 */

export { verify, environmentGuard, makeMountProbe, runProcess, cleanOutput, readSettingsSection, checkCapabilityBindings, isPlatformRow, listProfiles, pickProfile, TOOL, DEFAULTS } from './verify.mjs';
export {
  launch, commandQuick, commandDoctor, commandMenu, commandSelfTest, commandInstallPath,
  inspectEnvironment, findNode, isWindows, TOOL_ROOT,
} from './launcher.mjs';
export {
  STATUS, LAYER, LAYER_TIMEOUT_MS, row, worstStatus, verifyPlugin, verifyMode, checkContracts,
} from './ladder.mjs';
export { Budget, BudgetExhaustedError } from './budget.mjs';
export {
  composeProfile, loadPatchLayer, applyLayer, classifyGate, indexRowsByName, collectProvidedServices, GATE,
  PROFILE_PATCH_FILENAME, PROFILE_ROOT_FILENAME,
} from './compose.mjs';
export { scanPluginArtifacts, ARTIFACT, ARTIFACT_LABEL, ARTIFACT_ORDER, groupArtifacts, collectSourceFiles } from './artifacts.mjs';
export {
  resolvePresetRoots, discoverPresets, checkPresetHealth, sortPresets, presetSurface, readPresetMetadata,
  entryListProblem, flattenRows, unresolvableRows, classifySpecifier, packageInstalled, PRESET_ID,
  COMPOSITION_FILE, METADATA_FILE, USER_PRESET_DIR, TRUST,
} from './modes.mjs';
export { resolveDshHome, locateInstall, resolveDshCommand } from './paths.mjs';
export { buildBaseline, writeBaseline, readBaseline, diffBaseline, BASELINE_VERSION, BASELINE_FILE } from './baseline.mjs';
export { render, renderMarkdown, renderJson, renderJUnit, renderText, verdictLine, exitCodeFor, EXIT } from './report.mjs';
export { VERIFICATION_PROMPT, fillPrompt } from './prompt.mjs';
export { parseYaml, tryParseYaml, TaggedValue, YamlError } from './yaml.mjs';
