/**
 * Profile composition: the config tree, composed exactly as DSH composes it.
 *
 * DSH builds a profile's tree from ordered patch layers:
 *
 *   1. every bundle named by `package.json` → `dsh.profile.bundles`, in order,
 *      each contributing its own `cordis.patch.yml`;
 *   2. the profile's `cordis.patch.yml` (the user layer);
 *   3. `$DSH_HOME/cordis.patch.yml` (the home layer, which outranks layer 2);
 *   4. `--patch` overlays.
 *
 * A layer is a list of patch entries. An entry either `insert`s new rows or
 * targets an existing row `id` to replace its `config` (replacement, never a
 * deep merge) or to `disabled` it. Composing means folding those layers into
 * one ordered row set with last-write-wins per id.
 *
 * This module reproduces that fold. It never evaluates `!!js`; an expression
 * stays an opaque `TaggedValue`, which is why a platform-gated `disabled` is
 * reported as `conditional` rather than guessed at.
 *
 * @module dsh-verify/compose
 */

import { join, resolve } from 'node:path';
import { TaggedValue, parseYaml } from './yaml.mjs';
import { readTextOrNull, readJsonOrNull, isDir, isFile, resolvePackage, shortPath } from './fsutil.mjs';

/** Filename of a profile's root config, relative to the profile directory. */
export const PROFILE_ROOT_FILENAME = 'cordis.yml';
/** Filename of a patch layer, relative to a profile or package directory. */
export const PROFILE_PATCH_FILENAME = 'cordis.patch.yml';

/** The three states a row's `disabled` gate can be in. */
export const GATE = Object.freeze({
  ENABLED: 'enabled',
  DISABLED: 'disabled',
  CONDITIONAL: 'conditional',
});

/**
 * Classify a row's `disabled` field without evaluating it.
 *
 * `true` is off, absent/`false` is on, and anything the Loader interpolates
 * (an `!!js` expression) is `conditional`: the file alone cannot decide it.
 *
 * @param {any} value - the raw `disabled` value.
 * @returns {{ state: string, expr: string|null }}
 */
export function classifyGate(value) {
  if (value instanceof TaggedValue) return { state: GATE.CONDITIONAL, expr: value.__expr };
  if (value === true) return { state: GATE.DISABLED, expr: null };
  if (value === false || value === undefined || value === null) return { state: GATE.ENABLED, expr: null };
  // A truthy non-boolean is interpolated by the Loader; treat it as conditional
  // rather than assuming a truthiness rule the Loader may not share.
  return { state: GATE.CONDITIONAL, expr: String(value) };
}

/** Normalize an unknown thrown value into an Error. */
function asError(value) {
  return value instanceof Error ? value : new Error(String(value));
}

/**
 * Parse a patch layer file into a flat list of layer entries, preserving the
 * file's own order and recording where each entry came from.
 *
 * @param {string} path - the patch file.
 * @param {string} label - layer label used in evidence and reports.
 * @returns {{ label: string, path: string, exists: boolean, entries: any[], error: Error|null }}
 */
export function loadPatchLayer(path, label) {
  const base = { label, path, exists: isFile(path), entries: [], error: null };
  if (!base.exists) return base;

  const text = readTextOrNull(path);
  if (text === null) return { ...base, exists: true, error: new Error('file could not be read') };

  let parsed;
  try {
    parsed = parseYaml(text);
  } catch (error) {
    return { ...base, exists: true, error: asError(error) };
  }

  if (parsed === null) return { ...base, exists: true, entries: [] };
  if (!Array.isArray(parsed)) {
    return { ...base, exists: true, error: new Error('patch layer must be a top-level list of patch entries') };
  }
  return { ...base, exists: true, entries: parsed };
}

/**
 * Fold one layer's entries into the running row map.
 *
 * Entry shapes handled, matching the Loader's patch dialect:
 *   - `{ insert: [row, ...] }`   append rows, later duplicates of the same id
 *     replacing the earlier row and keeping the *original* position;
 *   - `{ id, disabled?: true }`  override one field of an existing row;
 *   - `{ id, config: {...} }`    replace that row's whole config;
 *   - `{ id: 'a/b', ... }`       a subpath id addresses a nested row.
 *
 * An entry naming an id that no earlier layer inserted is recorded as an
 * orphan: DSH's own dump would keep it, but for verification an orphan is a
 * real finding ("this plugin is configured but nothing ever introduces it").
 *
 * @param {Map<string, any>} rows - running id → row map (mutated).
 * @param {any[]} entries - layer entries.
 * @param {string} layerLabel - current layer label.
 * @returns {{ inserted: string[], overridden: string[], orphans: string[], malformed: any[] }}
 */
export function applyLayer(rows, entries, layerLabel) {
  const report = { inserted: [], overridden: [], orphans: [], malformed: [] };

  for (const entry of entries) {
    if (entry === null || typeof entry !== 'object' || Array.isArray(entry)) {
      report.malformed.push({ entry, reason: 'entry is not a mapping' });
      continue;
    }

    if (Array.isArray(entry.insert)) {
      for (const row of entry.insert) {
        if (row === null || typeof row !== 'object' || Array.isArray(row)) {
          report.malformed.push({ entry: row, reason: 'inserted row is not a mapping' });
          continue;
        }
        const id = typeof row.id === 'string' ? row.id : null;
        if (id === null) {
          report.malformed.push({ entry: row, reason: 'inserted row has no string `id`' });
          continue;
        }
        const previous = rows.get(id);
        if (previous) {
          rows.set(id, mergeRow(previous, row, layerLabel));
          report.overridden.push(id);
        } else {
          rows.set(id, toRow(id, row, layerLabel));
          report.inserted.push(id);
        }
      }
      continue;
    }

    if (typeof entry.id === 'string') {
      const id = entry.id;
      const previous = rows.get(id);
      if (!previous) {
        report.orphans.push(id);
        rows.set(id, toRow(id, entry, layerLabel, { orphan: true }));
        continue;
      }
      rows.set(id, mergeRow(previous, entry, layerLabel));
      report.overridden.push(id);
      continue;
    }

    report.malformed.push({ entry, reason: 'entry has neither `insert` nor a string `id`' });
  }

  return report;
}

/** Build the canonical row record the rest of the verifier consumes. */
function toRow(rowId, raw, layerLabel, extra = {}) {
  const gate = classifyGate(raw.disabled);
  return {
    id: rowId,
    name: typeof raw.name === 'string' ? raw.name : null,
    config: raw.config ?? null,
    gate: gate.state,
    gateExpr: gate.expr,
    introducedBy: layerLabel,
    lastTouchedBy: layerLabel,
    layers: [layerLabel],
    orphan: extra.orphan === true,
    raw,
  };
}

/** Merge a later layer's override onto an existing row. */
function mergeRow(previous, raw, layerLabel) {
  const gate = 'disabled' in raw ? classifyGate(raw.disabled) : { state: previous.gate, expr: previous.gateExpr };
  const name = typeof raw.name === 'string' ? raw.name : previous.name;
  // Patch semantics: a `config` key replaces the whole config, it does not merge.
  const config = 'config' in raw ? raw.config : previous.config;
  return {
    ...previous,
    name,
    config,
    gate: gate.state,
    gateExpr: gate.expr,
    lastTouchedBy: layerLabel,
    layers: previous.layers.includes(layerLabel) ? previous.layers : [...previous.layers, layerLabel],
    raw: { ...previous.raw, ...raw },
  };
}

/**
 * Resolve the ordered `node_modules` search roots for a profile.
 *
 * Mirrors the harness's own fallback: the profile's links first, then the
 * fallback farm, then the installation anchor that owns `@deepseek-ai/*`.
 *
 * @param {string} profileDir
 * @param {string} installAnchor
 * @returns {string[]}
 */
export function profileResolutionRoots(profileDir, installAnchor) {
  const roots = [];
  if (profileDir) {
    const fallback = join(profileDir, '.dsh-module-fallback', 'node_modules');
    if (isDir(fallback)) roots.push(fallback);
    roots.push(join(profileDir, 'node_modules'));
  }
  if (installAnchor) roots.push(join(installAnchor, 'node_modules'));
  return roots;
}

/**
 * Compose a profile's full config tree.
 *
 * @param {object} options
 * @param {string} options.dshHome - resolved harness home.
 * @param {string} options.profile - profile name.
 * @param {string} options.installAnchor - directory owning `node_modules/@deepseek-ai`.
 * @param {string[]} [options.overlays] - extra `--patch` files.
 * @returns {{
 *   ok: boolean, error: Error|null, profile: string, profileDir: string,
 *   manifestPath: string, manifest: any, bundleNames: string[],
 *   layers: any[], bundles: any[], rows: Map<string, any>, order: string[],
 *   homePatchPath: string, profilePatchPath: string, rootPath: string,
 *   resolutionRoots: string[], problems: any[]
 * }}
 */
export function composeProfile(options) {
  const { dshHome, profile, installAnchor, overlays = [] } = options;
  const profileDir = join(dshHome, 'profiles', profile);
  const resolutionRoots = profileResolutionRoots(profileDir, installAnchor);

  const result = {
    ok: false,
    error: null,
    profile,
    profileDir,
    rootPath: join(profileDir, PROFILE_ROOT_FILENAME),
    manifestPath: join(profileDir, 'package.json'),
    profilePatchPath: join(profileDir, PROFILE_PATCH_FILENAME),
    homePatchPath: join(dshHome, PROFILE_PATCH_FILENAME),
    manifest: null,
    bundleNames: [],
    bundles: [],
    layers: [],
    rows: new Map(),
    order: [],
    resolutionRoots,
    problems: [],
  };

  if (!isDir(profileDir)) {
    result.error = new Error(`profile directory not found: ${shortPath(profileDir)}`);
    return result;
  }

  const manifest = readJsonOrNull(result.manifestPath);
  if (manifest === null) {
    result.error = new Error(`profile manifest missing or unparsable: ${shortPath(result.manifestPath)}`);
    return result;
  }
  result.manifest = manifest;

  const bundles = manifest?.dsh?.profile?.bundles;
  if (!Array.isArray(bundles)) {
    result.error = new Error('profile manifest has no `dsh.profile.bundles` array');
    return result;
  }
  result.bundleNames = bundles.filter((b) => typeof b === 'string');

  // Layer 1: each bundle's own patch files, in declaration order.
  //
  // `dsh.bundle.patch` is one package-relative path or an ORDERED LIST of them
  // (`bundlePatchFiles` in `@deepseek-ai/dsh-app-boot`, whose docblock reads
  // "one file, or an ordered list of files"). DSH 0.2.0 uses the list form for
  // its own bundle: `@deepseek-ai/dsh-web-app` declares
  // [cordis.patch.yml, presets/standard.patch.yml, presets/ptc.patch.yml,
  // presets/minimal.patch.yml, presets/cordis.patch.yml], and those preset
  // layers are what declare the `standard`/`ptc`/`minimal`/`cordis` modes.
  //
  // Reading only the first entry — or, as this file previously did, passing the
  // whole array to `path.resolve` — silently composes a tree without any agent
  // preset, or throws outright. Both are the failure this tool exists to catch,
  // so the list is honoured in full and in order.
  for (const bundleName of result.bundleNames) {
    const resolved = resolvePackage(bundleName, resolutionRoots);
    if (!resolved) {
      result.bundles.push({ name: bundleName, resolved: false, reason: 'package could not be resolved from the profile' });
      result.problems.push({ kind: 'bundle-unresolved', bundle: bundleName });
      continue;
    }

    const declared = resolved.packageJson?.dsh?.bundle?.patch;
    let patchRels;
    if (declared === undefined || declared === null) {
      patchRels = [PROFILE_PATCH_FILENAME];
    } else if (typeof declared === 'string') {
      patchRels = [declared];
    } else if (Array.isArray(declared) && declared.every((file) => typeof file === 'string')) {
      patchRels = declared;
    } else {
      // DSH throws the same way; report it as a composition problem rather
      // than crashing the whole run on a malformed third-party bundle.
      result.bundles.push({ name: bundleName, resolved: true, dir: resolved.dir, invalidPatchDeclaration: true });
      result.problems.push({ kind: 'bundle-patch-invalid', bundle: bundleName, error: 'dsh.bundle.patch must be a file path or a list of file paths' });
      continue;
    }

    const patchPaths = [];
    let bundleRowCount = 0;
    let allPatchesExist = true;
    for (const patchRel of patchRels) {
      const patchPath = resolve(resolved.dir, patchRel);
      // A missing member of a declared list is reported, not skipped: DSH's
      // layers are ordered and last-write-wins, so dropping one changes which
      // row config survives.
      const layer = loadPatchLayer(patchPath, bundleName);
      applyLayer(result.rows, layer.entries, bundleName);
      result.layers.push(layer);
      patchPaths.push(patchPath);
      bundleRowCount += layer.entries.length;
      if (!layer.exists) allPatchesExist = false;
      if (layer.error) result.problems.push({ kind: 'bundle-patch-error', bundle: bundleName, path: patchPath, error: layer.error.message });
      else if (!layer.exists) result.problems.push({ kind: 'bundle-patch-missing', bundle: bundleName, path: patchPath });
    }

    result.bundles.push({
      name: bundleName,
      resolved: true,
      dir: resolved.dir,
      version: resolved.packageJson?.version ?? '',
      patchPaths,
      // Retained for the report and the baseline: the first patch is the
      // bundle's own tree, the rest are the preset layers it contributes.
      patchPath: patchPaths[0] ?? null,
      patchExists: allPatchesExist,
      rowCount: bundleRowCount,
    });
  }

  // Layer 2: the profile's own user layer.
  const profileLayer = loadPatchLayer(result.profilePatchPath, 'profile cordis.patch.yml');
  result.layers.push(profileLayer);
  result.profileApplied = applyLayer(result.rows, profileLayer.entries, 'profile cordis.patch.yml');
  if (profileLayer.error) result.problems.push({ kind: 'profile-patch-error', error: profileLayer.error.message });

  // Layer 3: the home layer, which outranks the profile layer.
  const homeLayer = loadPatchLayer(result.homePatchPath, 'home cordis.patch.yml');
  result.layers.push(homeLayer);
  result.homeApplied = applyLayer(result.rows, homeLayer.entries, 'home cordis.patch.yml');
  if (homeLayer.error) result.problems.push({ kind: 'home-patch-error', error: homeLayer.error.message });

  // Layer 4: explicit overlays, in argv order.
  result.overlayApplied = [];
  for (const file of overlays) {
    const absolute = resolve(file);
    const layer = loadPatchLayer(absolute, absolute);
    result.layers.push(layer);
    result.overlayApplied.push(applyLayer(result.rows, layer.entries, absolute));
    if (layer.error) result.problems.push({ kind: 'overlay-patch-error', path: absolute, error: layer.error.message });
  }

  result.order = [...result.rows.keys()];
  result.ok = true;
  return result;
}

/**
 * Index the composed rows by the module specifier each row mounts. Several rows
 * may mount the same package (base ships `tool-subagent` and
 * `tool-subagent-fork` over one package), so the index holds arrays.
 *
 * @param {Map<string, any>} rows
 * @returns {Map<string, any[]>}
 */
export function indexRowsByName(rows) {
  const index = new Map();
  for (const row of rows.values()) {
    if (!row.name) continue;
    const list = index.get(row.name);
    if (list) list.push(row);
    else index.set(row.name, [row]);
  }
  return index;
}

/**
 * The set of service names a composed tree publishes, inferred from each
 * mounted package's own declaration. Used to judge whether an `inject`
 * dependency has a provider anywhere in the tree.
 *
 * @param {Map<string, any>} rows
 * @param {string[]} resolutionRoots
 * @returns {Map<string, string[]>} service name → row ids that publish it
 */
export function collectProvidedServices(rows, resolutionRoots) {
  const provided = new Map();
  for (const row of rows.values()) {
    if (!row.name || row.gate === GATE.DISABLED) continue;
    const resolved = resolvePackage(row.name, resolutionRoots);
    const declared = resolved?.packageJson?.dsh?.provides;
    if (!Array.isArray(declared)) continue;
    for (const service of declared) {
      if (typeof service !== 'string') continue;
      const list = provided.get(service);
      if (list) list.push(row.id);
      else provided.set(service, [row.id]);
    }
  }
  return provided;
}
