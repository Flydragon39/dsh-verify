/**
 * Command-line surface.
 *
 * Three run modes, as the plan specifies: a CLI invocation (this file), a CI
 * step (the same command with `--format junit`), and an independent agent
 * session (the `--prompt` output). All three drive the same code path, so a
 * verdict means the same thing in each.
 *
 * @module dsh-verify/cli
 */

import { writeFileSync, mkdirSync } from 'node:fs';
import { resolve, join, dirname } from 'node:path';
import { verify, DEFAULTS, TOOL } from './verify.mjs';
import { buildBaseline, writeBaseline } from './baseline.mjs';
import { render, renderText, exitCodeFor, verdictLine } from './report.mjs';
import { VERIFICATION_PROMPT } from './prompt.mjs';

const USAGE = `dsh-verify — external completeness verifier for DSH plugins and agent-preset modes

Usage
  dsh-verify [verify] [options]        verify plugins and modes (default)
  dsh-verify quick [options]           verify with an auto-detected profile
  dsh-verify doctor                    show environment readiness; verify nothing
  dsh-verify menu                      interactive picker
  dsh-verify self-test                 check the launcher and CLI are wired up
  dsh-verify baseline save [options]   snapshot the current state as a baseline
  dsh-verify baseline diff [options]   compare the current state against a baseline
  dsh-verify prompt                    print the standalone verification prompt
  dsh-verify help                      show this text

Scope
  --profile <name>       profile to compose. When omitted, the profile is
                         auto-detected from <dsh-home>/profiles: the shipped
                         "web" template if it is present, otherwise the
                         installation's own profile. Listing them is easy:
                         run \`dsh-verify doctor\`.
  --modes-only           verify agent-preset modes only
  --plugins-only         skip mode verification
  --all                  verify every composed row, including the platform's own
                         @deepseek-ai/* packages. The default scope is the rows
                         you installed, because the plan treats the platform as
                         an environment guard rather than a subject.
  --only <a,b>           restrict plugins to these row ids or package names
  --modes <a,b>          restrict modes to these preset ids
  --patch <file>         extra patch overlay (repeatable)

Environment
  --dsh-home <path>      harness home                        (default: $DSH_HOME or ~/.dsh)
  --install <path>       directory owning node_modules/@deepseek-ai
  --dsh-bin <path>       the dsh executable, for the --version guard
  --version-probe        spend one budget call on \`dsh --version\`

Verification depth
  --probe                import each plugin in an isolated process (mount smoke test)
  --budget-calls <n>     probe-call ceiling                   (default: ${DEFAULTS.calls})
  --budget-seconds <n>   wall-clock ceiling                   (default: ${DEFAULTS.seconds})

Baseline
  --save-baseline <file> write a baseline snapshot after verifying
  --baseline <file>      diff the result against this baseline

Output
  --format <fmt>         text | markdown | json | junit       (default: text)
  --output <file>        write the report to a file instead of stdout
  --quiet                suppress the human summary on stderr
  --help, -h             show this text
  --version, -V          show the tool version

Exit codes
  0  no findings            1  FAILED or DEGRADED present            2  BLOCKED

Examples
  dsh-verify --profile web
  dsh-verify --probe --format markdown --output report.md
  dsh-verify --modes-only --format json --output modes.json
  dsh-verify --baseline .dsh-verify/baseline.json --format junit --output results.xml
  dsh-verify baseline save --output .dsh-verify/baseline.json
`;

/** Parse `--flag value`, `--flag=value`, and boolean flags. */
export function parseArgs(argv) {
  const options = { _: [], overlays: [], only: [], modes: [] };
  const takesValue = new Set([
    'profile', 'dsh-home', 'install', 'dsh-bin', 'patch', 'only', 'modes',
    'budget-calls', 'budget-seconds', 'format', 'output', 'baseline', 'save-baseline',
  ]);

  for (let i = 0; i < argv.length; i += 1) {
    const token = argv[i];
    if (!token.startsWith('--')) {
      options._.push(token);
      continue;
    }
    const eq = token.indexOf('=');
    const name = eq === -1 ? token.slice(2) : token.slice(2, eq);
    let value = eq === -1 ? null : token.slice(eq + 1);

    if (takesValue.has(name)) {
      if (value === null) {
        value = argv[i + 1] ?? null;
        i += 1;
      }
      if (value === null) throw new Error(`--${name} needs a value`);
      if (name === 'patch') options.overlays.push(value);
      else if (name === 'only') options.only.push(...value.split(',').map((s) => s.trim()).filter(Boolean));
      else if (name === 'modes') options.modes.push(...value.split(',').map((s) => s.trim()).filter(Boolean));
      else options[camel(name)] = value;
      continue;
    }
    options[camel(name)] = true;
  }

  return options;
}

function camel(name) {
  return name.replace(/-([a-z])/g, (_, c) => c.toUpperCase());
}

/** Translate parsed flags into `verify()` options. */
function toVerifyOptions(options) {
  const calls = options.budgetCalls === undefined ? undefined : Number(options.budgetCalls);
  const seconds = options.budgetSeconds === undefined ? undefined : Number(options.budgetSeconds);
  if (calls !== undefined && (!Number.isFinite(calls) || calls <= 0)) throw new Error('--budget-calls must be a positive number');
  if (seconds !== undefined && (!Number.isFinite(seconds) || seconds <= 0)) throw new Error('--budget-seconds must be a positive number');

  return {
    profile: options.profile,
    dshHome: options.dshHome,
    install: options.install,
    dshBin: options.dshBin,
    overlays: options.overlays,
    only: options.only,
    all: options.all === true,
    modes: options.modes,
    includeModes: options.pluginsOnly !== true,
    modesOnly: options.modesOnly === true,
    probe: options.probe === true,
    versionProbe: options.versionProbe === true,
    budgetCalls: calls,
    budgetSeconds: seconds,
    baselinePath: options.baseline,
    mode: options.modesOnly ? 'modes-only' : options.probe ? 'full' : 'static',
  };
}

/** Write a report to a file or stdout. */
function emitReport(text, options) {
  if (!options.output) {
    process.stdout.write(text.endsWith('\n') ? text : `${text}\n`);
    return;
  }
  const path = resolve(options.output);
  mkdirSync(dirname(path), { recursive: true });
  writeFileSync(path, text.endsWith('\n') ? text : `${text}\n`, 'utf8');
  if (!options.quiet) process.stderr.write(`report written to ${path}\n`);
}

/**
 * Entry point.
 *
 * @param {string[]} argv - `process.argv.slice(2)`.
 * @returns {Promise<number>} the process exit code.
 */
export async function main(argv) {
  if (argv.includes('--help') || argv.includes('-h') || argv[0] === 'help') {
    process.stdout.write(USAGE);
    return 0;
  }
  if (argv.includes('--version') || argv.includes('-V')) {
    process.stdout.write(`${TOOL.name} ${TOOL.version}\n`);
    return 0;
  }
  if (argv[0] === 'prompt') {
    process.stdout.write(VERIFICATION_PROMPT);
    return 0;
  }

  // Launcher commands. Imported lazily so the common verification path never
  // pays for the convenience surface, and so `cli.mjs` stays importable from
  // `launcher.mjs` without an eager cycle.
  if (argv[0] === 'quick' || argv[0] === 'doctor' || argv[0] === 'menu' || argv[0] === 'self-test') {
    const launcher = await import('./launcher.mjs');
    if (argv[0] === 'quick') return launcher.commandQuick(argv.slice(1));
    if (argv[0] === 'doctor') return launcher.commandDoctor();
    if (argv[0] === 'self-test') return launcher.commandSelfTest();
    return launcher.commandMenu();
  }

  const subcommand = argv[0] === 'baseline' ? 'baseline' : 'verify';
  const action = subcommand === 'baseline' ? argv[1] : null;
  const rest = subcommand === 'baseline' ? argv.slice(2) : argv;

  const options = parseArgs(rest);

  if (subcommand === 'baseline' && (action === 'save' || action === 'diff')) {
    const verifyOptions = toVerifyOptions(options);
    if (action === 'diff' && !verifyOptions.baselinePath && options.output) verifyOptions.baselinePath = options.output;
    const result = await verify(verifyOptions);

    if (action === 'save') {
      const baseline = buildBaseline(result);
      const destination = resolve(options.output ?? join('.dsh-verify', 'baseline.json'));
      const written = writeBaseline(destination, baseline);
      if (!written.ok) {
        process.stderr.write(`could not write baseline: ${written.error}\n`);
        return 2;
      }
      process.stderr.write(`baseline saved to ${written.path}\n`);
      process.stdout.write(`${renderText(result)}\n`);
      return exitCodeFor(result.summary);
    }

    // `baseline diff` verifies against the named baseline and reports the delta.
    const text = options.format && options.format !== 'text'
      ? render(result, options.format)
      : renderText(result);
    emitReport(text, options);
    return exitCodeFor(result.summary);
  }

  const verifyOptions = toVerifyOptions(options);
  const result = await verify(verifyOptions);
  const format = options.format ?? 'text';
  emitReport(render(result, format), options);

  if (!options.quiet && format !== 'text' && !options.output) {
    process.stderr.write(`${verdictLine(result.summary)}\n`);
  }
  return exitCodeFor(result.summary);
}

export { USAGE };
