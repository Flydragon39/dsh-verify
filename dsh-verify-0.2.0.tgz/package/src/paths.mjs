/**
 * Locating the DeepSeek Harness installation without booting it.
 *
 * The verifier never imports DSH code. It only needs two facts: where the user
 * configuration lives (`$DSH_HOME`) and where the installed `@deepseek-ai/*`
 * packages live (the *install anchor*). Both are discovered from the
 * filesystem, with every candidate and its outcome recorded so a `BLOCKED`
 * verdict can say exactly what was looked for and where.
 *
 * @module dsh-verify/paths
 */

import { join, dirname, resolve } from 'node:path';
import { existsSync } from 'node:fs';
import { homedir } from 'node:os';
import { readJsonOrNull, isDir, listDir, shortPath } from './fsutil.mjs';

/** Environment variables the launcher itself honours. */
export const DSH_HOME_ENV = 'DSH_HOME';

/**
 * Resolve the harness home directory.
 *
 * Precedence: explicit option, `$DSH_HOME`, then `~/.dsh`. A candidate that
 * does not exist is still returned when it was named explicitly, so the caller
 * can report "you asked for X and X is not there" rather than silently
 * inspecting a different home.
 *
 * @param {string} [explicit] - value from `--dsh-home`.
 * @returns {{ path: string, source: string, exists: boolean }}
 */
export function resolveDshHome(explicit) {
  const candidates = [];
  if (explicit) candidates.push({ path: resolve(explicit), source: 'option --dsh-home' });
  if (process.env[DSH_HOME_ENV]) candidates.push({ path: resolve(process.env[DSH_HOME_ENV]), source: `env ${DSH_HOME_ENV}` });
  candidates.push({ path: join(homedir(), '.dsh'), source: 'default ~/.dsh' });
  for (const candidate of candidates) {
    if (isDir(candidate.path)) return { ...candidate, exists: true };
  }
  const last = candidates[candidates.length - 1];
  return { ...last, exists: false };
}

/** Directories that may hold a `@deepseek-ai/dsh` package, lowest cost first. */
function installAnchorCandidates(dshHome) {
  const candidates = [];
  const push = (path, source) => {
    if (path && !candidates.some((c) => c.path === path)) candidates.push({ path, source });
  };

  push(process.env.DSH_INSTALL, 'env DSH_INSTALL');
  if (process.env.DSH_DSH_ROOT) push(process.env.DSH_DSH_ROOT, 'env DSH_DSH_ROOT');

  // A profile's own dependency links, and the harness fallback link farm.
  if (dshHome) {
    for (const entry of listDir(join(dshHome, 'profiles'))) {
      if (!entry.isDirectory()) continue;
      const profileDir = join(dshHome, 'profiles', entry.name);
      push(join(profileDir, '.dsh-module-fallback', 'node_modules'), `profile ${entry.name} module fallback`);
      push(join(profileDir, 'node_modules'), `profile ${entry.name} node_modules`);
    }
  }

  // npm/npx caches: the common way `dsh` is run without a global install.
  for (const cache of npmCacheRoots()) {
    const npxDir = join(cache, '_npx');
    for (const entry of listDir(npxDir)) {
      if (entry.isDirectory()) push(join(npxDir, entry.name, 'node_modules'), `npx cache ${entry.name}`);
    }
    push(join(cache, 'node_modules'), 'npm cache root');
  }

  // Global and prefix installs.
  for (const prefix of globalPrefixes()) {
    push(join(prefix, 'node_modules'), `global prefix ${prefix}`);
    push(join(prefix, 'lib', 'node_modules'), `global prefix ${prefix}`);
  }

  return candidates;
}

/** Candidate npm cache directories across platforms. */
function npmCacheRoots() {
  const roots = [];
  if (process.env.npm_config_cache) roots.push(process.env.npm_config_cache);
  if (process.env.NPM_CONFIG_CACHE) roots.push(process.env.NPM_CONFIG_CACHE);
  if (process.env.LOCALAPPDATA) roots.push(join(process.env.LOCALAPPDATA, 'npm-cache'));
  if (process.env.APPDATA) roots.push(join(process.env.APPDATA, 'npm-cache'));
  roots.push(join(homedir(), '.npm'));
  if (process.env.XDG_CACHE_HOME) roots.push(join(process.env.XDG_CACHE_HOME, 'npm'));
  return roots.filter((root) => isDir(root));
}

/** Candidate global install prefixes. */
function globalPrefixes() {
  const prefixes = [];
  if (process.env.npm_config_prefix) prefixes.push(process.env.npm_config_prefix);
  if (process.env.PREFIX) prefixes.push(process.env.PREFIX);
  if (process.platform === 'win32' && process.env.APPDATA) prefixes.push(join(process.env.APPDATA, 'npm'));
  prefixes.push(join(homedir(), '.local', 'share', 'npm'));
  prefixes.push('/usr/local');
  prefixes.push('/usr');
  return prefixes.filter((prefix) => isDir(prefix));
}

/**
 * Locate the installed `@deepseek-ai/dsh` package.
 *
 * Two distinct paths come out of this and conflating them is a silent failure
 * waiting to happen, so both are returned explicitly:
 *
 * - `nodeModules` is the `node_modules` directory that physically contains the
 *   `@deepseek-ai/*` packages;
 * - `anchor` is the project root that *owns* that `node_modules` — the base for
 *   `join(anchor, 'node_modules', …)` lookups and for the upward walk a preset's
 *   package resolution performs.
 *
 * @param {string} dshHome - resolved harness home, or '' when unknown.
 * @param {string} [explicit] - value from `--install`.
 * @returns {{ found: boolean, anchor: string, nodeModules: string, packageDir: string, packageJson: any, version: string, binPath: string|null, candidates: Array<{path: string, source: string, ok: boolean}> }}
 */
export function locateInstall(dshHome, explicit) {
  const candidates = [];
  /** Normalize any candidate into `{ root, nodeModules }`. */
  const normalize = (path) => {
    const absolute = resolve(path);
    const base = absolute.split(/[\\/]/).pop()?.toLowerCase();
    if (base === 'node_modules') return { nodeModules: absolute, root: dirname(absolute) };
    return { nodeModules: join(absolute, 'node_modules'), root: absolute };
  };

  if (explicit) {
    const { root, nodeModules } = normalize(explicit);
    const ok = existsSync(join(nodeModules, '@deepseek-ai', 'dsh', 'package.json'));
    // An explicit `--install` is an instruction, not a hint: if it does not
    // resolve, saying so is the whole answer. Falling back to an
    // auto-discovered installation would silently verify a different one.
    if (!ok) {
      return {
        found: false,
        anchor: root,
        nodeModules,
        packageDir: '',
        packageJson: null,
        version: '',
        binPath: null,
        explicitFailed: true,
        candidates: [{ path: root, nodeModules, source: 'option --install', ok: false }],
      };
    }
    candidates.push({ path: root, nodeModules, source: 'option --install', ok: true });
  }
  for (const candidate of installAnchorCandidates(dshHome)) {
    const { root, nodeModules } = normalize(candidate.path);
    candidates.push({
      path: root,
      nodeModules,
      source: candidate.source,
      ok: existsSync(join(nodeModules, '@deepseek-ai', 'dsh', 'package.json')),
    });
  }

  const hit = candidates.find((c) => c.ok);
  if (!hit) {
    return {
      found: false, anchor: '', nodeModules: '', packageDir: '', packageJson: null, version: '', binPath: null, candidates,
    };
  }

  const packageDir = join(hit.nodeModules, '@deepseek-ai', 'dsh');
  const packageJson = readJsonOrNull(join(packageDir, 'package.json'));
  const bin = packageJson?.bin;
  const binRel = typeof bin === 'string' ? bin : bin?.dsh ?? null;
  const binPath = binRel ? join(packageDir, binRel) : null;

  return {
    found: true,
    anchor: hit.path,
    nodeModules: hit.nodeModules,
    packageDir,
    packageJson,
    version: packageJson?.version ?? '',
    binPath: binPath && existsSync(binPath) ? binPath : null,
    candidates,
  };
}

/**
 * Resolve the `dsh` launcher command line for probe execution.
 *
 * Preference order: an explicit `--dsh-bin`, the installed package's own
 * `bin/dsh.js`, then the `.bin` shim beside it, then the plain `dsh` name on
 * `PATH`. Returning a descriptor (rather than a bare string) lets the caller
 * report which one it used.
 *
 * @param {{ nodeModules: string, packageDir: string, binPath: string|null }} install
 * @param {string} [explicit]
 * @returns {{ command: string, args: string[], source: string, kind: 'node-script'|'path' }}
 */
export function resolveDshCommand(install, explicit) {
  if (explicit) {
    return { command: explicit, args: [], source: 'option --dsh-bin', kind: 'path' };
  }
  if (install?.binPath) {
    return { command: process.execPath, args: [install.binPath], source: 'installed package bin', kind: 'node-script' };
  }
  const shim = install?.nodeModules
    ? join(install.nodeModules, '.bin', process.platform === 'win32' ? 'dsh.cmd' : 'dsh')
    : null;
  if (shim && existsSync(shim)) {
    return { command: shim, args: [], source: 'node_modules/.bin', kind: 'path' };
  }
  return { command: 'dsh', args: [], source: 'PATH', kind: 'path' };
}

/** Human-readable one-line location summary for report headers. */
export function describeLocation(location) {
  return `${shortPath(location.path)} (${location.source})`;
}
