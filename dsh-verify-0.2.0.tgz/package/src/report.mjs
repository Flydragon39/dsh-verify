/**
 * Report rendering: Markdown, JSON and JUnit (plan §2's output contract).
 *
 * The plan is emphatic that the whole verification is one table being filled in
 * — every item one row, every row five fields, no nested reports and no
 * redundant prose. Markdown therefore *is* the report; JSON is the same table
 * for machines, and JUnit is the same table for CI.
 *
 * @module dsh-verify/report
 */

import { STATUS } from './ladder.mjs';

/** Exit codes, so CI can branch on the verdict. */
export const EXIT = Object.freeze({
  PASS: 0,
  FINDINGS: 1,
  BLOCKED: 2,
});

/**
 * The single verdict line (plan §8's `VERDICT:` summary).
 *
 * A `deferred` UNKNOWN is reported in a trailing note rather than as a verdict
 * component: the plan's four-valued verdict would otherwise read `N UNKNOWN`
 * for every static run purely because mount behaviour was not probed, which
 * tells the reader nothing about the harness.
 *
 * @param {any} summary
 * @returns {string}
 */
export function verdictLine(summary) {
  if (summary.blocked) return `VERDICT: BLOCKED — ${summary.blockedReason}`;
  const deferred = summary.deferred > 0 ? ` (${summary.deferred} row(s) deferred — rerun with --probe)` : '';
  if (summary.failed === 0 && summary.degraded === 0 && summary.unknown === 0) return `VERDICT: ALL PASS${deferred}`;
  const parts = [];
  if (summary.failed > 0) parts.push(`${summary.failed} FAILED`);
  if (summary.degraded > 0) parts.push(`${summary.degraded} DEGRADED`);
  if (summary.unknown > 0) parts.push(`${summary.unknown} UNKNOWN`);
  return `VERDICT: ${parts.join(' | ')}${deferred}`;
}

/** Exit code for a run. */
export function exitCodeFor(summary) {
  if (summary.blocked) return EXIT.BLOCKED;
  return summary.failed > 0 || summary.degraded > 0 ? EXIT.FINDINGS : EXIT.PASS;
}

const TABLE_HEADER = '| item | type | status | layer | evidence |';
const TABLE_RULE = '|---|---|---|---|---|';

/** Escape a value for a Markdown table cell. */
function cell(value) {
  return String(value ?? '')
    .replace(/\|/g, '\\|')
    .replace(/\r?\n/g, '<br>')
    .trim();
}

/**
 * Render the full Markdown report.
 *
 * @param {any} result - the `verify()` return value.
 * @param {{ now?: Date }} [options]
 * @returns {string}
 */
export function renderMarkdown(result, options = {}) {
  const now = options.now ?? new Date();
  const out = [];
  const { environment, summary } = result;

  out.push('# DSH plugin & mode integrity report');
  out.push('');
  out.push(`- **Generated**: ${now.toISOString()}`);
  out.push(`- **Harness home**: \`${environment.dshHome}\` (${environment.dshHomeSource})`);
  out.push(`- **Install anchor**: \`${environment.installAnchor || '<not found>'}\``);
  out.push(`- **DSH version**: \`${environment.dshVersion || 'unknown'}\`${environment.dshVersionSource ? ` (${environment.dshVersionSource})` : ''}`);
  out.push(`- **Mode**: ${result.options.mode}${result.options.probe ? ' + mount probe' : ''}`);
  out.push('');
  out.push('> External, read-only verification. This tool never loads DSH code, never imports a plugin into its own process, and never writes to the harness configuration.');
  out.push('');

  if (summary.blocked) {
    out.push('## BLOCKED');
    out.push('');
    out.push(`**${summary.blockedReason}**`);
    out.push('');
    out.push('The environment guard failed, so no plugin or mode was inspected. Per the plan, a blocked guard terminates the run rather than expanding into a platform health check.');
    for (const probe of environment.guardProbes) {
      out.push(`- ${probe.ok ? 'ok' : 'FAILED'} — ${probe.label}: ${probe.detail}`);
    }
    out.push('');
    out.push(`\`\`\`\n${result.budget.summaryLine}\n\`\`\``);
    return out.join('\n');
  }

  for (const table of result.profiles) {
    out.push(`## Profile \`${table.profile}\``);
    out.push('');
    if (!table.composition.ok) {
      out.push(`Composition failed: ${table.composition.error}`);
      out.push('');
      continue;
    }
    out.push(`- Bundles: ${table.composition.bundleNames.map((b) => `\`${b}\``).join(' → ')}`);
    out.push(`- Composed rows: ${table.composition.order.length}`);
    out.push(table.includePlatform
      ? '- Scope: every composed row (`--all`)'
      : `- Scope: ${table.rows.length > 0 ? 'the rows you installed' : 'nothing to check'}; ${table.skippedPlatform} platform row(s) treated as the environment and not verified (pass \`--all\` to include them)`);
    out.push(`- Sources: ${table.composition.layers.filter((l) => l.exists).map((l) => `\`${l.label}\``).join(', ') || 'none'}`);
    out.push('');
    // Composition problems are report rows (see verify.mjs), so they already
    // appear under Findings and in the full table. Printing them a second time
    // here would give the same fact two shapes and invite them to drift.

    const findings = table.rows.filter((r) => r.status !== STATUS.PASS && r.status !== STATUS.PASS_MOUNTED && r.detail?.discoveryGap !== true);
    const notes = table.rows.filter((r) => r.detail?.discoveryGap === true);
    out.push(`### Verdict: ${verdictLine(table.summary).replace('VERDICT: ', '')}`);
    out.push('');
    out.push(`- ${table.verdicts.pass} PASS`);
    out.push(`- ${table.verdicts.passMounted} PASS (mounted only)`);
    out.push(`- ${table.verdicts.degraded} DEGRADED`);
    out.push(`- ${table.verdicts.failed} FAILED`);
    out.push(`- ${table.verdicts.unknown} UNKNOWN`);
    out.push('');

    if (notes.length > 0) {
      out.push('### Notes');
      out.push('');
      for (const note of notes) out.push(`- **${note.item}**: ${note.evidence}`);
      out.push('');
    }

    if (findings.length > 0) {
      out.push('### Findings');
      out.push('');
      out.push(TABLE_HEADER);
      out.push(TABLE_RULE);
      for (const item of findings) out.push(`| ${cell(item.item)} | ${cell(item.type)} | ${cell(item.status)} | ${cell(item.layer)} | ${cell(item.evidence)} |`);
      out.push('');
    }

    out.push('### Full table');
    out.push('');
    out.push(TABLE_HEADER);
    out.push(TABLE_RULE);
    for (const item of table.rows) out.push(`| ${cell(item.item)} | ${cell(item.type)} | ${cell(item.status)} | ${cell(item.layer)} | ${cell(item.evidence)} |`);
    out.push('');
  }

  if (result.modes) {
    out.push('## Modes (agent presets)');
    out.push('');
    out.push(`- Default mode: \`${result.modes.defaultId ?? '<unresolved>'}\``);
    out.push('- Roots, in precedence order:');
    for (const root of result.modes.roots) {
      out.push(`  - ${root.exists ? '' : '**missing** '}\`${root.path}\` (${root.trust}, ${root.source})`);
    }
    out.push('');
    if (result.modes.problems.length > 0) {
      out.push('### Discovery notes');
      out.push('');
      for (const problem of result.modes.problems) {
        out.push(problem.kind === 'id-skipped'
          ? `- skipped: \`${problem.path}\` — directory name is not a valid preset id (${/^[a-z0-9][a-z0-9-]*$/.source})`
          : `- missing root: \`${problem.path}\` (${problem.source})`);
      }
      out.push('');
    }
    out.push(`### Verdict: ${verdictLine(result.modes.summary).replace('VERDICT: ', '')}`);
    out.push('');
    out.push(TABLE_HEADER);
    out.push(TABLE_RULE);
    for (const item of result.modes.rows) out.push(`| ${cell(item.item)} | ${cell(item.type)} | ${cell(item.status)} | ${cell(item.layer)} | ${cell(item.evidence)} |`);
    out.push('');
  }

  if (result.diff) {
    out.push('## Baseline diff');
    out.push('');
    if (result.diff.isEmpty) {
      out.push('No differences from the baseline.');
    } else {
      out.push(`${result.diff.changes.length} difference(s):`);
      out.push('');
      out.push('| kind | item | detail |');
      out.push('|---|---|---|');
      for (const change of result.diff.changes) out.push(`| ${cell(change.kind)} | ${cell(change.item)} | ${cell(change.detail)} |`);
    }
    out.push('');
  }

  out.push('## Summary');
  out.push('');
  out.push('```');
  out.push(verdictLine(summary));
  out.push(result.budget.summaryLine);
  if (result.budget.exhaustedBy) {
    out.push(`Budget exhausted by: ${result.budget.exhaustedBy.dimension} (limit ${result.budget.exhaustedBy.limit}) — every undecided item was left UNKNOWN.`);
  }
  out.push('```');
  out.push('');
  out.push('Status meanings: `PASS` the contract is satisfied; `PASS(mounted)` the item registers nothing, so a successful mount is the entire contract; `DEGRADED` something is provably wrong but the item still works; `FAILED` the item cannot work; `UNKNOWN` the file alone cannot decide — needs a human or a deeper backend, and is deliberately not treated as a failure.');
  out.push('');
  return out.join('\n');
}

/** Render the machine-readable report. */
export function renderJson(result) {
  return `${JSON.stringify(serialize(result), null, 2)}\n`;
}

/** Strip non-serializable values (Maps, functions) from a result. */
function serialize(result) {
  return {
    tool: result.tool,
    generatedAt: new Date().toISOString(),
    environment: result.environment,
    options: result.options,
    budget: result.budget,
    summary: result.summary,
    verdict: verdictLine(result.summary),
    profiles: result.profiles.map((table) => ({
      profile: table.profile,
      composition: {
        ok: table.composition.ok,
        error: table.composition.error ?? null,
        bundles: table.composition.bundleNames,
        rowOrder: table.composition.order,
        layers: table.composition.layers.map((l) => ({ label: l.label, path: l.path, exists: l.exists, error: l.error ? String(l.error) : null })),
        problems: table.composition.problems,
      },
      summary: table.summary,
      verdicts: table.verdicts,
      rows: table.rows,
    })),
    modes: result.modes
      ? {
        defaultId: result.modes.defaultId,
        roots: result.modes.roots,
        problems: result.modes.problems,
        summary: result.modes.summary,
        verdicts: result.modes.verdicts,
        rows: result.modes.rows,
      }
      : null,
    diff: result.diff ?? null,
  };
}

/**
 * Render a JUnit XML report, one test case per table row.
 *
 * Mapping: FAILED — `<failure>`, DEGRADED — `<failure type="degraded">`,
 * UNKNOWN — `<skipped>`. UNKNOWN maps to skipped rather than failed because
 * the plan makes it a first-class "not covered by this approach" state, and a
 * CI job that fails on it would train people to ignore it.
 */
export function renderJUnit(result) {
  const escape = (value) => String(value ?? '')
    .replace(/&/g, '&amp;')
    .replace(/</g, '&lt;')
    .replace(/>/g, '&gt;')
    .replace(/"/g, '&quot;')
    .replace(/'/g, '&apos;');

  const cases = [];
  let failures = 0;
  let skipped = 0;

  const pushCases = (suiteName, rows) => {
    for (const item of rows) {
      const name = escape(`${suiteName} :: ${item.item} [${item.layer}]`);
      const details = escape(item.evidence);
      if (item.status === STATUS.FAILED) {
        failures += 1;
        cases.push(`    <testcase name="${name}" classname="${escape(suiteName)}"><failure type="failed" message="${details}">${details}</failure></testcase>`);
      } else if (item.status === STATUS.DEGRADED) {
        failures += 1;
        cases.push(`    <testcase name="${name}" classname="${escape(suiteName)}"><failure type="degraded" message="${details}">${details}</failure></testcase>`);
      } else if (item.status === STATUS.UNKNOWN) {
        skipped += 1;
        cases.push(`    <testcase name="${name}" classname="${escape(suiteName)}"><skipped message="${details}"/></testcase>`);
      } else {
        cases.push(`    <testcase name="${name}" classname="${escape(suiteName)}"/>`);
      }
    }
  };

  if (result.summary.blocked) {
    pushCases('dsh-verify.environment', [{
      item: 'environment guard',
      layer: 'L0',
      status: STATUS.FAILED,
      evidence: result.summary.blockedReason,
    }]);
  } else {
    for (const table of result.profiles) pushCases(`dsh-verify.${table.profile}`, table.rows);
    if (result.modes) pushCases('dsh-verify.modes', result.modes.rows);
  }

  const total = cases.length;
  const out = [
    '<?xml version="1.0" encoding="UTF-8"?>',
    `<testsuites name="dsh-verify" tests="${total}" failures="${failures}" skipped="${skipped}">`,
    `  <testsuite name="dsh-verify" tests="${total}" failures="${failures}" skipped="${skipped}">`,
    ...cases,
    '  </testsuite>',
    '</testsuites>',
    '',
  ];
  return out.join('\n');
}

/**
 * Render the compact terminal report: the plan's `VERDICT:`/`BUDGET:` block
 * plus the non-PASS rows, which is what a human runs after an update.
 */
export function renderText(result) {
  const out = [];
  const { summary } = result;

  out.push(`dsh-verify — ${result.environment.dshHome} · DSH ${result.environment.dshVersion || 'unknown'} · ${result.options.mode}`);
  out.push('');

  if (summary.blocked) {
    out.push(`VERDICT: BLOCKED — ${summary.blockedReason}`);
    out.push('');
    for (const probe of result.environment.guardProbes) out.push(`  ${probe.ok ? 'ok  ' : 'FAIL'} ${probe.label}: ${probe.detail}`);
    out.push('');
    out.push(result.budget.summaryLine);
    return out.join('\n');
  }

  const findings = [];
  const notes = [];
  for (const table of result.profiles) {
    for (const r of table.rows) {
      // A row that says "this run could not look" is a note, not a finding:
      // the modes ladder has printed its discovery gaps this way since the
      // first release, and the plugins gap now follows the same rule.
      if (r.detail?.discoveryGap === true) notes.push(r);
      else if (r.status !== STATUS.PASS && r.status !== STATUS.PASS_MOUNTED && r.detail?.deferred !== true) findings.push(r);
    }
  }
  if (result.modes) {
    for (const r of result.modes.rows) {
      // A discovery gap says "this run could not look", not "this is broken".
      // It is reported, but it must not be counted as a defect the reader is
      // expected to act on — no flag makes it go away.
      if (r.detail?.discoveryGap === true) notes.push(r);
      else if (r.status !== STATUS.PASS && r.status !== STATUS.PASS_MOUNTED && r.detail?.deferred !== true) findings.push(r);
    }
  }

  if (findings.length === 0) {
    out.push(result.summary.failed + result.summary.degraded + result.summary.unknown === 0
      ? 'No findings.'
      : 'No findings beyond deferred checks.');
  } else {
    const width = Math.min(46, Math.max(...findings.map((f) => f.item.length), 4));
    for (const item of findings) {
      out.push(`  ${item.status.padEnd(9)} ${item.layer.padEnd(5)} ${item.item.slice(0, width).padEnd(width)}  ${item.evidence}`);
    }
  }
  if (notes.length > 0) {
    out.push('');
    for (const note of notes) out.push(`  NOTE  ${note.item}: ${note.evidence}`);
  }
  // Discovery notes are not findings — a missing optional root is normal — but
  // a preset directory that DSH silently ignores must not be invisible either.
  // Only `id-skipped` is printed here: a root that does not exist is expected on
  // a deployment with no presets, and repeating it on every run is noise.
  const skippedIds = result.modes?.problems.filter((p) => p.kind === 'id-skipped') ?? [];
  if (skippedIds.length > 0) {
    if (notes.length === 0) out.push('');
    for (const problem of skippedIds) {
      out.push(`  NOTE  modes: ${problem.path} is not a valid preset id, so DSH will never load it`);
    }
  }
  out.push('');
  if (result.diff) {
    if (result.diff.error) {
      out.push(`Baseline diff unavailable: ${result.diff.error}`);
    } else if (result.diff.isEmpty) {
      out.push('Baseline diff: no changes since the snapshot.');
    } else {
      out.push(`Baseline diff: ${result.diff.changes.length} change(s)`);
      for (const change of result.diff.changes.slice(0, 12)) out.push(`  ${change.kind.padEnd(20)} ${change.item} — ${change.detail}`);
      if (result.diff.changes.length > 12) out.push(`  … and ${result.diff.changes.length - 12} more (see the Markdown or JSON report)`);
    }
    out.push('');
  }

  out.push(verdictLine(summary));
  out.push(result.budget.summaryLine);
  if (result.budget.exhaustedBy) {
    out.push(`Budget exhausted by ${result.budget.exhaustedBy.dimension} (limit ${result.budget.exhaustedBy.limit}); undecided items were left UNKNOWN.`);
  }
  return out.join('\n');
}

/** Dispatch to the requested format. */
export function render(result, format) {
  switch (format) {
    case 'json': return renderJson(result);
    case 'junit': return renderJUnit(result);
    case 'text': return renderText(result);
    case 'markdown':
    default: return renderMarkdown(result);
  }
}
