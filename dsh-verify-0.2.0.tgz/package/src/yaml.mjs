/**
 * Minimal, dependency-free YAML reader for DeepSeek Harness configuration.
 *
 * Scope: the YAML subset DSH actually writes and ships — block mappings and
 * sequences, flow collections, quoted and plain scalars, block scalars
 * (`|` / `>` with chomping and explicit indentation indicators), comments,
 * document markers, anchors/aliases with merge keys, and custom tags.
 *
 * Deliberate design decisions:
 *
 * - A custom tag such as DSH's `!!js` is NEVER evaluated. It is returned as a
 *   frozen `{ __tag, __expr }` marker so callers can render or reason about the
 *   expression without any risk of executing it. A verifier must be able to
 *   read a hostile config without running it.
 * - Timestamps, binary, sexagesimals and complex keys are intentionally not
 *   interpreted; they arrive as strings or throw. Guessing is worse than
 *   reporting.
 * - Parse failures throw `YamlError` carrying the 1-based line and column, so a
 *   caller can put a precise location in a report.
 *
 * @module dsh-verify/yaml
 */

/** Marker returned for any tag this reader does not interpret (e.g. `!!js`). */
export class TaggedValue {
  constructor(tag, expr) {
    this.__tag = tag;
    this.__expr = expr;
    Object.freeze(this);
  }
  toJSON() {
    return { __tag: this.__tag, __expr: this.__expr };
  }
  toString() {
    return `${this.__tag} ${this.__expr}`;
  }
}

/** Parse failure with a precise source location. */
export class YamlError extends Error {
  constructor(message, line, column) {
    super(`${message} (line ${line}, column ${column})`);
    this.name = 'YamlError';
    this.line = line;
    this.column = column;
  }
}

const TRUE = new Set(['true', 'True', 'TRUE']);
const FALSE = new Set(['false', 'False', 'FALSE']);
const NULLS = new Set(['null', 'Null', 'NULL', '~', '']);
const MAX_ALIAS_DEPTH = 64;

/** Split into lines, tolerating CRLF and CR, and strip a leading BOM. */
function splitLines(text) {
  const normalized = text.charCodeAt(0) === 0xfeff ? text.slice(1) : text;
  return normalized.split(/\r\n|\r|\n/);
}

function indentOf(line) {
  let n = 0;
  while (n < line.length && line[n] === ' ') n += 1;
  return n;
}

function isBlank(line) {
  return line.trim() === '';
}

function isComment(line) {
  return line.trimStart().startsWith('#');
}

/**
 * Strip a trailing comment from a scalar region, honouring quotes.
 * A `#` only starts a comment at the start of the region or after whitespace.
 */
function stripComment(text) {
  let quote = null;
  for (let i = 0; i < text.length; i += 1) {
    const ch = text[i];
    if (quote === "'") {
      if (ch === "'" && text[i + 1] === "'") i += 1;
      else if (ch === "'") quote = null;
      continue;
    }
    if (quote === '"') {
      if (ch === '\\') i += 1;
      else if (ch === '"') quote = null;
      continue;
    }
    if (ch === "'" || ch === '"') {
      quote = ch;
      continue;
    }
    if (ch === '#' && (i === 0 || /\s/.test(text[i - 1]))) return text.slice(0, i);
  }
  return text;
}

/** True when the region carries a trailing comment. */
function hasComment(region) {
  return stripComment(region) !== region;
}

/**
 * Fold a multi-line plain scalar's continuation lines, the way YAML does:
 * one line break becomes a space, a run of n breaks becomes n-1 newlines.
 *
 * A line belongs to the scalar when it is indented deeper than `foldIndent`
 * (the parent's indentation), is neither blank nor a comment, and does not
 * read like another `key: value` — in YAML a plain scalar cannot contain
 * ": ", so such a line ends the scalar and the caller reports it. A trailing
 * comment ends the scalar too, matching the reference parser.
 *
 * The reader advances past every line consumed here.
 */
function foldPlainContinuation(reader, first, foldIndent) {
  let text = first;
  for (;;) {
    let probe = reader.i;
    let blanks = 0;
    while (probe < reader.lines.length && isBlank(reader.lines[probe])) { probe += 1; blanks += 1; }
    if (probe >= reader.lines.length) break;
    const line = reader.lines[probe];
    if (isComment(line)) break;
    if (indentOf(line) <= foldIndent) break;
    const region = line.slice(indentOf(line));
    const cut = stripComment(region).trimEnd();
    if (cut === '') break;
    if (findKeyColon(cut) !== -1) break;
    text += (blanks === 0 ? ' ' : '\n'.repeat(blanks)) + cut;
    reader.i = probe + 1;
    if (hasComment(region)) break;
  }
  return text;
}

/** Index of the `:` that separates key from value, or -1. Honours quotes/flow. */
function findKeyColon(text) {
  let quote = null;
  let depth = 0;
  for (let i = 0; i < text.length; i += 1) {
    const ch = text[i];
    if (quote === "'") {
      if (ch === "'" && text[i + 1] === "'") i += 1;
      else if (ch === "'") quote = null;
      continue;
    }
    if (quote === '"') {
      if (ch === '\\') i += 1;
      else if (ch === '"') quote = null;
      continue;
    }
    if (ch === "'" || ch === '"') {
      quote = ch;
      continue;
    }
    if (ch === '[' || ch === '{') depth += 1;
    else if (ch === ']' || ch === '}') depth -= 1;
    else if (ch === '#' && i > 0 && /\s/.test(text[i - 1])) return -1;
    else if (ch === ':' && depth === 0) {
      const next = text[i + 1];
      if (next === undefined || next === ' ' || next === '\t') return i;
    }
  }
  return -1;
}

function unquoteDouble(body, line, column) {
  let out = '';
  for (let i = 0; i < body.length; i += 1) {
    const ch = body[i];
    if (ch !== '\\') {
      out += ch;
      continue;
    }
    const esc = body[i + 1];
    i += 1;
    switch (esc) {
      case 'n': out += '\n'; break;
      case 't': out += '\t'; break;
      case 'r': out += '\r'; break;
      case '0': out += '\0'; break;
      case 'b': out += '\b'; break;
      case 'f': out += '\f'; break;
      case '"': out += '"'; break;
      case '/': out += '/'; break;
      case '\\': out += '\\'; break;
      case ' ': out += ' '; break;
      case 'x': out += String.fromCharCode(parseInt(body.slice(i + 1, i + 3), 16)); i += 2; break;
      case 'u': out += String.fromCharCode(parseInt(body.slice(i + 1, i + 5), 16)); i += 4; break;
      case 'U': out += String.fromCodePoint(parseInt(body.slice(i + 1, i + 9), 16)); i += 8; break;
      default:
        throw new YamlError(`unsupported escape "\\${esc}"`, line, column);
    }
  }
  return out;
}

/** Interpret a plain (unquoted) scalar token. */
function plainScalar(token) {
  if (NULLS.has(token)) return null;
  if (TRUE.has(token)) return true;
  if (FALSE.has(token)) return false;
  if (/^[+-]?\d+$/.test(token)) {
    const n = Number(token);
    return Number.isSafeInteger(n) ? n : token;
  }
  if (/^[+-]?(\d+\.\d*|\.\d+|\d+)([eE][+-]?\d+)?$/.test(token) && /[.eE]/.test(token)) {
    const n = Number(token);
    if (Number.isFinite(n)) return n;
  }
  if (/^0x[0-9a-fA-F]+$/.test(token)) return parseInt(token, 16);
  if (/^0o[0-7]+$/.test(token)) return parseInt(token.slice(2), 8);
  return token;
}

/**
 * Parse one scalar region (everything after `key:` or `-`) into a value.
 * Handles quoted strings, flow collections, tags and plain scalars.
 *
 * `foldIndent` is the indentation of the block that owns the value. It is only
 * used for plain scalars: YAML lets those continue on following lines that are
 * indented deeper than that block, which is how DSH's own presets write a long
 * `description`. `null` disables folding.
 */
function parseInline(reader, text, line, column, ctxIndent, foldIndent = null) {
  let rest = text;
  let tag = null;

  const tagMatch = /^(![^\s]*)\s*/.exec(rest);
  if (tagMatch) {
    tag = tagMatch[1];
    rest = rest.slice(tagMatch[0].length);
  }

  if (rest === '') {
    const node = parseBlock(reader, ctxIndent + 1);
    return tag ? new TaggedValue(tag, node) : node;
  }

  const first = rest[0];
  if (first === '|' || first === '>') {
    const value = readBlockScalar(reader, rest, ctxIndent, line, column);
    return tag ? new TaggedValue(tag, value) : value;
  }

  if (first === '[' || first === '{') {
    const value = parseFlow(reader, rest, line, column);
    return tag ? new TaggedValue(tag, value) : value;
  }

  if (first === '&') {
    const m = /^&(\S+)\s*/.exec(rest);
    const name = m[1];
    rest = rest.slice(m[0].length);
    const value = rest === '' ? parseBlock(reader, ctxIndent + 1) : parseInline(reader, rest, line, column, ctxIndent, foldIndent);
    reader.anchors.set(name, value);
    return value;
  }

  if (first === '*') {
    const name = rest.slice(1).trim();
    if (!reader.anchors.has(name)) throw new YamlError(`unknown alias *${name}`, line, column);
    return reader.anchors.get(name);
  }

  let value;
  if (first === '"') {
    if (!rest.endsWith('"') || rest.length < 2) throw new YamlError('unterminated double-quoted scalar', line, column);
    value = unquoteDouble(rest.slice(1, -1), line, column);
  } else if (first === "'") {
    if (!rest.endsWith("'") || rest.length < 2) throw new YamlError('unterminated single-quoted scalar', line, column);
    value = rest.slice(1, -1).replace(/''/g, "'");
  } else {
    const folded = foldIndent === null ? rest : foldPlainContinuation(reader, rest, foldIndent);
    value = plainScalar(folded);
  }
  return tag ? new TaggedValue(tag, value) : value;
}

/**
 * Read a block scalar (`|` literal or `>` folded) whose header is `header`.
 * `ctxIndent` is the indentation of the line that introduced it.
 */
function readBlockScalar(reader, header, ctxIndent, line, column) {
  const m = /^([|>])([+-]?)(\d*)([+-]?)\s*$/.exec(header);
  if (!m) throw new YamlError(`invalid block scalar header "${header}"`, line, column);
  const style = m[1];
  const chomp = m[2] || m[4] || '';
  const explicitIndent = m[3] === '' ? null : Number(m[3]);

  const body = [];
  let blockIndent = explicitIndent === null ? null : ctxIndent + explicitIndent;
  let lastNonBlank = -1;

  while (reader.i < reader.lines.length) {
    const raw = reader.lines[reader.i];
    if (isBlank(raw)) {
      body.push('');
      reader.i += 1;
      continue;
    }
    const ind = indentOf(raw);
    if (blockIndent === null) {
      if (ind <= ctxIndent) break;
      blockIndent = ind;
    }
    if (ind < blockIndent) break;
    body.push(raw.slice(blockIndent));
    lastNonBlank = body.length - 1;
    reader.i += 1;
  }

  const kept = chomp === '+' ? body : body.slice(0, lastNonBlank + 1);
  let text;
  if (style === '|') {
    text = kept.join('\n');
  } else {
    const out = [];
    for (let i = 0; i < kept.length; i += 1) {
      const cur = kept[i];
      const next = kept[i + 1];
      if (cur === '') { out.push('\n'); continue; }
      if (next === undefined) { out.push(cur); continue; }
      if (next === '') { out.push(cur); continue; }
      if (/^\s/.test(next)) { out.push(`${cur}\n`); continue; }
      out.push(`${cur} `);
    }
    text = out.join('');
  }
  if (chomp !== '-' && text !== '') text += '\n';
  if (chomp === '-' && text.endsWith('\n')) text = text.replace(/\n+$/, '');
  return text;
}

/** Parse a flow collection starting at `text[0]`, consuming further lines if needed. */
function parseFlow(reader, text, line, column) {
  let buffer = text;
  let depth = 0;
  let quote = null;
  let end = -1;

  for (;;) {
    depth = 0;
    quote = null;
    end = -1;
    for (let i = 0; i < buffer.length; i += 1) {
      const ch = buffer[i];
      if (quote === "'") {
        if (ch === "'" && buffer[i + 1] === "'") i += 1;
        else if (ch === "'") quote = null;
        continue;
      }
      if (quote === '"') {
        if (ch === '\\') i += 1;
        else if (ch === '"') quote = null;
        continue;
      }
      if (ch === "'" || ch === '"') { quote = ch; continue; }
      if (ch === '[' || ch === '{') depth += 1;
      else if (ch === ']' || ch === '}') {
        depth -= 1;
        if (depth === 0) { end = i; break; }
      }
    }
    if (end !== -1) break;
    if (reader.i >= reader.lines.length) throw new YamlError('unterminated flow collection', line, column);
    buffer += ` ${reader.lines[reader.i].trim()}`;
    reader.i += 1;
  }

  const parser = { s: buffer, i: 0, line, column };
  const value = flowValue(parser);
  skipFlowSpace(parser);
  if (parser.i < parser.s.length && parser.s[parser.i] !== ',') {
    // Trailing content after the collection is a parse error; be strict.
    throw new YamlError(`unexpected content after flow collection: "${parser.s.slice(parser.i)}"`, line, column);
  }
  return value;
}

function skipFlowSpace(p) {
  while (p.i < p.s.length && /\s/.test(p.s[p.i])) p.i += 1;
}

function flowValue(p) {
  skipFlowSpace(p);
  const ch = p.s[p.i];
  if (ch === '[') return flowSeq(p);
  if (ch === '{') return flowMap(p);
  if (ch === '"' || ch === "'") {
    const q = ch;
    let out = '';
    p.i += 1;
    while (p.i < p.s.length) {
      const c = p.s[p.i];
      if (q === '"' && c === '\\') { out += p.s[p.i] + p.s[p.i + 1]; p.i += 2; continue; }
      if (c === q) {
        if (q === "'" && p.s[p.i + 1] === "'") { out += "'"; p.i += 2; continue; }
        p.i += 1;
        return q === '"' ? unquoteDouble(out, p.line, p.column) : out.replace(/''/g, "'");
      }
      out += c;
      p.i += 1;
    }
    throw new YamlError('unterminated quoted scalar in flow collection', p.line, p.column);
  }
  let token = '';
  while (p.i < p.s.length) {
    const ch = p.s[p.i];
    if (ch === ',' || ch === '[' || ch === ']' || ch === '{' || ch === '}') break;
    // In flow context a plain scalar may contain ':' unless a space or a flow
    // indicator follows — `file:F:/x.tgz` is one token, `a: 1` is a pair.
    if (ch === ':' && (p.s[p.i + 1] === undefined || /[\s,\[\]{}]/.test(p.s[p.i + 1]))) break;
    token += ch;
    p.i += 1;
  }
  return plainScalar(token.trim());
}

function flowSeq(p) {
  p.i += 1;
  const out = [];
  skipFlowSpace(p);
  if (p.s[p.i] === ']') { p.i += 1; return out; }
  for (;;) {
    out.push(flowValue(p));
    skipFlowSpace(p);
    if (p.s[p.i] === ',') { p.i += 1; skipFlowSpace(p); if (p.s[p.i] === ']') { p.i += 1; return out; } continue; }
    if (p.s[p.i] === ']') { p.i += 1; return out; }
    throw new YamlError('malformed flow sequence', p.line, p.column);
  }
}

function flowMap(p) {
  p.i += 1;
  const out = {};
  skipFlowSpace(p);
  if (p.s[p.i] === '}') { p.i += 1; return out; }
  for (;;) {
    skipFlowSpace(p);
    const key = flowValue(p);
    skipFlowSpace(p);
    let value = null;
    if (p.s[p.i] === ':') {
      p.i += 1;
      value = flowValue(p);
    }
    out[String(key)] = value;
    skipFlowSpace(p);
    if (p.s[p.i] === ',') { p.i += 1; skipFlowSpace(p); if (p.s[p.i] === '}') { p.i += 1; return out; } continue; }
    if (p.s[p.i] === '}') { p.i += 1; return out; }
    throw new YamlError('malformed flow mapping', p.line, p.column);
  }
}

/** True when `line` opens a block sequence entry at column `indent`. */
function isSeqEntry(line, indent) {
  const rest = line.slice(indent);
  return rest === '-' || rest.startsWith('- ');
}

/** Parse the block node that begins at the current line, requiring >= `minIndent`. */
function parseBlock(reader, minIndent) {
  // Skip blank and comment-only lines to find the node's first real line.
  const save = reader.i;
  while (reader.i < reader.lines.length) {
    const line = reader.lines[reader.i];
    if (isBlank(line) || isComment(line)) { reader.i += 1; continue; }
    break;
  }
  if (reader.i >= reader.lines.length) { reader.i = save; return null; }
  const line = reader.lines[reader.i];
  const indent = indentOf(line);
  if (indent < minIndent) { reader.i = save; return null; }

  if (isSeqEntry(line, indent)) return parseSequence(reader, indent);
  if (findKeyColon(stripComment(line)) !== -1) return parseMapping(reader, indent);
  // At the document root the owning block's indent is -1, so a plain scalar
  // may continue on column-0 lines (the reference parser folds "foo\nbar").
  return parseScalarLine(reader, indent, minIndent - 1);
}

function parseScalarLine(reader, indent, foldIndent = indent) {
  const line = reader.lines[reader.i];
  const raw = line.slice(indent);
  const text = stripComment(raw).trimEnd();
  reader.i += 1;
  return parseInline(reader, text, reader.i, indent + 1, indent, hasComment(raw) ? null : foldIndent);
}

function parseSequence(reader, indent) {
  const out = [];
  while (reader.i < reader.lines.length) {
    const line = reader.lines[reader.i];
    if (isBlank(line) || isComment(line)) { reader.i += 1; continue; }
    const ind = indentOf(line);
    if (ind < indent) break;
    if (ind > indent) throw new YamlError('unexpected indentation in sequence', reader.i + 1, ind + 1);
    if (!isSeqEntry(line, ind)) break;

    const rest = line.slice(ind + 1);
    const contentOffset = ind + 1 + (rest.length - rest.trimStart().length);
    const content = stripComment(rest).trimEnd();

    if (content.trim() === '') {
      reader.i += 1;
      out.push(parseBlock(reader, indent + 1));
      continue;
    }

    const colon = findKeyColon(content);
    if (colon === -1) {
      reader.i += 1;
      out.push(parseInline(reader, content.trim(), reader.i, contentOffset + 1, contentOffset,
        hasComment(rest) ? null : ind));
      continue;
    }
    // A mapping that starts on the dash line: its keys continue at contentOffset.
    out.push(parseMappingInline(reader, content, contentOffset, hasComment(rest)));
  }
  return out;
}

/**
 * Parse a mapping whose first key/value pair is already on the current line.
 *
 * `firstHasComment` is true when the dash line carried a trailing comment; a
 * comment ends a plain scalar in YAML, so such a value must not fold.
 */
function parseMappingInline(reader, firstLineContent, indent, firstHasComment = false) {
  const map = {};
  let pendingLine = firstLineContent;
  let pendingIndent = indent;
  let pendingHasComment = firstHasComment;

  for (;;) {
    const text = stripComment(pendingLine).trimEnd();
    if (text.trim() !== '') {
      const colon = findKeyColon(text);
      if (colon === -1) throw new YamlError('expected "key: value" in mapping', reader.i + 1, pendingIndent + 1);
      let keyToken = text.slice(0, colon).trim();
      if (keyToken.startsWith('? ')) keyToken = keyToken.slice(2).trim();
      const key = readKey(keyToken, reader.i + 1, pendingIndent + 1);
      const valueText = text.slice(colon + 1).trim();
      reader.i += 1;
      assignKey(map, key, parseInline(reader, valueText, reader.i, colon + 1, pendingIndent,
        pendingHasComment ? null : pendingIndent));
    } else {
      reader.i += 1;
    }

    // Find the next line that belongs to this mapping.
    let probe = reader.i;
    while (probe < reader.lines.length && (isBlank(reader.lines[probe]) || isComment(reader.lines[probe]))) probe += 1;
    if (probe >= reader.lines.length) { reader.i = probe; break; }
    const next = reader.lines[probe];
    const ind = indentOf(next);
    if (ind < indent) { reader.i = probe; break; }
    if (ind > indent) throw new YamlError('unexpected indentation in mapping', probe + 1, ind + 1);
    if (isSeqEntry(next, ind)) { reader.i = probe; break; }
    if (findKeyColon(stripComment(next)) === -1) { reader.i = probe; break; }
    pendingLine = next.slice(ind);
    pendingHasComment = hasComment(pendingLine);
    pendingIndent = ind;
    reader.i = probe;
  }
  return map;
}

function parseMapping(reader, indent) {
  const map = {};
  let first = true;
  for (;;) {
    let probe = reader.i;
    while (probe < reader.lines.length && (isBlank(reader.lines[probe]) || isComment(reader.lines[probe]))) probe += 1;
    if (probe >= reader.lines.length) { reader.i = probe; break; }
    const line = reader.lines[probe];
    const ind = indentOf(line);
    if (ind < indent) { reader.i = probe; break; }
    if (ind > indent) throw new YamlError('unexpected indentation in mapping', probe + 1, ind + 1);
    if (isSeqEntry(line, ind)) { reader.i = probe; break; }
    const raw = line.slice(ind);
    const text = stripComment(raw).trimEnd();
    const colon = findKeyColon(text);
    if (colon === -1) {
      if (first) throw new YamlError('expected "key: value"', probe + 1, ind + 1);
      reader.i = probe;
      break;
    }
    first = false;
    let keyToken = text.slice(0, colon).trim();
    if (keyToken.startsWith('? ')) keyToken = keyToken.slice(2).trim();
    const key = readKey(keyToken, probe + 1, ind + 1);
    const valueText = text.slice(colon + 1).trim();
    reader.i = probe + 1;
    // A plain value folds only when the line carries no comment (YAML ends a
    // plain scalar at a comment) and only onto lines deeper than this mapping.
    assignKey(map, key, parseInline(reader, valueText, probe + 1, colon + 1, ind, hasComment(raw) ? null : ind));
  }
  return map;
}

function readKey(token, line, column) {
  if (token.startsWith('"')) {
    if (!token.endsWith('"')) throw new YamlError('unterminated double-quoted key', line, column);
    return unquoteDouble(token.slice(1, -1), line, column);
  }
  if (token.startsWith("'")) {
    if (!token.endsWith("'")) throw new YamlError('unterminated single-quoted key', line, column);
    return token.slice(1, -1).replace(/''/g, "'");
  }
  return token;
}

function assignKey(map, key, value) {
  if (key === '<<') {
    const sources = Array.isArray(value) ? value : [value];
    for (const src of sources) {
      if (src && typeof src === 'object' && !Array.isArray(src)) {
        for (const [k, v] of Object.entries(src)) if (!(k in map)) map[k] = v;
      }
    }
    return;
  }
  map[key] = value;
}

/**
 * Parse a YAML document into JavaScript values.
 *
 * @param {string} text - the YAML source.
 * @param {{ all?: boolean }} [options] - `all: true` returns every document in a multi-document stream.
 * @returns {any} the parsed value (or an array of them when `all` is set).
 * @throws {YamlError} on malformed input, with the offending line and column.
 */
export function parseYaml(text, options = {}) {
  if (typeof text !== 'string') throw new TypeError('parseYaml expects a string');
  const lines = splitLines(text);
  const reader = { lines, i: 0, anchors: new Map() };
  const documents = [];

  // Leading document markers and directives.
  while (reader.i < lines.length) {
    const line = lines[reader.i];
    const trimmed = line.trim();
    if (trimmed === '' || trimmed.startsWith('#')) { reader.i += 1; continue; }
    if (trimmed.startsWith('%')) { reader.i += 1; continue; }
    if (trimmed === '---' || trimmed.startsWith('--- ')) {
      const inline = trimmed.slice(3).trim();
      reader.i += 1;
      if (inline !== '') documents.push(parseInline(reader, inline, reader.i, 1, 0));
      else documents.push(parseBlock(reader, 0));
      continue;
    }
    documents.push(parseBlock(reader, 0));
    break;
  }

  // Consume any further documents.
  while (reader.i < lines.length) {
    const trimmed = lines[reader.i].trim();
    if (trimmed === '') { reader.i += 1; continue; }
    if (trimmed.startsWith('#')) { reader.i += 1; continue; }
    if (trimmed === '...') { reader.i += 1; continue; }
    if (trimmed === '---' || trimmed.startsWith('--- ')) {
      const inline = trimmed.slice(3).trim();
      reader.i += 1;
      if (inline !== '') documents.push(parseInline(reader, inline, reader.i, 1, 0));
      else documents.push(parseBlock(reader, 0));
      continue;
    }
    throw new YamlError(`unexpected content after document end: "${trimmed}"`, reader.i + 1, indentOf(lines[reader.i]) + 1);
  }

  if (options.all) return documents;
  if (documents.length === 0) return null;
  return documents[0];
}

/**
 * Parse, returning `{ ok: true, value }` or `{ ok: false, error }` instead of
 * throwing. Callers that must record a parse failure in a report use this.
 *
 * @param {string} text - the YAML source.
 * @returns {{ ok: boolean, value?: any, error?: Error }}
 */
export function tryParseYaml(text) {
  try {
    return { ok: true, value: parseYaml(text) };
  } catch (error) {
    return { ok: false, error };
  }
}
