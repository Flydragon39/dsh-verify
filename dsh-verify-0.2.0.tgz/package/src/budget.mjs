/**
 * Global budget enforcement (plan §5, rule one).
 *
 * Anti-spin depends on the run having a hard ceiling that is checked *before*
 * every unit of work, never after. Two dimensions are tracked, mirroring the
 * plan: probe calls and wall-clock seconds. The first to trip ends the run;
 * every item not yet decided keeps its `UNKNOWN` status.
 *
 * The budget is also the reason `spend()` returns a boolean rather than
 * throwing: a caller that cannot afford a probe must degrade the item, not
 * abort the report.
 *
 * @module dsh-verify/budget
 */

export class BudgetExhaustedError extends Error {
  constructor(dimension, limit) {
    super(`budget exhausted: ${dimension} limit ${limit} reached`);
    this.name = 'BudgetExhaustedError';
    this.dimension = dimension;
    this.limit = limit;
  }
}

/**
 * A hard, monotonically consumed budget.
 *
 * Two ledgers are kept, because the plan's ceiling exists to stop *air
 * spinning* — repeated calls into a live system — and a deterministic read of a
 * file that has already been located is not that. Counting both would make the
 * ceiling meaningless on a profile with eighty composed rows, and ignoring it
 * entirely would drop the guarantee.
 *
 * - `spend()` is a **probe**: it executes something (a child process, the DSH
 *   CLI, a plugin's own code). These are hard-capped by `calls` (default 20,
 *   the plan's number).
 * - `inspect()` is a **static read**: it counts toward the wall-clock ceiling
 *   and appears in the report, but is not a probe.
 *
 * The wall-clock ceiling applies to everything, unconditionally.
 *
 * @example
 * const budget = new Budget({ calls: 20, seconds: 180 });
 * if (!budget.spend('mount probe')) return unknown('budget exhausted');
 * budget.inspect('contract check');
 */
export class Budget {
  /**
   * @param {{ calls?: number, seconds?: number, clock?: () => number }} [limits]
   */
  constructor(limits = {}) {
    this.callLimit = Number.isFinite(limits.calls) && limits.calls > 0 ? Math.floor(limits.calls) : 20;
    this.secondLimit = Number.isFinite(limits.seconds) && limits.seconds > 0 ? limits.seconds : 180;
    this.clock = limits.clock ?? (() => Date.now());
    this.startedAt = this.clock();
    this.calls = 0;
    this.inspections = 0;
    this.ledger = [];
    this.exhaustedBy = null;
  }

  /** Seconds elapsed since construction, rounded to 0.1s. */
  elapsed() {
    return (this.clock() - this.startedAt) / 1000;
  }

  /** True while both dimensions still have room. */
  canSpend() {
    return this.exhaustedBy === null;
  }

  /**
   * Consume one probe call.
   *
   * @param {string} label - what the call was for; recorded in the ledger.
   * @returns {boolean} false when the budget is (now) exhausted.
   */
  spend(label) {
    if (this.exhaustedBy !== null) return false;
    if (this.calls + 1 > this.callLimit) {
      this.exhaustedBy = { dimension: 'calls', limit: this.callLimit };
      return false;
    }
    if (this.elapsed() > this.secondLimit) {
      this.exhaustedBy = { dimension: 'seconds', limit: this.secondLimit };
      return false;
    }
    this.calls += 1;
    this.ledger.push({ index: this.calls, label, at: Number(this.elapsed().toFixed(2)) });
    return true;
  }

  /**
   * Record a static read. Counts toward wall-clock pressure and the report, but
   * is not a probe and therefore does not consume the probe ceiling.
   *
   * @param {string} label
   * @returns {boolean} false when the wall-clock ceiling has been reached.
   */
  inspect(label) {
    this.inspections += 1;
    if (this.inspections % 64 === 1) this.ledger.push({ index: this.inspections, label, at: Number(this.elapsed().toFixed(2)), kind: 'inspect' });
    return this.check();
  }

  /**
   * Re-check the time dimension without consuming a call. Long static scans
   * call this between items so a slow filesystem still trips the ceiling.
   *
   * @returns {boolean} true when the budget is still usable.
   */
  check() {
    if (this.exhaustedBy !== null) return false;
    if (this.elapsed() > this.secondLimit) {
      this.exhaustedBy = { dimension: 'seconds', limit: this.secondLimit };
      return false;
    }
    return true;
  }

  /** Remaining calls, floored at zero. */
  remaining() {
    return Math.max(0, this.callLimit - this.calls);
  }

  /**
   * The plan's summary line: `已用 X 次调用 / Y 秒`, rendered in English with
   * the original shape preserved. Built from raw fields so it never re-enters
   * {@link Budget#snapshot}.
   */
  summaryLine() {
    const seconds = Number(this.elapsed().toFixed(2));
    const tag = this.exhaustedBy ? ` (EXHAUSTED: ${this.exhaustedBy.dimension})` : '';
    return `BUDGET: used ${this.calls} probe calls / ${this.inspections} inspections / ${seconds}s of ${this.callLimit} calls / ${this.secondLimit}s${tag}`;
  }

  /** Machine-readable budget state for the report. */
  snapshot() {
    return {
      calls: this.calls,
      callLimit: this.callLimit,
      remaining: this.remaining(),
      inspections: this.inspections,
      seconds: Number(this.elapsed().toFixed(2)),
      secondLimit: this.secondLimit,
      exhausted: this.exhaustedBy !== null,
      exhaustedBy: this.exhaustedBy,
      summaryLine: this.summaryLine(),
    };
  }
}
