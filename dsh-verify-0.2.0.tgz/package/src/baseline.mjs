/**
 * Baseline snapshots and diffing (plan §7).
 *
 * The cheapest way to answer "what did the update break?" is to compare against
 * a snapshot taken before it. The baseline records exactly the five things the
 * plan names — the composed plugin rows, each profile's mode list, the expected
 * tool list, each mode's tool set, and the DSH version — so the diff that runs
 * before the ladder can shrink the search space to what actually moved.
 *
 * @module dsh-verify/baseline
 */

import { join, resolve } from 'node:path';
import { mkdirSync, writeFileSync } from 'node:fs';
import { readJson, readTextOrNull } from './fsutil.mjs';

/** Current baseline schema version; bumped when the shape changes. */
export const BASELINE_VERSION = 1;

/** Default filename for a snapshot inside the state directory. */
export const BASELINE_FILE = 'baseline.json';

/**
 * Build a snapshot from a completed verification result.
 *
 * @param {any} result - the `verify()` return value.
 * @returns {any} a JSON-serializable baseline document.
 */
export function buildBaseline(result) {
  const plugins = {};
  for (const table of result.profiles ?? []) {
    plugins[table.profile] = {
      rows: Object.fromEntries([...table.composition.rows.values()].map((rowRecord) => [
        rowRecord.id,
        { name: rowRecord.name, gate: rowRecord.gate, config: rowRecord.config, introducedBy: rowRecord.introducedBy },
      ])),
      rowOrder: table.composition.order,
      bundles: table.composition.bundleNames,
    };
  }

  const modes = result.modes
    ? {
      roots: result.modes.roots.map((root) => ({ path: root.path, trust: root.trust, source: root.source, exists: root.exists })),
      defaultId: result.modes.defaultId ?? null,
      items: Object.fromEntries(result.modes.verified.map((entry) => [
        entry.preset.id,
        {
          trust: entry.preset.trust,
          rootSource: entry.preset.rootSource,
          active: entry.preset.active,
          shadowed: entry.preset.shadowed,
          status: entry.status,
          name: entry.preset.name ?? null,
          tools: entry.surface?.tools ?? null,
          prompts: entry.surface?.prompts ?? null,
          packages: entry.surface?.packages ?? null,
        },
      ])),
    }
    : null;

  return {
    version: BASELINE_VERSION,
    createdAt: new Date().toISOString(),
    dshVersion: result.environment.dshVersion || null,
    installAnchor: result.environment.installAnchor,
    dshHome: result.environment.dshHome,
    profile: result.profiles?.[0]?.profile ?? null,
    plugins,
    modes,
    summary: result.summary,
  };
}

/**
 * Write a baseline document.
 *
 * This is one of only two places the verifier writes anything, and it only runs
 * when the user asks for it explicitly.
 *
 * @param {string} path - destination file.
 * @param {any} baseline - the document.
 * @returns {{ ok: boolean, path: string, error?: string }}
 */
export function writeBaseline(path, baseline) {
  try {
    const absolute = resolve(path);
    mkdirSync(join(absolute, '..'), { recursive: true });
    writeFileSync(absolute, `${JSON.stringify(baseline, null, 2)}\n`, 'utf8');
    return { ok: true, path: absolute };
  } catch (error) {
    return { ok: false, path, error: error instanceof Error ? error.message : String(error) };
  }
}

/**
 * Read a baseline document.
 *
 * @param {string} path
 * @returns {{ ok: boolean, baseline?: any, error?: string }}
 */
export function readBaseline(path) {
  const absolute = resolve(path);
  if (readTextOrNull(absolute) === null) return { ok: false, error: `baseline not found: ${absolute}` };
  const parsed = readJson(absolute);
  if (!parsed.ok) return { ok: false, error: `baseline is not valid JSON: ${parsed.error.message}` };
  if (parsed.value?.version !== BASELINE_VERSION) {
    return { ok: false, error: `baseline version ${parsed.value?.version ?? '?'} is not the supported version ${BASELINE_VERSION}` };
  }
  return { ok: true, baseline: parsed.value };
}

/**
 * Diff a fresh result against a baseline, in the plan's five categories.
 *
 * @param {any} baseline
 * @param {any} current - the `verify()` return value.
 * @returns {{ changes: any[], counts: any, isEmpty: boolean }}
 */
export function diffBaseline(baseline, current) {
  const changes = [];
  const add = (kind, item, detail) => changes.push({ kind, item, detail });

  if ((baseline.dshVersion ?? null) !== (current.environment.dshVersion || null)) {
    add('dsh-version', 'harness', `${baseline.dshVersion ?? 'unknown'} → ${current.environment.dshVersion || 'unknown'}`);
  }

  for (const table of current.profiles ?? []) {
    const before = baseline.plugins?.[table.profile];
    if (!before) {
      add('profile-added', table.profile, `${table.composition.order.length} row(s), no baseline to compare`);
      continue;
    }
    const beforeRows = before.rows ?? {};
    const afterRows = Object.fromEntries([...table.composition.rows.values()].map((r) => [r.id, { name: r.name, gate: r.gate }]));

    for (const [id, rowRecord] of Object.entries(beforeRows)) {
      if (!(id in afterRows)) add('plugin-removed', `${table.profile}:${id}`, `${rowRecord.name} was composed before, and is gone now`);
    }
    for (const [id, rowRecord] of Object.entries(afterRows)) {
      if (!(id in beforeRows)) add('plugin-added', `${table.profile}:${id}`, `${rowRecord.name} is newly composed`);
      else if (beforeRows[id].name !== rowRecord.name) add('plugin-rebound', `${table.profile}:${id}`, `${beforeRows[id].name} → ${rowRecord.name}`);
      else if (beforeRows[id].gate !== rowRecord.gate) add('plugin-gate', `${table.profile}:${id}`, `enablement ${beforeRows[id].gate} → ${rowRecord.gate}`);
    }
  }

  if (baseline.modes && current.modes) {
    const beforeModes = baseline.modes.items ?? {};
    const afterModes = Object.fromEntries(current.modes.verified.map((e) => [e.preset.id, e]));

    for (const [id, before] of Object.entries(beforeModes)) {
      if (!(id in afterModes)) { add('mode-removed', id, 'mode was present before, and is gone now'); continue; }
      const after = afterModes[id];
      if (before.status !== after.status) add('mode-status', id, `${before.status} → ${after.status}`);
      if (before.shadowed !== after.preset.shadowed) add('mode-shadowing', id, after.preset.shadowed ? 'now shadowed by a higher-precedence root' : 'no longer shadowed');
      const beforeTools = before.tools ?? [];
      const afterTools = after.surface?.tools ?? [];
      const lost = beforeTools.filter((t) => !afterTools.includes(t));
      const gained = afterTools.filter((t) => !beforeTools.includes(t));
      if (lost.length) add('mode-tools-lost', id, `lost ${lost.join(', ')}`);
      if (gained.length) add('mode-tools-gained', id, `gained ${gained.join(', ')}`);
    }
    for (const id of Object.keys(afterModes)) {
      if (!(id in beforeModes)) add('mode-added', id, 'mode is newly discoverable');
    }
    if ((baseline.modes.defaultId ?? null) !== (current.modes.defaultId ?? null)) {
      add('mode-default', 'default', `${baseline.modes.defaultId ?? 'none'} → ${current.modes.defaultId ?? 'none'}`);
    }
  }

  const counts = changes.reduce((acc, change) => {
    acc[change.kind] = (acc[change.kind] ?? 0) + 1;
    return acc;
  }, {});

  return { changes, counts, isEmpty: changes.length === 0 };
}
