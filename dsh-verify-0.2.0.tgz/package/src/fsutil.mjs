/**
 * Read-only filesystem helpers and process utilities.
 *
 * Every function here is deliberately read-only: this tool's contract with DSH
 * is "inspect, never mutate". The only writes it ever performs are the report
 * and baseline files the user explicitly asks for, handled in `report.mjs` and
 * `baseline.mjs`.
 *
 * @module dsh-verify/fsutil
 */

import { readFileSync, statSync, readdirSync, existsSync } from 'node:fs';
import { join, dirname, resolve, isAbsolute, sep } from 'node:path';
import { homedir } from 'node:os';
import { fileURLToPath as nodeFileUrlToPath } from 'node:url';

/** Read a UTF-8 text file, or return `null` when it cannot be read. */
export function readTextOrNull(path) {
  try {
    const stat = statSync(path);
    if (!stat.isFile()) return null;
    if (stat.size > 16 * 1024 * 1024) return null;
    return readFileSync(path, 'utf8');
  } catch {
    return null;
  }
}

/** Read and JSON-parse a file, or return `null`. Never throws. */
export function readJsonOrNull(path) {
  const text = readTextOrNull(path);
  if (text === null) return null;
  try {
    return JSON.parse(text);
  } catch {
    return null;
  }
}

/** Read and JSON-parse a file, reporting the failure instead of swallowing it. */
export function readJson(path) {
  const text = readTextOrNull(path);
  if (text === null) return { ok: false, error: new Error(`cannot read ${path}`), value: null };
  try {
    return { ok: true, value: JSON.parse(text) };
  } catch (error) {
    return { ok: false, error, value: null };
  }
}

/** `statSync` that returns `null` instead of throwing. */
export function statOrNull(path) {
  try {
    return statSync(path);
  } catch {
    return null;
  }
}

/** `readdirSync` with `withFileTypes`, returning `[]` instead of throwing. */
export function listDir(path) {
  try {
    return readdirSync(path, { withFileTypes: true });
  } catch {
    return [];
  }
}

/** True when `path` exists as a file. */
export function isFile(path) {
  const s = statOrNull(path);
  return s !== null && s.isFile();
}

/** True when `path` exists as a directory. */
export function isDir(path) {
  const s = statOrNull(path);
  return s !== null && s.isDirectory();
}

/**
 * Resolve a module specifier to its package directory, walking the Node
 * resolution roots that DSH uses for a profile.
 *
 * Order matters and mirrors `healProfilesModuleFallback`: the profile's own
 * `node_modules` wins, then the harness module-fallback link farm, then the
 * installation anchor that actually owns the `@deepseek-ai/*` packages.
 *
 * A specifier may name a *subpath* (`@deepseek-ai/dsh-web-app/startup`), which
 * Node resolves through the package's `exports` map rather than as a physical
 * directory. Both the package root (what a source scan needs) and the resolved
 * entry file (what a load would import) are returned.
 *
 * @param {string} specifier - package name, optionally with a subpath.
 * @param {string[]} roots - absolute `node_modules`-parent directories.
 * @returns {{ pkgName: string, subpath: string, dir: string, packageDir: string, packageJsonPath: string, packageJson: any, root: string, entryFile: string|null } | null}
 */
export function resolvePackage(specifier, roots) {
  const { pkgName, subpath } = splitSpecifier(specifier);
  if (!pkgName) return null;

  for (const root of roots) {
    if (!root) continue;
    // Node resolves `@scope/name` as two path segments.
    const packageDir = join(root, ...pkgName.split('/'));
    const packageJsonPath = join(packageDir, 'package.json');
    const manifest = readJsonOrNull(packageJsonPath);
    if (manifest === null) continue;

    const result = {
      pkgName,
      subpath,
      dir: packageDir,
      packageDir,
      packageJsonPath,
      packageJson: manifest,
      root,
      entryFile: null,
    };
    if (subpath === '') {
      result.entryFile = resolveManifestTarget(packageDir, manifest, null, manifest.main);
      return result;
    }

    // Subpath: go through `exports`, falling back to the physical path.
    const exportsField = manifest.exports;
    let target = null;
    if (exportsField && typeof exportsField === 'object' && !Array.isArray(exportsField)) {
      const key = `./${subpath}`;
      const entry = exportsField[key];
      if (typeof entry === 'string') target = entry;
      else if (entry && typeof entry === 'object') target = entry.default ?? entry.import ?? entry.require ?? null;
    }
    const filePath = target ? resolve(packageDir, target) : join(packageDir, subpath);
    if (isFile(filePath)) {
      result.entryFile = filePath;
      return result;
    }
    // The manifest exists but the subpath does not resolve: report it rather
    // than silently returning the package root, which would mask a real break.
    result.entryFile = null;
    result.subpathUnresolved = true;
    return result;
  }
  return null;
}

/** Resolve a manifest's `exports['.']` / `main` to an existing file. */
function resolveManifestTarget(packageDir, manifest, exportsEntry, main) {
  const candidates = [];
  const root = exportsEntry ?? manifest?.exports?.['.'];
  if (typeof root === 'string') candidates.push(root);
  else if (root && typeof root === 'object') candidates.push(root.default, root.import, root.require);
  if (typeof main === 'string') candidates.push(main);
  candidates.push('index.js');
  for (const candidate of candidates) {
    if (typeof candidate !== 'string') continue;
    const path = resolve(packageDir, candidate);
    if (isFile(path)) return path;
  }
  return null;
}

/** Split `@scope/pkg/sub` into `{ pkgName: '@scope/pkg', subpath: 'sub' }`. */
export function splitSpecifier(specifier) {
  if (typeof specifier !== 'string' || specifier === '') return { pkgName: '', subpath: '' };
  const parts = specifier.split('/');
  if (specifier.startsWith('@')) {
    if (parts.length < 2) return { pkgName: specifier, subpath: '' };
    return { pkgName: `${parts[0]}/${parts[1]}`, subpath: parts.slice(2).join('/') };
  }
  return { pkgName: parts[0], subpath: parts.slice(1).join('/') };
}

/**
 * Resolve a relative file specifier against a base directory, refusing paths
 * that escape it. Presets address sibling files (`.` / `./file.js`) and a
 * composition that reaches outside its own directory is worth flagging, not
 * silently following.
 *
 * @param {string} specifier - a specifier beginning with `.` or `/`.
 * @param {string} baseDir - the directory to resolve against.
 * @returns {{ path: string, escapes: boolean }}
 */
export function resolveFileSpecifier(specifier, baseDir) {
  const path = isAbsolute(specifier) ? resolve(specifier) : resolve(baseDir, specifier);
  const normalizedBase = resolve(baseDir);
  const escapes = path !== normalizedBase && !path.startsWith(normalizedBase + sep);
  return { path, escapes };
}

/** Convert a `file:` URL to a filesystem path, or return `null`. */
export function fileUrlToPath(url) {
  if (typeof url !== 'string' || !url.startsWith('file:')) return null;
  try {
    return nodeFileUrlToPath(url);
  } catch {
    return null;
  }
}

/** Home directory, used only as a default when `DSH_HOME` is unset. */
export function homeDirectory() {
  return homedir();
}

/** Normalize to forward slashes for stable cross-platform evidence strings. */
export function toPosixPath(path) {
  return path.split(sep).join('/');
}

/**
 * Reduce an absolute path to a short, human-readable form for report evidence:
 * `~` for the home directory. Keeps evidence lines narrow without losing which
 * file was inspected.
 */
export function shortPath(path) {
  const home = homeDirectory();
  if (path.startsWith(home)) return `~${path.slice(home.length)}`;
  return path;
}

export { join, dirname, resolve, existsSync };
