/**
 * Mode (agent-preset) verification — plan §4's second ladder.
 *
 * DSH composes each session from an *agent preset*: a directory holding
 * `preset.yml` (display metadata) and `agent.cordis.yml` (a top-level list of
 * plugin rows). Presets are discovered from ordered roots — the shipped set,
 * then configured roots, then `<DSH_HOME>/.agent-presets` — and the first root
 * to claim an id wins.
 *
 * The plan asks for four dynamic steps: switch to the mode, confirm it is not
 * bounced back to the default, diff the tool list and system prompt, and fail
 * when nothing changed. An external process cannot switch a running session's
 * preset, so those four steps are reproduced against the same artefacts the
 * switch would consume:
 *
 *   1. *switch*      → compose the preset's rows exactly as the roster would;
 *   2. *bounce back* → detect an id shadowed by a higher-precedence root, and
 *                      every condition under which DSH refuses to mount;
 *   3. *diff*        → resolve each row's package and diff the resulting tool
 *                      and prompt-section surface against the default preset;
 *   4. *no change*   → identical row set and identical surface is a FAILED,
 *                      because a mode that changes nothing is not a mode.
 *
 * Health rules follow DSH's own discovery pass step for step, including its
 * order of checks and its wording, so a verdict here is directly comparable
 * with what the DSH UI would report.
 *
 * @module dsh-verify/modes
 */

import { join, resolve, isAbsolute } from 'node:path';
import { parseYaml, TaggedValue } from './yaml.mjs';
import { readTextOrNull, isFile, isDir, listDir, shortPath, fileUrlToPath } from './fsutil.mjs';
import { ARTIFACT } from './artifacts.mjs';

/** The directory-name rule DSH applies before a directory is even considered. */
export const PRESET_ID = /^[a-z0-9][a-z0-9-]*$/;
/** The composition filename; not configurable in DSH. */
export const COMPOSITION_FILE = 'agent.cordis.yml';
/** The display-metadata filename. */
export const METADATA_FILE = 'preset.yml';
/** The harness-home directory holding user-authored presets. */
export const USER_PRESET_DIR = '.agent-presets';

export const TRUST = Object.freeze({ SYSTEM: 'system', USER: 'user' });

/** Expand the `~` forms DSH's `expandHomePath` accepts. */
function expandHomePath(path, home) {
  if (path === '~') return home;
  if (path.startsWith('~/') || path.startsWith('~\\')) return join(home, path.slice(2));
  return path;
}

/**
 * The ordered preset roots this deployment would scan.
 *
 * @param {object} options
 * @param {string} options.dshHome - harness home.
 * @param {string} options.homeDirectory - the OS home, for `~` expansion.
 * @param {string} options.installAnchor - owns `node_modules/@deepseek-ai`.
 * @param {any} [options.rosterConfig] - the composed `agent-presets` row config.
 * @returns {Array<{ path: string, trust: string, source: string, exists: boolean }>}
 */
export function resolvePresetRoots(options) {
  const { dshHome, homeDirectory, installAnchor, rosterConfig } = options;
  const roots = [];

  const config = rosterConfig && typeof rosterConfig === 'object' ? rosterConfig : {};
  const includeShipped = config.includeShippedRoot !== false;
  const includeUser = config.includeUserRoot !== false;

  if (includeShipped) {
    const shipped = installAnchor
      ? join(installAnchor, 'node_modules', '@deepseek-ai', 'dsh-agent-presets', 'presets')
      : null;
    if (shipped) roots.push({ path: shipped, trust: TRUST.SYSTEM, source: 'shipped', exists: isDir(shipped) });
  }

  if (Array.isArray(config.roots)) {
    for (const [index, entry] of config.roots.entries()) {
      if (!entry || typeof entry !== 'object' || typeof entry.path !== 'string') continue;
      const path = resolve(expandHomePath(entry.path, homeDirectory));
      roots.push({
        path,
        trust: entry.trust === TRUST.SYSTEM ? TRUST.SYSTEM : TRUST.USER,
        source: `configured root #${index + 1}`,
        exists: isDir(path),
      });
    }
  }

  if (includeUser) {
    const userRoot = join(dshHome, USER_PRESET_DIR);
    roots.push({ path: userRoot, trust: TRUST.USER, source: 'user home', exists: isDir(userRoot) });
  }

  return roots;
}

/** Read `preset.yml`; never fatal, exactly as DSH treats it. */
export function readPresetMetadata(dir) {
  const path = join(dir, METADATA_FILE);
  const text = readTextOrNull(path);
  if (text === null) return { present: false, path, value: {}, fields: {}, problems: [] };

  let parsed;
  try {
    parsed = parseYaml(text);
  } catch (error) {
    return { present: true, path, value: {}, fields: {}, problems: [`${METADATA_FILE} is not valid YAML: ${firstLine(error.message)}`] };
  }
  if (parsed === null || typeof parsed !== 'object' || Array.isArray(parsed)) {
    return { present: true, path, value: {}, fields: {}, problems: [] };
  }

  const problems = [];
  const text$ = (value) => (typeof value === 'string' && value.trim() !== '' ? value.trim() : undefined);
  const name = text$(parsed.name);
  const description = text$(parsed.description);
  const order = typeof parsed.order === 'number' && Number.isFinite(parsed.order) ? parsed.order : undefined;
  if (parsed.name !== undefined && name === undefined) problems.push('`name` is present but is not a non-empty string');
  if (parsed.description !== undefined && description === undefined) problems.push('`description` is present but is not a non-empty string');
  if (parsed.order !== undefined && order === undefined) problems.push('`order` is present but is not a finite number');

  return { present: true, path, value: parsed, fields: { name, description, order }, problems };
}

/** First line of a multi-line error message, matching DSH's own truncation. */
function firstLine(message) {
  return String(message).replace(/\n[\s\S]*$/, '');
}

/**
 * The preset-relative resolution DSH performs for a row specifier.
 *
 * A package lives wherever `node_modules/<pkg>/package.json` can be found by
 * walking up from the harness base — deliberately *not* the profile's own
 * `node_modules`, because a preset composes in the agent plane, above the
 * profile.
 *
 * @param {string} specifier
 * @param {string} harnessBase
 * @returns {boolean}
 */
export function packageInstalled(specifier, harnessBase) {
  const parts = specifier.split('/');
  const pkg = parts.slice(0, specifier.startsWith('@') ? 2 : 1).join('/');
  if (pkg === '') return false;

  let dir = resolve(harnessBase);
  for (;;) {
    if (isFile(join(dir, 'node_modules', ...pkg.split('/'), 'package.json'))) return true;
    const parent = resolve(dir, '..');
    if (parent === dir) return false;
    dir = parent;
  }
}

/** Classify a row specifier exactly as DSH's `classifyRowSpecifier` does. */
export function classifySpecifier(specifier) {
  if (typeof specifier !== 'string') return 'invalid';
  if (specifier.startsWith('cordis:')) return 'builtin';
  if (specifier.startsWith('.')) return 'preset';
  if (specifier.startsWith('file:')) return 'file';
  if (isAbsolute(specifier)) return 'file';
  return 'package';
}

/**
 * Walk a composition's rows, mirroring DSH's `entryListProblem` shape check.
 *
 * @param {any} rows - parsed composition.
 * @param {string} [at] - group label when recursing.
 * @returns {string|null} the problem, or null when the shape is valid.
 */
export function entryListProblem(rows, at) {
  const label = (index) => (at === undefined ? `row ${index + 1}` : `${at} row ${index + 1}`);

  if (!Array.isArray(rows)) {
    return at === undefined
      ? 'the composition must be a top-level list of plugin rows'
      : `group ${at} must hold a list of plugin rows`;
  }

  for (const [index, row] of rows.entries()) {
    if (row === null || typeof row !== 'object' || Array.isArray(row)) {
      return `${label(index)} is not a plugin row (expected a map with a "name")`;
    }
    const { name, group, config } = row;
    if (typeof name !== 'string' || name === '') {
      return `${label(index)} names no plugin (a "name" string is required)`;
    }
    if (group === true) {
      const nested = entryListProblem(config, label(index));
      if (nested !== null) return nested;
    }
  }
  return null;
}

/**
 * Flatten a composition into its addressable rows, tracking group nesting and
 * inherited disablement the way the Loader does.
 *
 * @param {any[]} rows
 * @param {string} [at]
 * @param {boolean} [inheritedDisabled]
 * @returns {any[]}
 */
export function flattenRows(rows, at, inheritedDisabled = false) {
  const out = [];
  if (!Array.isArray(rows)) return out;
  for (const [index, row] of rows.entries()) {
    if (row === null || typeof row !== 'object' || Array.isArray(row)) continue;
    const label = at === undefined ? `row ${index + 1}` : `${at} row ${index + 1}`;
    const own = row.disabled instanceof TaggedValue ? 'conditional' : row.disabled === true ? true : false;
    if (row.group === true) {
      const nestedDisabled = inheritedDisabled || own === true;
      out.push(...flattenRows(row.config, label, nestedDisabled));
      continue;
    }
    const enabled = inheritedDisabled || own === true ? false : own === 'conditional' ? 'conditional' : true;
    out.push({
      id: typeof row.id === 'string' && row.id !== '' ? row.id : null,
      name: row.name,
      label: typeof row.id === 'string' && row.id !== '' ? `row "${row.id}"` : label,
      enabled,
      condition: own === 'conditional' ? row.disabled.__expr : null,
      groupLabel: at ?? null,
      raw: row,
    });
  }
  return out;
}

/**
 * The unresolvable rows of a composition, and DSH's exact failure wording.
 *
 * @param {any[]} rows
 * @param {string} compositionPath
 * @param {string} harnessBase
 * @returns {{ failures: any[], message: string|null }}
 */
export function unresolvableRows(rows, compositionPath, harnessBase) {
  const presetBase = resolve(compositionPath, '..');
  const failures = [];

  const visit = (list, at) => {
    if (!Array.isArray(list)) return;
    for (const [index, row] of list.entries()) {
      if (row === null || typeof row !== 'object' || Array.isArray(row)) continue;
      const label = at === undefined ? `row ${index + 1}` : `${at} row ${index + 1}`;
      if (row.group === true) {
        visit(row.config, label);
        continue;
      }
      // `Boolean(row.disabled)` — a `!!js` node is an object and therefore truthy,
      // which is exactly why DSH leaves those rows unchecked.
      if (row.disabled) continue;

      const name = row.name;
      const kind = classifySpecifier(name);
      let resolved = false;
      if (kind === 'builtin') resolved = true;
      else if (kind === 'preset') resolved = isFile(resolve(presetBase, name));
      else if (kind === 'file') {
        const target = name.startsWith('file:') ? fileUrlToPath(name) : name;
        resolved = typeof target === 'string' && target !== '' && isFile(target);
      } else if (kind === 'package') resolved = packageInstalled(name, harnessBase);

      if (!resolved) {
        failures.push({
          label: typeof row.id === 'string' && row.id !== '' ? `row "${row.id}"` : label,
          name,
          kind,
          groupLabel: at ?? null,
        });
      }
    }
  };

  visit(rows, undefined);

  if (failures.length === 0) return { failures, message: null };
  if (failures.length === 1) {
    return { failures, message: `${failures[0].label} names a plugin that cannot be resolved: ${failures[0].name}` };
  }
  const lines = failures.map((f) => `- ${f.label}: ${f.name}`).join('\n');
  return { failures, message: `${failures.length} rows name plugins that cannot be resolved:\n${lines}` };
}

/**
 * Run DSH's own health check for one preset directory.
 *
 * The check order is load-bearing: each step runs only when the previous one
 * passed, and the first failure is the whole answer — matching
 * `scanRoot` → `compositionProblem` in DSH.
 *
 * @param {object} preset
 * @param {string} preset.dir
 * @param {string} preset.id
 * @param {string} harnessBase
 * @returns {{ broken: string|null, layer: string, composition: any[]|null, rows: any[], rowsProblem: string|null, resolution: any, metadata: any, path: string }}
 */
export function checkPresetHealth(preset, harnessBase) {
  const path = join(preset.dir, COMPOSITION_FILE);
  const metadata = readPresetMetadata(preset.dir);
  const base = { path, composition: null, rows: [], rowsProblem: null, resolution: { failures: [], message: null }, metadata };

  if (!isFile(path)) {
    return {
      ...base,
      broken: `the composition file ${COMPOSITION_FILE} is missing — the directory still occupies the id; delete it or restore the file`,
      layer: 'L1',
    };
  }

  const text = readTextOrNull(path);
  if (text === null) {
    return { ...base, broken: `the composition file ${COMPOSITION_FILE} cannot be read`, layer: 'L1' };
  }

  let composition;
  try {
    composition = parseYaml(text);
  } catch (error) {
    return { ...base, broken: `the composition is not valid YAML: ${firstLine(error.message)}`, layer: 'L1' };
  }

  const rowsProblem = entryListProblem(composition);
  if (rowsProblem !== null) {
    return { ...base, composition: Array.isArray(composition) ? composition : null, broken: rowsProblem, layer: 'L2' };
  }

  const resolution = unresolvableRows(composition, path, harnessBase);
  const rows = flattenRows(composition);
  if (resolution.message !== null) {
    return { ...base, composition, rows, rowsProblem: null, resolution, broken: resolution.message, layer: 'L2' };
  }

  return { ...base, composition, rows, rowsProblem: null, resolution, broken: null, layer: 'L2' };
}

/**
 * Discover every preset across every root, keeping shadowed duplicates.
 *
 * DSH silently drops a duplicate id from a lower-precedence root. That is the
 * single most damaging silent failure this tool exists to catch — the user's
 * preset directory is present, its file is valid, and the mode never appears —
 * so a shadowed preset is kept as a row and reported, not discarded.
 *
 * @param {object} options
 * @param {Array<{ path: string, trust: string, source: string, exists: boolean }>} options.roots
 * @param {string} options.harnessBase
 * @returns {{ presets: any[], problems: any[] }}
 */
export function discoverPresets(options) {
  const { roots, harnessBase } = options;
  const claimed = new Map();
  const presets = [];
  const problems = [];

  for (const root of roots) {
    if (!root.exists) {
      problems.push({ kind: 'root-missing', path: root.path, trust: root.trust, source: root.source });
      continue;
    }
    const entries = listDir(root.path).filter((e) => e.isDirectory()).sort((a, b) => a.name.localeCompare(b.name));

    for (const entry of entries) {
      if (!PRESET_ID.test(entry.name)) {
        problems.push({ kind: 'id-skipped', path: join(root.path, entry.name), id: entry.name, source: root.source });
        continue;
      }
      const dir = join(root.path, entry.name);
      const metadata = readPresetMetadata(dir);
      const shadowedBy = claimed.get(entry.name) ?? null;

      const preset = {
        id: entry.name,
        dir,
        trust: root.trust,
        rootSource: root.source,
        rootPath: root.path,
        path: join(dir, COMPOSITION_FILE),
        name: metadata.fields.name,
        description: metadata.fields.description,
        order: metadata.fields.order,
        shadowed: shadowedBy !== null,
        shadowedBy,
        active: shadowedBy === null,
      };

      if (shadowedBy === null) {
        claimed.set(entry.name, { path: root.path, trust: root.trust, source: root.source, dir });
      }
      presets.push(preset);
    }
  }

  return { presets, problems };
}

/** DSH's ordering: `order` ascending with `undefined` last, then id. */
export function sortPresets(presets) {
  return [...presets].sort((a, b) => {
    const left = a.order ?? Number.POSITIVE_INFINITY;
    const right = b.order ?? Number.POSITIVE_INFINITY;
    if (left !== right) return left - right;
    return a.id.localeCompare(b.id);
  });
}

/**
 * The tool and prompt surface a preset would install.
 *
 * Each row's package is resolved and scanned once per run, then the union of
 * that preset's enabled rows is taken. This is the static stand-in for "diff
 * the tool list and system prompt before and after switching".
 *
 * Artifacts whose name is computed at runtime (`<unnamed defineTool
 * @file:line>`) are counted but excluded from the name sets. Their placeholder
 * embeds a line number, so a dependency bump that shifts a file by three lines
 * would otherwise read as "this mode gained and lost five tools" — a false
 * change in exactly the report a baseline diff exists to make trustworthy.
 *
 * @param {object} options
 * @param {any[]} options.rows - flattened preset rows.
 * @param {Map<string, any>} options.cache - package specifier → scan result.
 * @param {(specifier: string, row: any) => any} options.resolveRow - resolver.
 * @returns {{ tools: string[], prompts: string[], services: string[], packages: string[], unscanned: string[], dynamic: { tools: number, prompts: number } }}
 */
export function presetSurface(options) {
  const { rows, cache, resolveRow } = options;
  const tools = new Set();
  const prompts = new Set();
  const services = new Set();
  const packages = new Set();
  const unscanned = new Set();
  const dynamic = { tools: 0, prompts: 0 };

  /** A placeholder name is a `<...>` marker, never a stable identity. */
  const isDynamic = (name) => typeof name === 'string' && name.startsWith('<') && name.endsWith('>');

  for (const row of rows) {
    if (row.enabled === false) continue;
    packages.add(row.name);
    const scan = resolveRow(row.name, row);
    if (!scan) { unscanned.add(row.name); continue; }
    for (const artifact of scan.artifacts) {
      if (artifact.type === ARTIFACT.TOOL) {
        if (isDynamic(artifact.name) || artifact.detail?.named === false) dynamic.tools += 1;
        else tools.add(artifact.name);
      } else if (artifact.type === ARTIFACT.PROMPT) {
        if (isDynamic(artifact.name) || artifact.detail?.named === false) dynamic.prompts += 1;
        else prompts.add(artifact.name);
      } else if (artifact.type === ARTIFACT.SERVICE && artifact.detail.role !== 'identity') {
        services.add(artifact.name);
      }
    }
  }
  void cache;

  return {
    tools: [...tools].sort(),
    prompts: [...prompts].sort(),
    services: [...services].sort(),
    packages: [...packages].sort(),
    unscanned: [...unscanned].sort(),
    dynamic,
  };
}

/** A compact, stable representation of a mode's composition, for the baseline. */
export function modeFingerprint(preset) {
  return {
    id: preset.id,
    trust: preset.trust,
    rootSource: preset.rootSource,
    dir: preset.dir,
    name: preset.name ?? null,
    order: preset.order ?? null,
    active: preset.active,
    shadowed: preset.shadowed,
  };
}

export { shortPath };
