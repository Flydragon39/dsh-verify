/**
 * The stepped verification engine (plan §4).
 *
 * One item — a plugin or a mode — is pushed through ordered layers. Any layer
 * that fails or terminates ends the item immediately; there is no path back to
 * an earlier layer and no retry of a completed one. Together with the budget
 * and the UNKNOWN terminal, that is what guarantees the run terminates.
 *
 * Layer contract, verbatim from the plan:
 *
 *   L0  existence       the name is present in the composed config tree
 *   L1  mount           no mount/apply error
 *   L2  enumerate       at least one artifact; none — PASS (mounted), stop
 *   L3  contract        each artifact satisfies its class contract
 *   L4  behaviour       one minimal trigger; failure — DEGRADED, unconstructible — UNKNOWN
 *
 * @module dsh-verify/ladder
 */

import { ARTIFACT, ARTIFACT_ORDER, ARTIFACT_LABEL, groupArtifacts } from './artifacts.mjs';
import { GATE } from './compose.mjs';

/** The five verdicts. There is deliberately no sixth. */
export const STATUS = Object.freeze({
  PASS: 'PASS',
  PASS_MOUNTED: 'PASS(mounted)',
  DEGRADED: 'DEGRADED',
  FAILED: 'FAILED',
  UNKNOWN: 'UNKNOWN',
});

export const LAYER = Object.freeze({
  L0: 'L0',
  L1: 'L1',
  L2: 'L2',
  L3: 'L3',
  L4: 'L4',
  META: 'MODES',
});

/** Per-layer attempt timeouts from the plan. Advisory here: the budget owns the clock. */
export const LAYER_TIMEOUT_MS = Object.freeze({ L0: 5000, L1: 10000, L2: 5000, L3: 15000, L4: 10000 });

/**
 * One row of the report table (plan §10: `item | type | status | layer | evidence`).
 *
 * @param {object} fields
 * @returns {{ item: string, type: string, status: string, layer: string, evidence: string, detail?: any }}
 */
export function row(item, type, status, layer, evidence, detail) {
  const record = { item, type, status, layer, evidence };
  if (detail !== undefined) record.detail = detail;
  return record;
}

/**
 * Contract checks for each artifact class (plan §3's table).
 *
 * Each check returns `null` for "satisfied", a string for a violated contract
 * (— DEGRADED), or `{ unknown: string }` when the file alone cannot decide
 * (— UNKNOWN). The distinction matters: `web.searchProvider: ddg` pointing at
 * a provider we cannot see is not the same as pointing at one we can see is
 * absent, and the report must not conflate them.
 *
 * @param {object} context
 * @param {any} context.scan - the plugin's scan result.
 * @param {Map<string, any[]>} context.nameIndex - composed rows by module specifier.
 * @param {Map<string, any>} context.rowIdIndex - composed rows by normalized row id.
 * @param {Map<string, string[]>} context.capabilityIndex - capability id — owning row ids.
 * @param {Set<string>} context.declaredCapabilities - capability ids this plugin publishes.
 * @param {Map<string, string[]>} context.toolOwners - tool name — plugin names across the tree.
 * @returns {Array<{ artifact: any, status: string, evidence: string }>}
 */
export function checkContracts(context) {
  const { scan, nameIndex, rowIdIndex, capabilityIndex, toolOwners } = context;
  const results = [];

  for (const artifact of scan.artifacts) {
    switch (artifact.type) {
      case ARTIFACT.TOOL:
        results.push(checkTool(artifact, scan, toolOwners));
        break;
      case ARTIFACT.COMMAND:
        results.push(checkCommand(artifact));
        break;
      case ARTIFACT.HOOK:
        results.push(checkHook(artifact));
        break;
      case ARTIFACT.SERVICE:
        results.push(checkService(artifact, scan, nameIndex, rowIdIndex, capabilityIndex));
        break;
      case ARTIFACT.PROMPT:
        results.push(checkPrompt(artifact));
        break;
      case ARTIFACT.SLOT:
        results.push(checkSlot(artifact));
        break;
      default:
        results.push({ artifact, status: STATUS.PASS, evidence: 'no contract to check for this class' });
    }
  }
  return results;
}

function checkTool(artifact, scan, toolOwners) {
  if (!artifact.detail.named) {
    return { artifact, status: STATUS.UNKNOWN, evidence: 'tool is registered dynamically; its name cannot be read from the source' };
  }
  const owners = toolOwners.get(artifact.name) ?? [];
  if (owners.length > 1) {
    return {
      artifact,
      status: STATUS.DEGRADED,
      evidence: `name "${artifact.name}" is also declared by ${owners.filter((o) => o !== scan.name).join(', ')} — duplicate registration collides at runtime`,
    };
  }
  if (!artifact.detail.hasParameters) {
    return { artifact, status: STATUS.DEGRADED, evidence: 'no parameters/input schema declared' };
  }
  if (!artifact.detail.hasDescription) {
    return { artifact, status: STATUS.DEGRADED, evidence: 'no description declared' };
  }
  return { artifact, status: STATUS.PASS, evidence: `named, described, schema present (${artifact.file.split(/[\\/]/).pop()}:${artifact.line})` };
}

function checkCommand(artifact) {
  if (!artifact.detail.named) {
    return { artifact, status: STATUS.UNKNOWN, evidence: 'command name cannot be read from the source' };
  }
  if (!/^[A-Za-z0-9][A-Za-z0-9:_-]*$/.test(artifact.name)) {
    return { artifact, status: STATUS.DEGRADED, evidence: `command name "${artifact.name}" is not a usable slash-command token` };
  }
  return { artifact, status: STATUS.PASS, evidence: `named "${artifact.name}"` };
}

function checkHook(artifact) {
  if (!artifact.name.includes('/') && !artifact.name.includes(':')) {
    return { artifact, status: STATUS.DEGRADED, evidence: `event name "${artifact.name}" is not a namespaced cordis event` };
  }
  return { artifact, status: STATUS.PASS, evidence: `listens on "${artifact.name}"` };
}

function checkService(artifact, scan, nameIndex, rowIdIndex, capabilityIndex) {
  const { service, role } = artifact.detail;

  // A plugin's own `name` export is advisory: DSH keys the tree on the loader
  // row's `id`, and shipped packages routinely differ (`session-title-llm` is
  // the row id for the module named `session-title-first-prompt-llm`). Nothing
  // in DSH requires the two to agree, so a mismatch is evidence, not a defect.
  if (role === 'identity') {
    return { artifact, status: STATUS.PASS, evidence: `module reports itself as "${service}" (the tree is keyed on the loader row id, which need not match)` };
  }

  if (role === 'provide') {
    const providerRow = rowIdIndex.get(normalizeServiceName(service));
    return {
      artifact,
      status: STATUS.PASS,
      evidence: providerRow
        ? `publishes service "${service}" (composed row "${providerRow.id}" exists)`
        : `publishes service "${service}"`,
    };
  }

  if (role === 'register') {
    if (artifact.detail.capabilityId) {
      return {
        artifact,
        status: STATUS.PASS,
        evidence: `publishes capability id "${artifact.detail.capabilityId}" (${artifact.detail.capabilityEvidence})`,
      };
    }
    return { artifact, status: STATUS.PASS, evidence: `${artifact.detail.namespace}.${artifact.detail.verb}() — registration call present` };
  }

  // role === 'inject': the artifact names a service some other row must supply.
  //
  // A DSH service name is the *row id* of its provider, not the package name:
  // `ctx.inject(['settings'])` is satisfied by the row `- id: settings`, and
  // `ctx.inject(['systemPrompt'])` by `- id: system-prompt`. Comparing against
  // package names alone would report every one of them as unprovided, so both
  // indexes are consulted, normalized for the camelCase/kebab-case split.
  const normalized = normalizeServiceName(service);
  const byRowId = rowIdIndex.get(normalized);
  if (byRowId) {
    return {
      artifact,
      status: STATUS.PASS,
      evidence: `"${service}" is published by composed row "${byRowId.id}" (${byRowId.name})`,
    };
  }

  const byPackage = nameIndex.get(service)
    ?? [...nameIndex.entries()].find(([specifier]) => normalizeServiceName(specifier.split('/').pop()) === normalized)?.[1];
  if (byPackage && byPackage.length > 0) {
    return { artifact, status: STATUS.PASS, evidence: `"${service}" is published by composed row "${byPackage[0].id}"` };
  }

  if (capabilityIndex.has(service)) {
    return { artifact, status: STATUS.PASS, evidence: `"${service}" is published by capability provider ${capabilityIndex.get(service).join(', ')}` };
  }

  return {
    artifact,
    status: STATUS.UNKNOWN,
    evidence: `no composed row resolves to the service "${service}"; it may be supplied by a plugin whose name differs from the service key, which the file alone cannot settle`,
  };
}

function checkPrompt(artifact) {
  if (!artifact.detail.named) {
    return { artifact, status: STATUS.UNKNOWN, evidence: 'prompt section name is computed at runtime' };
  }
  return artifact.detail.hasText
    ? { artifact, status: STATUS.PASS, evidence: `section "${artifact.name}" has text` }
    : { artifact, status: STATUS.DEGRADED, evidence: `section "${artifact.name}" declares no text` };
}

function checkSlot(artifact) {
  if (artifact.detail.entry && !artifact.detail.entryExists) {
    return { artifact, status: STATUS.DEGRADED, evidence: `client entry "${artifact.detail.entry}" declared in the manifest does not exist` };
  }
  if (!artifact.detail.entry) {
    return { artifact, status: STATUS.UNKNOWN, evidence: 'manifest declares a client surface but names no client entry file' };
  }
  return {
    artifact,
    status: STATUS.PASS,
    evidence: `client entry "${artifact.detail.entry}" exists for platform "${artifact.detail.platform}"`,
  };
}

/** `systemPrompt` — `systemprompt`, `system-prompt` — `systemprompt`. */
function normalizeServiceName(value) {
  return String(value ?? '').toLowerCase().replace(/[-_.]/g, '');
}

/**
 * Reduce contract outcomes to one status for the item, keeping the worst.
 *
 * Ordering: FAILED > DEGRADED > UNKNOWN > PASS. UNKNOWN ranks above PASS
 * because a row the file cannot decide must not be reported as verified.
 */
export function worstStatus(statuses) {
  const rank = { [STATUS.FAILED]: 4, [STATUS.DEGRADED]: 3, [STATUS.UNKNOWN]: 2, [STATUS.PASS_MOUNTED]: 1, [STATUS.PASS]: 0 };
  let worst = STATUS.PASS;
  for (const status of statuses) if ((rank[status] ?? 0) > (rank[worst] ?? 0)) worst = status;
  return worst;
}

/**
 * Verify one plugin through the ladder.
 *
 * The function is pure with respect to DSH: it reads the already-composed tree
 * and the plugin's own files, and it never loads the plugin. `probe` is the
 * only gateway to anything dynamic (a sandbox import), so a run without
 * `--probe` performs no execution at all.
 *
 * @param {object} options
 * @param {any} options.rowRecord - the composed row for this plugin.
 * @param {any} options.scan - artifact scan result, or null when unresolvable.
 * @param {any} options.resolution - `{ dir, packageJson }` or null.
 * @param {Map<string, any[]>} options.nameIndex
 * @param {Map<string, any>} options.rowIdIndex
 * @param {Map<string, string[]>} options.capabilityIndex
 * @param {Map<string, string[]>} options.toolOwners
 * @param {(plugin: any) => Promise<{ ok: boolean, error: string|null, skipped?: string }>} [options.probe]
 * @param {import('./budget.mjs').Budget} options.budget
 * @returns {Promise<{ rows: any[], status: string, layer: string, scan: any }>}
 */
export async function verifyPlugin(options) {
  const { rowRecord, scan, resolution, nameIndex, rowIdIndex, capabilityIndex, toolOwners, probe, budget } = options;
  const item = rowRecord.name ?? rowRecord.id;
  const rows = [];

  // ── L0: presence in the composed tree ─────────────────────────────────────
  const inTree = nameIndex.has(rowRecord.name) && rowRecord.id !== null;
  if (!inTree && !resolution) {
    rows.push(row(item, 'plugin', STATUS.FAILED, LAYER.L0, `not present in the composed config tree of profile "${rowRecord.profile ?? '?'}"`));
    return { rows, status: STATUS.FAILED, layer: LAYER.L0, scan };
  }
  const gate = rowRecord.gate === GATE.DISABLED
    ? 'row is disabled in the composition'
    : rowRecord.gate === GATE.CONDITIONAL
      ? `row is conditionally disabled by ${rowRecord.gateExpr}`
      : 'row is enabled';
  rows.push(row(item, 'plugin', STATUS.PASS, LAYER.L0, `composed as row id "${rowRecord.id}" (${gate}); introduced by ${rowRecord.introducedBy}`));

  // A disabled row is present but inert: that is a terminal PASS, not a failure.
  if (rowRecord.gate === GATE.DISABLED) {
    return { rows, status: STATUS.PASS_MOUNTED, layer: LAYER.L0, scan };
  }

  if (!resolution) {
    rows.push(row(item, 'plugin', STATUS.FAILED, LAYER.L1, `package "${rowRecord.name}" cannot be resolved from the profile's module roots`));
    return { rows, status: STATUS.FAILED, layer: LAYER.L1, scan };
  }

  // ── L1: loads without error ───────────────────────────────────────────────
  const manifest = resolution.packageJson;
  const entrySpec = typeof manifest?.exports === 'object' && manifest.exports?.['.']
    ? (typeof manifest.exports['.'] === 'string' ? manifest.exports['.'] : manifest.exports['.'].default)
    : manifest?.main;
  if (!manifest?.name) {
    rows.push(row(item, 'plugin', STATUS.FAILED, LAYER.L1, `package.json at ${resolution.dir} has no "name"`));
    return { rows, status: STATUS.FAILED, layer: LAYER.L1, scan };
  }
  rows.push(row(item, 'plugin', STATUS.PASS, LAYER.L1, `manifest resolved (v${manifest.version ?? '?'}), entry ${entrySpec ?? '<none declared>'}`));

  if (probe) {
    const spent = budget.spend(`mount probe: ${rowRecord.name}`);
    if (!spent) {
      rows.push(row(item, 'plugin', STATUS.UNKNOWN, LAYER.L1, 'budget exhausted before the mount probe', { deferred: true }));
      return { rows, status: STATUS.UNKNOWN, layer: LAYER.L1, scan };
    }
    const outcome = await probe({ name: rowRecord.name, dir: resolution.dir, manifest });
    if (outcome.skipped) {
      rows.push(row(item, 'plugin', STATUS.UNKNOWN, LAYER.L1, `mount not observed: ${outcome.skipped}`, { deferred: true }));
    } else if (!outcome.ok && outcome.inconclusive) {
      // A probe that could not run says nothing about the plugin; only an
      // observed throw does. Conflating the two would fail healthy plugins.
      rows.push(row(item, 'plugin', STATUS.UNKNOWN, LAYER.L1, `mount not observed: ${outcome.error}`, { deferred: true }));
    } else if (!outcome.ok) {
      rows.push(row(item, 'plugin', STATUS.FAILED, LAYER.L1, `mount probe threw: ${outcome.error}`));
      return { rows, status: STATUS.FAILED, layer: LAYER.L1, scan };
    } else {
      rows.push(row(item, 'plugin', STATUS.PASS, LAYER.L1, 'imported in an isolated probe process without throwing'));
    }
  } else {
    // Honest, and identical for every plugin: a static run cannot see mount
    // errors. Marked `deferred` because the remedy is a flag, not an
    // investigation, and counting it as a finding would drown the real ones.
    rows.push(row(item, 'plugin', STATUS.UNKNOWN, LAYER.L1, 'static run: mount behaviour is unobservable without executing the plugin (rerun with --probe)', { deferred: true }));
  }

  if (!scan) {
    rows.push(row(item, 'plugin', STATUS.UNKNOWN, LAYER.L2, 'artifact scan unavailable'));
    return { rows, status: STATUS.UNKNOWN, layer: LAYER.L2, scan };
  }

  // ── L2: enumerate artifacts ───────────────────────────────────────────────
  //
  // A module's own `name` export is identity metadata, not a product. Counting
  // it would defeat the terminal case the plan specifies: a plugin that
  // registers nothing must reach `PASS(mounted)`, and every plugin names itself.
  const produced = scan.artifacts.filter((a) => a.detail?.role !== 'identity');
  const groups = groupArtifacts(produced);
  const present = [...groups.entries()].filter(([, list]) => list.length > 0).map(([type]) => type);
  const ordered = [...ARTIFACT_ORDER, ARTIFACT.SIDE_EFFECT].filter((type) => present.includes(type));

  if (present.length === 0 || (present.length === 1 && present[0] === ARTIFACT.SIDE_EFFECT)) {
    rows.push(row(item, 'plugin', STATUS.PASS_MOUNTED, LAYER.L2, 'registers no tool, command, hook, service, prompt section or UI slot — mount success is the whole contract'));
    return { rows, status: STATUS.PASS_MOUNTED, layer: LAYER.L2, scan };
  }

  rows.push(row(
    item,
    'plugin',
    STATUS.PASS,
    LAYER.L2,
    ordered.map((type) => `${ARTIFACT_LABEL[type].en}×${groups.get(type).length}`).join(', '),
    { artifacts: produced.map((a) => ({ type: a.type, name: a.name, file: a.file, line: a.line })) },
  ));

  // ── L3: artifact contracts ────────────────────────────────────────────────
  //
  // One report row per artifact *class*, not per artifact: the plan's table has
  // one row per item per type, and a plugin injecting five services must not
  // become five rows. Per-artifact outcomes stay in `detail`.
  budget.inspect(`contract check: ${rowRecord.name}`);
  if (!budget.check()) {
    rows.push(row(item, 'plugin', STATUS.UNKNOWN, LAYER.L3, 'wall-clock budget exhausted before contract checks'));
    return { rows, status: worstStatus([STATUS.PASS, STATUS.UNKNOWN]), layer: LAYER.L3, scan };
  }
  const contracts = checkContracts({ scan, nameIndex, rowIdIndex, capabilityIndex, toolOwners });

  const byClass = new Map();
  for (const result of contracts) {
    const type = result.artifact.type;
    const bucket = byClass.get(type) ?? { type, statuses: [], members: [] };
    bucket.statuses.push(result.status);
    bucket.members.push({ name: result.artifact.name, status: result.status, evidence: result.evidence });
    byClass.set(type, bucket);
  }

  for (const bucket of byClass.values()) {
    const status = worstStatus(bucket.statuses);
    const counts = bucket.statuses.reduce((acc, s) => { acc[s] = (acc[s] ?? 0) + 1; return acc; }, {});
    const tallyText = Object.entries(counts).map(([s, n]) => `${n} ${s}`).join(', ');
    const highlighted = bucket.members.filter((m) => m.status !== STATUS.PASS);
    const evidence = highlighted.length > 0
      ? `${highlighted.slice(0, 3).map((m) => `${m.name}: ${m.evidence}`).join(' • ')}${highlighted.length > 3 ? ` • (+${highlighted.length - 3} more)` : ''}`
      : `${bucket.members.slice(0, 4).map((m) => m.name).join(', ')}${bucket.members.length > 4 ? `, +${bucket.members.length - 4} more` : ''}`;
    rows.push(row(
      item,
      ARTIFACT_LABEL[bucket.type].en,
      status,
      LAYER.L3,
      `${bucket.members.length} artifact(s): ${tallyText} — ${evidence}`,
      { members: bucket.members },
    ));
  }

  // ── L4: behaviour trigger ─────────────────────────────────────────────────
  // A static, external verifier can prove a tool exists and is well formed; it
  // cannot prove the tool answers without a live host. Claiming otherwise would
  // be the exact dishonesty the plan forbids, so L4 is UNKNOWN by construction
  // unless a probe backend actually exercised the artifact.
  const triggerable = contracts.filter((c) => c.status === STATUS.PASS
    && (c.artifact.type === ARTIFACT.TOOL || c.artifact.type === ARTIFACT.COMMAND));
  if (triggerable.length > 0) {
    rows.push(row(
      item,
      'plugin',
      STATUS.UNKNOWN,
      LAYER.L4,
      `${triggerable.length} callable artifact(s) were not triggered: constructing a minimal invocation needs a live host, which an external read-only verifier does not mount`,
      { deferred: true },
    ));
  }

  const status = worstStatus(
    rows.filter((r) => r.detail?.deferred !== true)
      .map((r) => r.status)
      .filter((s) => s !== STATUS.PASS_MOUNTED),
  );
  const layer = rows[rows.length - 1]?.layer ?? LAYER.L0;
  return { rows, status, layer, scan };
}

/**
 * Verify one mode (agent preset) through the plan's second ladder.
 *
 * The four dynamic steps the plan names are reproduced against the artefacts a
 * preset switch would consume: compose the rows, detect the bounce-back, diff
 * the surface against the default mode, and fail a mode that changes nothing.
 *
 * @param {object} options
 * @param {any} options.preset - a discovered preset record.
 * @param {string} options.harnessBase - base the roster resolves packages from.
 * @param {string} options.defaultId - the deployment/user default preset id.
 * @param {any} [options.defaultSurface] - the default mode's surface, when known.
 * @param {(preset: any) => any} options.surfaceOf - computes a preset's surface.
 * @param {import('./budget.mjs').Budget} options.budget
 * @returns {Promise<{ rows: any[], status: string, layer: string, surface: any }>}
 */
export async function verifyMode(options) {
  const { preset, defaultId, defaultSurface, surfaceOf, budget } = options;
  // A shadowed directory and the preset that shadows it share an id, so the two
  // rows must be told apart in the table or the report is ambiguous.
  const item = preset.shadowed ? `mode:${preset.id} (shadowed)` : `mode:${preset.id}`;
  const rows = [];

  // ── L0: the mode is discoverable under its own id ─────────────────────────
  if (preset.shadowed) {
    rows.push(row(
      item,
      'mode',
      STATUS.FAILED,
      LAYER.L0,
      `id "${preset.id}" is claimed first by ${preset.shadowedBy.source} at ${preset.shadowedBy.path} — this directory is silently skipped and the mode never appears (bounce-back)`,
      { shadowedBy: preset.shadowedBy },
    ));
    return { rows, status: STATUS.FAILED, layer: LAYER.L0, surface: null };
  }
  rows.push(row(item, 'mode', STATUS.PASS, LAYER.L0, `discovered as id "${preset.id}" from the ${preset.trust} root (${preset.rootSource})`));

  // ── L1: the composition file exists, reads and parses ─────────────────────
  if (!budget.spend(`mode health: ${preset.id}`)) {
    rows.push(row(item, 'mode', STATUS.UNKNOWN, LAYER.L1, 'budget exhausted before the composition could be read'));
    return { rows, status: STATUS.UNKNOWN, layer: LAYER.L1, surface: null };
  }
  const health = options.healthOf(preset);
  if (health.broken !== null) {
    // DSH refuses to compose a broken preset, so this is FAILED, not DEGRADED:
    // the mode cannot be selected at all.
    rows.push(row(
      item,
      'mode',
      STATUS.FAILED,
      health.layer === 'L1' ? LAYER.L1 : LAYER.L2,
      health.broken,
      { resolutionFailures: health.resolution.failures },
    ));
    // Metadata problems are reported even on a broken preset: they are what a
    // human needs in order to fix the row.
    for (const problem of health.metadata.problems) {
      rows.push(row(item, 'mode', STATUS.DEGRADED, LAYER.L3, problem));
    }
    return { rows, status: STATUS.FAILED, layer: health.layer === 'L1' ? LAYER.L1 : LAYER.L2, surface: null };
  }
  rows.push(row(item, 'mode', STATUS.PASS, LAYER.L1, `composition parsed: ${health.rows.length} row(s) from ${health.path.split(/[\\/]/).pop()}`));

  // ── L2: rows are resolvable and mountable ─────────────────────────────────
  const conditionals = health.rows.filter((r) => r.enabled === 'conditional');
  const enabled = health.rows.filter((r) => r.enabled !== false);
  rows.push(row(
    item,
    'mode',
    STATUS.PASS,
    LAYER.L2,
    `${enabled.length}/${health.rows.length} row(s) enabled${conditionals.length ? `, ${conditionals.length} conditional (${conditionals.map((r) => r.condition).join('; ')})` : ''}; all specifiers resolve`,
  ));

  // ── L3: display metadata ──────────────────────────────────────────────────
  if (health.metadata.problems.length > 0) {
    for (const problem of health.metadata.problems) rows.push(row(item, 'mode', STATUS.DEGRADED, LAYER.L3, `preset.yml: ${problem}`));
  } else if (!health.metadata.present) {
    rows.push(row(item, 'mode', STATUS.DEGRADED, LAYER.L3, 'no preset.yml: the mode is listed by id only, with no display name or description'));
  } else {
    rows.push(row(item, 'mode', STATUS.PASS, LAYER.L3, `display name "${health.metadata.fields.name ?? preset.id}"${health.metadata.fields.description ? ', description present' : ', no description'}`));
  }

  // ── L4: switching must actually change something ──────────────────────────
  if (!budget.spend(`mode surface: ${preset.id}`)) {
    rows.push(row(item, 'mode', STATUS.UNKNOWN, LAYER.L4, 'budget exhausted before the surface diff'));
    return { rows, status: worstStatus(rows.map((r) => r.status)), layer: LAYER.L4, surface: null };
  }
  const surface = surfaceOf(preset);

  if (preset.id === defaultId) {
    rows.push(row(item, 'mode', STATUS.PASS, LAYER.L4, `this is the default mode (${surface.tools.length} tool(s), ${surface.prompts.length} prompt section(s)${surface.unscanned.length ? `, ${surface.unscanned.length} package(s) not scannable` : ''})`, { surface }));
  } else if (defaultSurface === null || defaultSurface === undefined) {
    rows.push(row(item, 'mode', STATUS.UNKNOWN, LAYER.L4, `default mode "${defaultId}" could not be resolved, so the surface diff against it is not constructible`));
  } else {
    const addedTools = surface.tools.filter((t) => !defaultSurface.tools.includes(t));
    const removedTools = defaultSurface.tools.filter((t) => !surface.tools.includes(t));
    const addedPrompts = surface.prompts.filter((p) => !defaultSurface.prompts.includes(p));
    const removedPrompts = defaultSurface.prompts.filter((p) => !surface.prompts.includes(p));
    const changedPackages = surface.packages.length !== defaultSurface.packages.length
      || surface.packages.some((p, i) => p !== defaultSurface.packages[i]);
    const changed = addedTools.length > 0 || removedTools.length > 0 || addedPrompts.length > 0
      || removedPrompts.length > 0 || changedPackages;

    const delta = [
      addedTools.length ? `+${addedTools.length} tool(s)` : null,
      removedTools.length ? `-${removedTools.length} tool(s)` : null,
      addedPrompts.length ? `+${addedPrompts.length} prompt section(s)` : null,
      removedPrompts.length ? `-${removedPrompts.length} prompt section(s)` : null,
      changedPackages ? `${surface.packages.length} vs ${defaultSurface.packages.length} package(s)` : null,
    ].filter(Boolean).join(', ');

    if (!changed) {
      rows.push(row(item, 'mode', STATUS.FAILED, LAYER.L4, `composition and surface are identical to the default mode "${defaultId}" — switching to it changes nothing`, { surface, defaultSurface }));
    } else if (surface.unscanned.length > 0) {
      rows.push(row(item, 'mode', STATUS.UNKNOWN, LAYER.L4, `differs from "${defaultId}" (${delta}) but ${surface.unscanned.length} package(s) could not be scanned, so the diff is incomplete`, { surface, diff: { addedTools, removedTools, addedPrompts, removedPrompts } }));
    } else {
      rows.push(row(item, 'mode', STATUS.PASS, LAYER.L4, `differs from default "${defaultId}": ${delta}`, { surface, diff: { addedTools, removedTools, addedPrompts, removedPrompts } }));
    }
  }

  const status = worstStatus(rows.map((r) => r.status));
  return { rows, status, layer: LAYER.L4, surface };
}
