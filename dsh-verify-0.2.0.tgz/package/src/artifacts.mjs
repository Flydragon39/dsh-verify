/**
 * Artifact enumeration (plan §3 and §4 layer L2).
 *
 * A plugin's implementation may be anything; what it *produces* at runtime is
 * one of a fixed set of artifact classes. Enumerating them is what makes a
 * universal verifier possible: a plugin that registers nothing falls out at L2
 * as `PASS (mounted)`, and every other plugin lands in exactly one of the
 * remaining classes.
 *
 * Enumeration here is static and evidence-based. Each artifact records the file
 * and line that declares it, so a report can be checked by a human without
 * trusting the tool. Nothing is inferred from a plugin's name, description or
 * README.
 *
 * @module dsh-verify/artifacts
 */

import { join, relative } from 'node:path';
import { classify, findCallSites, readObjectProperty, asStringLiteral, isArrayLiteral, readStringArray, isObjectLiteral } from './scan.mjs';
import { readTextOrNull, listDir, isDir, shortPath } from './fsutil.mjs';

/** The seven artifact classes. `SIDE_EFFECT` is a terminal, not a failure. */
export const ARTIFACT = Object.freeze({
  TOOL: 'tool',
  COMMAND: 'command',
  HOOK: 'hook',
  SERVICE: 'service',
  PROMPT: 'prompt',
  SLOT: 'slot',
  SIDE_EFFECT: 'side-effect',
});

/** Bilingual labels, so both report locales name the same thing. */
export const ARTIFACT_LABEL = Object.freeze({
  [ARTIFACT.TOOL]: { en: 'tool', zh: '工具' },
  [ARTIFACT.COMMAND]: { en: 'command', zh: '命令' },
  [ARTIFACT.HOOK]: { en: 'hook', zh: '钩子' },
  [ARTIFACT.SERVICE]: { en: 'service', zh: '服务' },
  [ARTIFACT.PROMPT]: { en: 'prompt section', zh: '提示词段' },
  [ARTIFACT.SLOT]: { en: 'UI slot', zh: 'UI 插槽' },
  [ARTIFACT.SIDE_EFFECT]: { en: 'pure side effect', zh: '纯副作用' },
});

/** Human-facing ordering, so reports group artifacts consistently. */
export const ARTIFACT_ORDER = [
  ARTIFACT.TOOL,
  ARTIFACT.COMMAND,
  ARTIFACT.HOOK,
  ARTIFACT.SERVICE,
  ARTIFACT.PROMPT,
  ARTIFACT.SLOT,
];

const MAX_FILES = 60;
const MAX_FILE_BYTES = 1024 * 1024;

/** Basename only: an evidence string should not carry an absolute path. */
function short(file) {
  return String(file).split(/[\\\\/]/).pop();
}

/** 1-based line number of a character offset. */
function lineAt(source, index) {
  let line = 1;
  for (let i = 0; i < index && i < source.length; i += 1) if (source[i] === '\n') line += 1;
  return line;
}

/**
 * The JavaScript files a plugin can register things from.
 *
 * Declared entry points come first (they are what the Loader imports), then the
 * rest of the package's own sources, because a plugin frequently registers from
 * a module the entry merely re-exports.
 *
 * @param {string} dir - package directory.
 * @param {any} manifest - the package's `package.json`.
 * @returns {{ files: string[], truncated: boolean }}
 */
export function collectSourceFiles(dir, manifest) {
  const files = [];
  const seen = new Set();
  const add = (path) => {
    if (path && !seen.has(path) && files.length < MAX_FILES) {
      seen.add(path);
      files.push(path);
    }
  };

  // Declared entry points.
  const entryCandidates = [];
  const main = manifest?.main;
  if (typeof main === 'string') entryCandidates.push(join(dir, main));
  const exportsField = manifest?.exports;
  const collectExportTargets = (value) => {
    if (typeof value === 'string') entryCandidates.push(join(dir, value));
    else if (value && typeof value === 'object') for (const v of Object.values(value)) collectExportTargets(v);
  };
  collectExportTargets(exportsField);
  for (const candidate of entryCandidates) if (readTextOrNull(candidate) !== null) add(candidate);

  // Remaining package sources, breadth-first and bounded.
  const walk = (current, depth) => {
    if (depth > 4 || files.length >= MAX_FILES) return;
    for (const entry of listDir(current)) {
      if (files.length >= MAX_FILES) return;
      const full = join(current, entry.name);
      if (entry.isDirectory()) {
        if (entry.name === 'node_modules' || entry.name.startsWith('.')) continue;
        walk(full, depth + 1);
      } else if (/\.(mjs|cjs|js)$/i.test(entry.name)) {
        const text = readTextOrNull(full);
        if (text !== null && text.length <= MAX_FILE_BYTES) add(full);
      }
    }
  };
  walk(dir, 0);

  return { files, truncated: files.length >= MAX_FILES };
}

/**
 * Scan one plugin package for its runtime artifacts.
 *
 * @param {object} plugin
 * @param {string} plugin.name - module specifier as mounted.
 * @param {string} plugin.dir - package directory.
 * @param {any} plugin.packageJson - the plugin's manifest.
 * @returns {{
 *   name: string, dir: string, version: string,
 *   artifacts: any[], injectedServices: string[], providedServices: string[],
 *   clientEntry: any, filesScanned: number, filesTruncated: boolean, notes: string[]
 * }}
 */
export function scanPluginArtifacts(plugin) {
  const { name, dir, packageJson } = plugin;
  const notes = [];
  const artifacts = [];
  const injectedServices = new Set();
  const providedServices = new Set();

  const { files, truncated } = collectSourceFiles(dir, packageJson);
  if (truncated) notes.push(`source scan capped at ${MAX_FILES} files`);

  /** De-duplicate artifacts that several scanned files would otherwise report. */
  const seenArtifact = new Set();
  const pushArtifact = (artifact) => {
    const key = `${artifact.type}\u0000${artifact.name}\u0000${artifact.file}`;
    if (seenArtifact.has(key)) return;
    seenArtifact.add(key);
    artifacts.push(artifact);
  };

  /** Capability ids the plugin publishes, e.g. `web.fetchProvider = 'safe-http'`. */
  const capabilities = [];
  const moduleContract = { names: [], inject: [], applyPresent: false, configSchemaPresent: false };
  /** Registrations whose capability id must be resolved across files afterwards. */
  const pendingCapabilities = [];
  const sources = [];

  for (const file of files) {
    const source = readTextOrNull(file);
    if (source === null) continue;
    const { kinds } = classify(source);
    const rel = file;
    sources.push({ file, source, kinds });

    scanTools(source, kinds, file, rel, pushArtifact);
    scanPromptSections(source, kinds, file, rel, pushArtifact, notes);
    scanCommands(source, kinds, file, rel, pushArtifact);
    scanHooks(source, kinds, file, rel, pushArtifact);
    scanServices(source, kinds, file, rel, injectedServices, providedServices, pushArtifact);
    scanRegistrations(source, kinds, file, pushArtifact, pendingCapabilities);
    if (file === files[0]) mergeModuleContract(moduleContract, scanModuleContract(source, kinds));
  }

  // Capability ids often live in a different file from the registration: the
  // shipped `dsh-safe-web-fetch` registers `new SafeWebFetchProvider(...)` in
  // `index.js` while the class carrying `id = 'safe-http'` sits in
  // `provider.js`. Resolve those references once every source is in hand.
  resolveCapabilityIds(sources, pendingCapabilities, capabilities);

  for (const service of moduleContract.inject) injectedServices.add(service);
  for (const declared of moduleContract.names) {
    pushArtifact({
      type: ARTIFACT.SERVICE,
      name: `${declared} (module name)`,
      file: join(dir, 'package.json'),
      line: 1,
      detail: { role: 'identity', service: declared },
    });
  }

  // Declared UI surface travels in the manifest, not the source.
  const clientDecl = packageJson?.dsh?.client;
  let clientEntry = null;
  if (clientDecl && typeof clientDecl === 'object') {
    const platform = typeof clientDecl.platform === 'string' ? clientDecl.platform : 'unknown';
    const inject = Array.isArray(clientDecl.inject) ? clientDecl.inject.filter((v) => typeof v === 'string') : [];
    const targets = [];
    const exportsField = packageJson?.exports;
    if (exportsField && typeof exportsField === 'object' && typeof exportsField['./client'] === 'string') {
      targets.push(exportsField['./client']);
    } else if (exportsField && typeof exportsField === 'object' && exportsField['./client']?.default) {
      targets.push(exportsField['./client'].default);
    } else if (isDir(join(dir, 'lib')) && readTextOrNull(join(dir, 'lib', 'client.js')) !== null) {
      targets.push('./lib/client.js');
    }
    clientEntry = {
      platform,
      inject,
      entry: targets[0] ?? null,
      entryExists: targets.length > 0 ? readTextOrNull(join(dir, targets[0])) !== null : false,
    };
    pushArtifact({
      type: ARTIFACT.SLOT,
      name: `client:${platform}`,
      file: join(dir, 'package.json'),
      line: 1,
      detail: { platform, inject, entry: clientEntry.entry, entryExists: clientEntry.entryExists },
    });
    for (const dep of inject) injectedServices.add(dep);
  }

  if (artifacts.length === 0) {
    artifacts.push({
      type: ARTIFACT.SIDE_EFFECT,
      name: name,
      file: files[0] ?? join(dir, 'package.json'),
      line: 1,
      detail: { reason: 'no tool, command, hook, service, prompt section or UI slot declaration found' },
    });
  }

  return {
    name,
    dir,
    version: packageJson?.version ?? '',
    artifacts,
    injectedServices: [...injectedServices],
    providedServices: [...providedServices],
    capabilities,
    moduleContract,
    clientEntry,
    filesScanned: files.length,
    filesTruncated: truncated,
    notes,
  };
}

/**
 * A real Cordis service key is a plain identifier: `settings`, `tools`,
 * `webServer`, `systemPrompt`.
 *
 * `inject` arrays also carry things that are *not* service keys — type tokens
 * (`@scope/pkg#Session`), route patterns (`/api`), and template literals that
 * build a runtime label (`api-gateway: ${path}`). Treating those as service
 * requirements would bury the real findings under noise, so they are filtered
 * out here rather than reported as unresolvable.
 *
 * @param {string} value
 * @returns {boolean}
 */
export function isPlausibleServiceKey(value) {
  if (typeof value !== 'string' || value === '') return false;
  if (value.includes('${')) return false;
  if (/[#/\\\s]/.test(value)) return false;
  return /^[A-Za-z_$][\w$.-]*$/.test(value);
}

/**
 * Read the Cordis module contract off a plugin's source.
 *
 * A Cordis plugin is an ES module whose contract is carried by named exports:
 * `name` (the id the loader reports), `inject` (required services), `Config`
 * (its configuration schema) and `apply` (the mount function). Some plugins
 * write `export const name = …` inline; others assemble plain consts and
 * re-export them in a single `export { … }` list, which is what the shipped
 * `dsh-free-search` does. Both forms are read here.
 *
 * @param {string} source
 * @param {Uint8Array} kinds
 * @returns {{ names: string[], inject: string[], applyPresent: boolean, configSchemaPresent: boolean }}
 */
export function scanModuleContract(source, kinds) {
  const contract = { names: [], inject: [], applyPresent: false, configSchemaPresent: false };

  const constString = (identifier) => {
    // Single- and double-quoted only: a backtick form is computed at runtime
    // (e.g. a lock-file path built from a hash) and is not a stable identity.
    const re = new RegExp(`(?:^|[\\s;])(?:export\\s+)?const\\s+${identifier}\\s*=\\s*(['"])((?:\\\\.|(?!\\1)[\\s\\S])*?)\\1`, 'g');
    const found = [];
    let m;
    while ((m = re.exec(source)) !== null) {
      if (kinds[m.index] === 0 && m[2] !== '' && !m[2].includes('${')) found.push(m[2]);
    }
    return found;
  };

  const constArray = (identifier) => {
    const re = new RegExp(`(?:^|[\\s;])(?:export\\s+)?const\\s+${identifier}\\s*=\\s*(\\[[\\s\\S]*?\\])`, 'g');
    const found = [];
    let m;
    while ((m = re.exec(source)) !== null) {
      if (kinds[m.index] !== 0) continue;
      // `inject` may be a bare array of names, or an object describing required
      // and optional services; both spellings appear in the shipped packages.
      found.push(...readStringArray(m[1].replace(/`[^`]*`/g, '')));
    }
    return found;
  };

  const exportedNames = [];
  const exportList = /export\s*\{([^}]*)\}/g;
  let m;
  while ((m = exportList.exec(source)) !== null) {
    if (kinds[m.index] !== 0) continue;
    for (const part of m[1].split(',')) {
      const cleaned = part.trim().split(/\s+as\s+/);
      const local = (cleaned[1] ?? cleaned[0] ?? '').trim();
      if (/^[A-Za-z_$][\w$]*$/.test(local)) exportedNames.push(local);
    }
  }

  contract.names.push(...constString('name'));
  contract.inject.push(...constArray('inject'));

  // `export { name, inject, Config, apply }` — the local const form.
  if (exportedNames.length > 0) {
    if (exportedNames.includes('name') && contract.names.length === 0) contract.names.push(...constString('name'));
    if (exportedNames.includes('inject') && contract.inject.length === 0) contract.inject.push(...constArray('inject'));
    if (exportedNames.includes('apply')) contract.applyPresent = true;
    if (exportedNames.includes('Config')) contract.configSchemaPresent = true;
  }

  if (/(?:export\s+)?(?:async\s+)?function\s+apply\s*\(/.test(source)) contract.applyPresent = true;
  if (/(?:export\s+)?const\s+apply\s*=/.test(source)) contract.applyPresent = true;
  if (/(?:export\s+)?const\s+Config\s*=/.test(source)) contract.configSchemaPresent = true;

  return contract;
}

/** Fold one file's module contract into the plugin-wide contract. */
function mergeModuleContract(target, source) {
  for (const name of source.names) if (!target.names.includes(name)) target.names.push(name);
  for (const dep of source.inject) if (!target.inject.includes(dep)) target.inject.push(dep);
  target.applyPresent ||= source.applyPresent;
  target.configSchemaPresent ||= source.configSchemaPresent;
}

/** Registration verbs that publish something consumable rather than registering a tool. */
const REGISTRATION_VERB = /\bctx\s*\.\s*([A-Za-z_$][\w$]*)\s*\.\s*((?:register|provide|install|mount|declare|add)[A-Za-z]*)\s*\(/g;

/**
 * Find service/capability registrations: `ctx.web.registerSearchProvider(p)`,
 * `ctx.settings.installSection(...)`, `ctx.webServer.register(route)`.
 *
 * These are the artifacts the plan calls *services* — something another plugin
 * consumes through `inject`. The namespace and verb are kept because they are
 * the only honest description available without mounting the plugin.
 *
 * When the registered value is a named constant, its `id` field is the
 * capability id the composition's config refers to (`fetchProvider:
 * safe-http`), which is what makes a dangling reference detectable.
 */
function scanRegistrations(source, kinds, file, push, pendingCapabilities) {
  const regex = new RegExp(REGISTRATION_VERB.source, REGISTRATION_VERB.flags);
  let match;
  while ((match = regex.exec(source)) !== null) {
    if (kinds[match.index] !== 0) continue;
    const namespace = match[1];
    const verb = match[2];

    // Tool/command/hook registries are already reported under their own class.
    if (namespace === 'tools' || namespace === 'commands' || namespace === 'systemPrompt') continue;

    const site = findCallSites(source, kinds, new RegExp(`ctx\\s*\\.\\s*${namespace}\\s*\\.\\s*${verb}\\b`))
      .find((s) => s.index >= match.index);
    const args = site ? site.args.trim() : '';

    const artifact = {
      type: ARTIFACT.SERVICE,
      name: `${namespace}.${verb}()`,
      file,
      line: lineAt(source, match.index),
      detail: { role: 'register', namespace, verb, capabilityId: null, capabilityEvidence: null },
    };
    push(artifact);

    if (/Provider\b/.test(verb)) {
      pendingCapabilities.push({
        file,
        line: artifact.line,
        namespace,
        verb,
        args,
        artifact,
      });
    }
  }
}

/**
 * Resolve every pending provider registration to the capability id it
 * publishes, searching all of the plugin's files.
 *
 * Four strategies, in decreasing confidence:
 *   1. the registered value is a bare identifier declared in the same file;
 *   2. it is `new ClassName(...)` and `ClassName` declares an `id` field
 *      somewhere in the package — as `class X {`, or as the class-expression
 *      form a bundler emits, `var X = class {`;
 *   3. that `id` field is an identifier rather than a literal, and exactly one
 *      string constant of that name is declared in the package
 *      (`const DEEPSEEK_PROVIDER_ID = "deepseek-official"`);
 *   4. exactly one class/object in the package declares an `id` literal and the
 *      package registers exactly one provider — unambiguous, so accepted.
 *
 * Anything else stays unresolved on purpose: a guessed capability id would
 * turn a genuinely dangling config reference into a false PASS.
 */
function resolveCapabilityIds(sources, pending, capabilities) {
  if (pending.length === 0) return;

  /** Every `id` literal a class or object declares anywhere in the package. */
  const declaredIds = [];
  /** Every `const NAME = 'literal'` anywhere in the package, for strategy 3. */
  const stringConstants = new Map();
  for (const { file, source, kinds } of sources) {
    const re = /(?:^|[{;\s])id\s*[:=]\s*(['"`])([\w.:@/-]+)\1/g;
    let m;
    while ((m = re.exec(source)) !== null) {
      if (kinds[m.index] !== 0) continue;
      declaredIds.push({ id: m[2], file, index: m.index, line: lineAt(source, m.index) });
    }

    const constRe = /\b(?:const|let|var)\s+([A-Za-z_$][\w$]*)\s*=\s*(['"`])([\w.:@/-]+)\2/g;
    while ((m = constRe.exec(source)) !== null) {
      if (kinds[m.index] !== 0) continue;
      const name = m[1];
      const value = m[3];
      const owners = stringConstants.get(name) ?? new Set();
      owners.add(`${value}\u0000${file}\u0000${lineAt(source, m.index)}`);
      stringConstants.set(name, owners);
    }
  }

  for (const entry of pending) {
    let resolved = null;

    const bareIdentifier = /^([A-Za-z_$][\w$]*)/.exec(entry.args)?.[1];
    const classIdentifier = /^new\s+([A-Za-z_$][\w$]*)/.exec(entry.args)?.[1];
    const wanted = classIdentifier ?? bareIdentifier;

    if (wanted) {
      // Find the declaration of `wanted` and read an `id` from its body.
      // Two declaration shapes matter: `class X {`, and the class-expression
      // form `var X = class {` that esbuild emits when it bundles TypeScript.
      // Missing the second shape is what made every bundled provider look
      // unpublished — and therefore every legitimate config binding look
      // dangling.
      for (const { file, source, kinds } of sources) {
        const declRe = new RegExp(
          `(?:const|let|var)\\s+${wanted}\\s*=\\s*(\\{|class\\s*\\{)|class\\s+${wanted}\\b[^{]*\\{`,
          'g',
        );
        let decl;
        while ((decl = declRe.exec(source)) !== null) {
          if (kinds[decl.index] !== 0) continue;
          const open = source.indexOf('{', decl.index + decl[0].length - 1);
          if (open === -1) continue;
          const body = balancedFrom(source, kinds, open);
          if (!body) continue;
          const idMatch = /(?:^|[{;\s])id\s*[:=]\s*(?:([A-Za-z_$][\w$]*)|(['"`])([\w.:@/-]+)\2)/.exec(body);
          if (!idMatch) continue;
          const idLine = lineAt(source, open + idMatch.index);
          if (idMatch[3] !== undefined) {
            resolved = { id: idMatch[3], file, line: idLine, via: `${wanted}` };
          } else {
            // Strategy 3: the field points at a constant. Accept it only when
            // that constant has exactly one value across the package, so an
            // ambiguous name cannot silently become a wrong capability id.
            const owners = stringConstants.get(idMatch[1]);
            if (owners && owners.size === 1) {
              const [value, ownerFile, ownerLine] = [...owners][0].split('\u0000');
              resolved = {
                id: value,
                file: ownerFile,
                line: Number(ownerLine),
                via: `${wanted} → ${idMatch[1]}`,
              };
            }
          }
          if (resolved) break;
        }
        if (resolved) break;
      }
    }

    if (!resolved && pending.length === 1 && declaredIds.length === 1) {
      const only = declaredIds[0];
      resolved = { id: only.id, file: only.file, line: only.line, via: 'sole id literal in package' };
    }

    if (!resolved) continue;
    entry.capabilityId = resolved.id;
    entry.capabilityEvidence = `${resolved.via} @${resolved.file.split(/[\\/]/).pop()}:${resolved.line}`;
    entry.artifact.detail.capabilityId = resolved.id;
    entry.artifact.detail.capabilityEvidence = entry.capabilityEvidence;
    capabilities.push({
      id: resolved.id,
      via: `${entry.namespace}.${entry.verb}()`,
      file: resolved.file,
      line: resolved.line,
      registeredAt: entry.file,
      registeredLine: entry.line,
    });
  }
}

/** Source text from an opening brace to its match, or null. */
function balancedFrom(source, kinds, openIndex) {
  let depth = 0;
  for (let i = openIndex; i < source.length; i += 1) {
    if (kinds[i] !== 0) continue;
    const c = source[i];
    if (c === '{' || c === '[' || c === '(') depth += 1;
    else if (c === '}' || c === ']' || c === ')') {
      depth -= 1;
      if (depth === 0) return source.slice(openIndex, i + 1);
    }
  }
  return null;
}

function scanTools(source, kinds, file, rel, push) {
  // defineTool({ name: 'x', description, parameters|inputSchema, ... })
  for (const site of findCallSites(source, kinds, /\bdefineTool\b/)) {
    if (!site.objectLiteral) continue;
    const objKinds = classify(site.objectLiteral).kinds;
    const nameProp = readObjectProperty(site.objectLiteral, 'name', objKinds);
    const toolName = nameProp ? asStringLiteral(nameProp.raw) : null;
    const descProp = readObjectProperty(site.objectLiteral, 'description', objKinds);
    const paramsProp = readObjectProperty(site.objectLiteral, 'parameters', objKinds)
      ?? readObjectProperty(site.objectLiteral, 'inputSchema', objKinds)
      ?? readObjectProperty(site.objectLiteral, 'schema', objKinds);
    const outputProp = readObjectProperty(site.objectLiteral, 'output', objKinds);
    push({
      type: ARTIFACT.TOOL,
      name: toolName ?? `<unnamed defineTool @${short(rel)}:${lineAt(source, site.index)}>`,
      file,
      line: lineAt(source, site.index),
      detail: {
        named: toolName !== null,
        hasDescription: descProp !== null && (asStringLiteral(descProp.raw) ?? descProp.raw).length > 0,
        hasParameters: paramsProp !== null && isObjectLiteral(paramsProp.raw),
        hasOutputSchema: outputProp !== null,
      },
    });
  }

  // A register call with no matching defineTool means a tool we cannot name.
  const registerSites = findCallSites(source, kinds, /\btools\s*\.\s*register\b/);
  const namedTools = [...findCallSites(source, kinds, /\bdefineTool\b/)].length;
  if (registerSites.length > namedTools) {
    for (let i = namedTools; i < registerSites.length; i += 1) {
      push({
        type: ARTIFACT.TOOL,
        name: `<dynamic tool #${i + 1} @${short(rel)}:${lineAt(source, registerSites[i].index)}>`,
        file,
        line: lineAt(source, registerSites[i].index),
        detail: { named: false, reason: 'registered without a statically readable defineTool literal' },
      });
    }
  }
}

function scanPromptSections(source, kinds, file, rel, push, notes) {
  for (const callee of [/\bsystemPrompt\s*\.\s*section\b/, /\bsystemPrompt\s*\.\s*register\b/]) {
    for (const site of findCallSites(source, kinds, callee)) {
      const objKinds = site.objectLiteral ? classify(site.objectLiteral).kinds : null;
      const nameProp = site.objectLiteral ? readObjectProperty(site.objectLiteral, 'name', objKinds) : null;
      const textProp = site.objectLiteral ? readObjectProperty(site.objectLiteral, 'text', objKinds) : null;
      const dynamic = site.objectLiteral === null;
      push({
        type: ARTIFACT.PROMPT,
        name: nameProp ? (asStringLiteral(nameProp.raw) ?? nameProp.raw.slice(0, 40)) : `<section @${short(rel)}:${lineAt(source, site.index)}>`,
        file,
        line: lineAt(source, site.index),
        detail: {
          named: nameProp !== null,
          hasText: textProp !== null || dynamic,
          dynamic,
        },
      });
    }
  }
}

function scanCommands(source, kinds, file, rel, push) {
  for (const callee of [/\bcommands?\s*\.\s*register\b/, /\bctx\s*\.\s*command\b/]) {
    for (const site of findCallSites(source, kinds, callee)) {
      const objKinds = site.objectLiteral ? classify(site.objectLiteral).kinds : null;
      const nameProp = site.objectLiteral ? readObjectProperty(site.objectLiteral, 'name', objKinds) : null;
      push({
        type: ARTIFACT.COMMAND,
        name: nameProp ? (asStringLiteral(nameProp.raw) ?? nameProp.raw.slice(0, 40)) : `<command @${short(rel)}:${lineAt(source, site.index)}>`,
        file,
        line: lineAt(source, site.index),
        detail: { named: nameProp !== null },
      });
    }
  }
}

function scanHooks(source, kinds, file, rel, push) {
  const seen = new Set();
  for (const callee of [/\bctx\s*\.\s*on\b/, /\bsctx\s*\.\s*on\b/, /\bcontext\s*\.\s*on\b/]) {
    for (const site of findCallSites(source, kinds, callee)) {
      const firstArg = site.args.trim();
      const eventName = /^['"`]([^'"`]+)['"`]/.exec(firstArg);
      if (!eventName) continue;
      const key = `${eventName[1]}\u0000${site.index}`;
      if (seen.has(key)) continue;
      seen.add(key);
      push({
        type: ARTIFACT.HOOK,
        name: eventName[1],
        file,
        line: lineAt(source, site.index),
        detail: { named: true },
      });
    }
  }
}

function scanServices(source, kinds, file, rel, injected, provided, push) {
  for (const site of findCallSites(source, kinds, /\b(?:ctx|sctx|context)\s*\.\s*inject\b/)) {
    const firstArg = site.args.slice(0, firstArgBoundary(site.args));
    for (const service of readStringArray(firstArg.replace(/`[^`]*`/g, ''))) {
      if (!isPlausibleServiceKey(service)) continue;
      injected.add(service);
      push({
        type: ARTIFACT.SERVICE,
        name: `${service} (inject)`,
        file,
        line: lineAt(source, site.index),
        detail: { role: 'inject', service },
      });
    }
  }

  for (const callee of [/\b(?:ctx|sctx|context)\s*\.\s*provide\b/, /\b(?:ctx|sctx|context)\s*\.\s*set\b/]) {
    for (const site of findCallSites(source, kinds, callee)) {
      const first = asStringLiteral(site.args.slice(0, firstArgBoundary(site.args)).trim());
      if (!first) continue;
      provided.add(first);
      push({
        type: ARTIFACT.SERVICE,
        name: `${first} (provide)`,
        file,
        line: lineAt(source, site.index),
        detail: { role: 'provide', service: first },
      });
    }
  }
}

/**
 * Length of the first argument in `args`, stopping at a depth-0 comma.
 *
 * The classification must be computed over `args` itself: passing the
 * whole-file classification and indexing it with a slice-relative offset reads
 * unrelated characters, which silently splices neighbouring string literals
 * into the extracted value.
 */
function firstArgBoundary(args) {
  const { kinds } = classify(args);
  let depth = 0;
  for (let i = 0; i < args.length; i += 1) {
    if (kinds[i] !== 0) continue;
    const c = args[i];
    if (c === '(' || c === '[' || c === '{') depth += 1;
    else if (c === ')' || c === ']' || c === '}') depth -= 1;
    else if (c === ',' && depth === 0) return i;
  }
  return args.length;
}

/** Group artifacts by class, in the canonical order. */
export function groupArtifacts(artifacts) {
  const groups = new Map();
  for (const type of [...ARTIFACT_ORDER, ARTIFACT.SIDE_EFFECT]) groups.set(type, []);
  for (const artifact of artifacts) {
    if (!groups.has(artifact.type)) groups.set(artifact.type, []);
    groups.get(artifact.type).push(artifact);
  }
  return groups;
}
