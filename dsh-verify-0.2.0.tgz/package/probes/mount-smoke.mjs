/**
 * Isolated mount probe.
 *
 * Runs in its own child process, one plugin per invocation. It imports the
 * plugin's entry module and, when the module exposes an `apply` function,
 * calls it once against a recording stub context. The only output is a single
 * JSON line on stdout.
 *
 * Why a separate process: a plugin that throws at import, blocks forever,
 * monkey-patches globals, or calls `process.exit` must not be able to damage
 * the verifier or its report. The parent enforces a hard timeout and reads only
 * the JSON line, so a chatty or hostile plugin cannot corrupt the result.
 *
 * The stub context is deliberately minimal and *honest*: it records which
 * registrations a plugin attempts rather than pretending to be a working
 * harness. `apply` is therefore expected to fail when a plugin needs a real
 * service, and that outcome is reported as `skipped` with a reason, never as a
 * plugin defect.
 *
 * Usage:
 *   node mount-smoke.mjs --plugin <package-dir> [--name <specifier>] [--no-apply]
 *
 * @module dsh-verify/probes/mount-smoke
 */

import { pathToFileURL } from 'node:url';
import { readFileSync, writeFileSync, existsSync } from 'node:fs';
import { join, isAbsolute, resolve } from 'node:path';
/**
 * Emit exactly one JSON result and exit.
 *
 * The payload goes to stdout *and*, when the parent passed `--out <file>`, to
 * that file as well. Both channels are attempted on purpose:
 *
 * - stdout is what the parent normally reads;
 * - the file keeps the probe working where a confined sandbox refuses to hand
 *   the child a pipe at all.
 *
 * Writing the file *instead of* stdout — as an earlier revision did — silently
 * produced no result whenever a pipe was available, because the parent only
 * fell back to the file when spawning itself failed. Attempting both, and
 * letting the parent read whichever channel carries data, removes the
 * dependency on guessing which one worked.
 */
let outFile = null;
function emit(payload) {
  const line = JSON.stringify(payload);
  if (outFile) {
    try {
      writeFileSync(outFile, line, 'utf8');
    } catch { /* the parent may not need the file at all */ }
  }
  try {
    process.stdout.write(`${line}\n`);
  } catch { /* stdout denied; the file above is the fallback */ }
}

/**
 * Resolve a bare specifier from one of the harness's own module roots.
 *
 * DSH loads a plugin's peer dependencies (`@deepseek-ai/dsh-settings` and
 * friends) through the harness installation, not through the plugin's
 * directory. A plain `import()` started from the plugin cannot see those roots,
 * so a missing peer there is a limit of the probe, not a property of the
 * plugin. When the specifier *is* present under one of the roots the parent
 * passed with `--resolve-root`, the import failure is classified inconclusive
 * and the ladder records UNKNOWN rather than accusing a working plugin.
 *
 * @param {string} specifier - the bare specifier from the error message.
 * @param {string[]} roots - node_modules directories, in precedence order.
 * @returns {string|null} the root that provides it, or null.
 */
function findInRoots(specifier, roots) {
  const segments = specifier.split('/');
  for (const root of roots) {
    const dir = join(root, ...segments);
    if (existsSync(join(dir, 'package.json'))) return dir;
  }
  return null;
}

/** Resolve the module a package's manifest points at. */
function resolveEntry(dir, manifest) {
  const exportsField = manifest?.exports;
  const fromExports = (() => {
    if (typeof exportsField === 'string') return exportsField;
    if (exportsField && typeof exportsField === 'object') {
      const root = exportsField['.'];
      if (typeof root === 'string') return root;
      if (root && typeof root === 'object') return root.import ?? root.default ?? root.require ?? null;
    }
    return null;
  })();
  const relative = fromExports ?? manifest?.main ?? 'index.js';
  const path = isAbsolute(relative) ? relative : resolve(dir, relative);
  return existsSync(path) ? path : null;
}

/**
 * A recording stub context.
 *
 * Every property access yields another recording stub, so `ctx.web.register(...)`
 * and `ctx.tools.register(...)` both succeed and are recorded by their path.
 * Calls that a plugin uses to *read* host state (`ctx.get`, `ctx.inject`) are
 * given neutral answers so a well-behaved plugin can finish its synchronous
 * setup without a live harness.
 */
function createStubContext() {
  const calls = [];
  const proxies = new WeakMap();

  const makeStub = (path) => {
    const target = function stub() {};
    const handler = {
      get(_t, property) {
        if (property === Symbol.toPrimitive || property === 'then') return undefined;
        if (property === 'toString') return () => `[stub ${path}]`;
        if (property === Symbol.toStringTag) return `Stub(${path})`;
        if (property === '__calls') return calls;
        const child = path === '' ? String(property) : `${path}.${property}`;
        return makeStub(child);
      },
      apply(_t, _thisArg, args) {
        calls.push({ path, args: args.length });
        // `ctx.get('service')` / `ctx.inject([...], cb)` are reads: answer
        // neutrally instead of returning another stub, so plugins that branch
        // on availability take their "absent" path rather than crashing.
        if (path.endsWith('.get') || path === 'get') return undefined;
        if (path.endsWith('.inject') || path === 'inject') return () => {};
        if (path.endsWith('.effect') || path === 'effect') {
          const fn = args[0];
          if (typeof fn === 'function') {
            const dispose = fn();
            return typeof dispose === 'function' ? dispose : () => {};
          }
          return () => {};
        }
        return undefined;
      },
      has() { return true; },
    };
    if (proxies.has(target)) return proxies.get(target);
    const proxy = new Proxy(target, handler);
    proxies.set(target, proxy);
    return proxy;
  };

  return { ctx: makeStub('ctx'), calls };
}

async function main() {
  const argv = process.argv.slice(2);
  const readFlag = (flag) => {
    const index = argv.indexOf(flag);
    return index === -1 ? null : argv[index + 1] ?? null;
  };
  const readAllFlags = (flag) => {
    const out = [];
    for (let i = 0; i < argv.length; i += 1) {
      if (argv[i] === flag && i + 1 < argv.length) out.push(argv[i + 1]);
    }
    return out;
  };

  const dir = readFlag('--plugin');
  const name = readFlag('--name') ?? dir;
  const skipApply = argv.includes('--no-apply');
  const resolveRoots = readAllFlags('--resolve-root');
  outFile = readFlag('--out');

  if (!dir) {
    emit({ ok: false, error: 'missing --plugin' });
    return;
  }

  const manifestPath = join(dir, 'package.json');
  let manifest = null;
  try {
    manifest = JSON.parse(readFileSync(manifestPath, 'utf8'));
  } catch (error) {
    emit({ ok: false, error: `cannot read package.json: ${error.message}` });
    return;
  }

  const entry = resolveEntry(dir, manifest);
  if (entry === null) {
    emit({ ok: false, error: `no resolvable entry module (exports/main missing, or the file does not exist)` });
    return;
  }

  let module;
  try {
    module = await import(pathToFileURL(entry).href);
  } catch (error) {
    const message = error?.message ?? String(error);
    // A missing *peer* that the harness supplies is the probe's blind spot, not
    // a plugin defect: DSH resolves those through the installation, and this
    // process was started from the plugin's directory. Report it as
    // inconclusive so the ladder defers instead of failing a working plugin.
    const missing = /Cannot find package '([^']+)'/.exec(message);
    const providedBy = missing ? findInRoots(missing[1], resolveRoots) : null;
    if (providedBy) {
      emit({
        ok: false,
        inconclusive: true,
        stage: 'import',
        error: `import needs "${missing[1]}", which DSH supplies from ${providedBy}; the isolated probe resolves modules from the plugin's own directory and cannot reproduce that`,
        note: 'not a plugin defect — rerun inside DSH to observe the mount',
      });
      return;
    }
    emit({ ok: false, error: `import threw: ${message}`, stage: 'import' });
    return;
  }

  const apply = module.apply ?? module.default ?? null;
  if (typeof apply !== 'function') {
    emit({
      ok: true,
      stage: 'import',
      name: module.name ?? manifest.name ?? null,
      note: 'module exports no apply function; import alone is the whole observable contract',
      registrations: [],
    });
    return;
  }

  if (skipApply) {
    emit({ ok: true, stage: 'import', note: 'apply skipped by request' });
    return;
  }

  const { ctx, calls } = createStubContext();
  // A schema object is the common second argument; passing undefined lets a
  // plugin's own defaults resolve rather than fabricating configuration.
  try {
    await apply(ctx, undefined);
  } catch (error) {
    // A stub context supplies no real services. A failure that names a missing
    // service is the expected outcome for a well-formed plugin and is reported
    // as skipped, not as a defect.
    const message = error?.message ?? String(error);
    const serviceLike = /service|inject|undefined is not|cannot read (properties|property) of (undefined|null)|not a function/i.test(message);
    emit({
      ok: true,
      skipped: serviceLike ? `apply needs a live service the stub context does not provide (${message})` : null,
      error: serviceLike ? null : `apply threw: ${message}`,
      stage: 'apply',
      registrations: calls.slice(0, 50).map((c) => c.path),
    });
    return;
  }

  emit({
    ok: true,
    stage: 'apply',
    note: 'apply completed against the stub context',
    registrations: calls.slice(0, 50).map((c) => c.path),
  });
}

main().catch((error) => {
  emit({ ok: false, error: `probe crashed: ${error?.message ?? String(error)}` });
});
