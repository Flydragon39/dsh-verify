@echo off
setlocal EnableExtensions EnableDelayedExpansion
rem ===========================================================================
rem  dsh-verify - one-click launcher (Windows)
rem
rem  Double-click this file, or run it from any shell with any verifier flags:
rem      run.cmd
rem      run.cmd quick --probe
rem      run.cmd doctor
rem      run.cmd --profile desktop --format markdown --output report.md
rem
rem  It finds its own tool root from its own location, so the checkout works
rem  wherever it sits. No install, no PATH entry, no global package.
rem
rem  This is an EXTERNAL tool: it is not a DSH plugin and not an agent preset.
rem  DSH never loads it, and it never modifies your DSH configuration.
rem ===========================================================================

rem --- Tool root is this script's directory; %~dp0 is always absolute. --------
set "TOOL_ROOT=%~dp0"
if "%TOOL_ROOT:~-1%"=="\" set "TOOL_ROOT=%TOOL_ROOT:~0,-1%"

rem --- Locate a Node runtime -------------------------------------------------
set "NODE_EXE="
if defined DSH_NODE if exist "%DSH_NODE%" set "NODE_EXE=%DSH_NODE%"

if not defined NODE_EXE (
  for /f "delims=" %%I in ('where node 2^>nul') do (
    if not defined NODE_EXE set "NODE_EXE=%%I"
  )
)

rem DSH ships its own Node runtime; use it when PATH has none.
if not defined NODE_EXE (
  set "BUNDLED=%USERPROFILE%\.dsh\dsh-runtimes\dsh-primary-runtime\dependencies\node\bin\node.exe"
  if exist "!BUNDLED!" set "NODE_EXE=!BUNDLED!"
)

if not defined NODE_EXE (
  echo.
  echo   dsh-verify: no Node.js runtime found.
  echo.
  echo   Checked: DSH_NODE, then "node" on PATH, then the runtime DSH ships at
  echo            %%USERPROFILE%%\.dsh\dsh-runtimes\...\node\bin\node.exe
  echo.
  echo   Install Node 18+ from https://nodejs.org, or point DSH_NODE at a
  echo   node.exe, then run this file again.
  echo.
  set "EXIT_CODE=2"
  goto :finish
)

rem --- Run the launcher: no argument opens the interactive menu --------------
"%NODE_EXE%" "%TOOL_ROOT%\bin\dsh-verify-launcher.mjs" %*
set "EXIT_CODE=!ERRORLEVEL!"

:finish
rem --- Keep the window open when double-clicked, but not in a real shell -----
if not defined DSH_VERIFY_NO_PAUSE (
  echo %CMDCMDLINE% | find /i "/c" >nul
  if not errorlevel 1 (
    echo.
    pause
  )
)

endlocal & exit /b %EXIT_CODE%
