/**
 * The verification test suite.
 *
 * Every assertion here is a claim the tool makes about a harness state, checked
 * against a fixture whose break is known exactly. The point is not coverage —
 * it is that each of the plan's silent-failure modes provably produces the
 * verdict the plan says it should.
 *
 * Run: `node --test tests/` or `node tests/verify.test.mjs`
 */

import { test } from 'node:test';
import assert from 'node:assert/strict';
import { join, dirname } from 'node:path';
import { fileURLToPath } from 'node:url';
import { mkdirSync, writeFileSync } from 'node:fs';

import { build, ENV } from './fixtures/build.mjs';
import { verify, makeMountProbe } from '../src/verify.mjs';
import { parseYaml, TaggedValue, YamlError } from '../src/yaml.mjs';
import { Budget } from '../src/budget.mjs';
import { classify, findCallSites, readObjectProperty } from '../src/scan.mjs';
import { composeProfile, classifyGate, GATE } from '../src/compose.mjs';
import { checkPresetHealth, entryListProblem, discoverPresets, resolvePresetRoots } from '../src/modes.mjs';
import { render, renderJUnit, verdictLine, exitCodeFor } from '../src/report.mjs';
import { buildBaseline, diffBaseline } from '../src/baseline.mjs';

const HERE = dirname(fileURLToPath(import.meta.url));
build();

/** Run a verification scoped to the fixture environment. */
function runFixture(overrides = {}) {
  return verify({
    dshHome: ENV,
    install: ENV,
    profile: 'web',
    versionProbe: false,
    includeModes: true,
    ...overrides,
  });
}

/** Find a table row by item and layer. */
function findRow(table, item, layer) {
  return table.rows.find((r) => r.item === item && r.layer === layer);
}

/** Find a table row by item, layer and artifact type. */
function findTypedRow(table, item, layer, type) {
  return table.rows.find((r) => r.item === item && r.layer === layer && r.type === type);
}

// ─────────────────────────────────────────────────────────────────────────────
// The YAML reader
// ─────────────────────────────────────────────────────────────────────────────

test('yaml: reads the document shapes DSH writes', () => {
  const parsed = parseYaml([
    '# a comment',
    'name: demo',
    'count: 3',
    'enabled: true',
    'nothing: null',
    'list:',
    '  - one',
    '  - two',
    'nested:',
    '  key: value',
    'block: |-',
    '  line one',
    '  line two',
    'flow: [a, b, c]',
    'flowmap: {x: 1, y: 2}',
    'gate: !!js process.platform === "win32"',
  ].join('\n'));

  assert.equal(parsed.name, 'demo');
  assert.equal(parsed.count, 3);
  assert.equal(parsed.enabled, true);
  assert.equal(parsed.nothing, null);
  assert.deepEqual(parsed.list, ['one', 'two']);
  assert.deepEqual(parsed.nested, { key: 'value' });
  assert.equal(parsed.block, 'line one\nline two');
  assert.deepEqual(parsed.flow, ['a', 'b', 'c']);
  assert.deepEqual(parsed.flowmap, { x: 1, y: 2 });
});

test('yaml: a custom tag is captured, never evaluated', () => {
  const parsed = parseYaml('gate: !!js process.exit(1)\n');
  assert.ok(parsed.gate instanceof TaggedValue);
  assert.equal(parsed.gate.__tag, '!!js');
  assert.equal(parsed.gate.__expr, 'process.exit(1)');
});

test('yaml: a sequence of mappings keeps each mapping whole', () => {
  const parsed = parseYaml([
    '- id: a',
    '  name: "@scope/a"',
    '  config:',
    '    deep:',
    '      deeper: 1',
    '- id: b',
    '  disabled: true',
  ].join('\n'));
  assert.equal(parsed.length, 2);
  assert.equal(parsed[0].id, 'a');
  assert.deepEqual(parsed[0].config, { deep: { deeper: 1 } });
  assert.equal(parsed[1].disabled, true);
});

test('yaml: malformed input reports the line, it does not guess', () => {
  assert.throws(() => parseYaml('a:\n  b: 1\n   c: 2\n'), YamlError);
});

test('yaml: a comment inside a value is not part of the value', () => {
  const parsed = parseYaml('name: demo  # trailing commentary\nurl: "http://x/#frag"\n');
  assert.equal(parsed.name, 'demo');
  assert.equal(parsed.url, 'http://x/#frag');
});

test('yaml: a plain scalar folds continuation lines into one value', () => {
  // This is how DSH's own presets write a long description. Rejecting it made
  // the whole user layer vanish from the composed tree — the exact silent
  // failure this tool exists to catch — so it is pinned here.
  const parsed = parseYaml([
    'description: 棱镜，证据优先、反方强制的认知安全研究引擎。动态严谨度分级响应 +3',
    '  轮思考预算）；深度通道按固定执行序运行：意图解析 → 三路并行检索',
    '  加权排序）→ 反方视野自动曝光',
    'order: 10',
  ].join('\n'));
  assert.equal(
    parsed.description,
    '棱镜，证据优先、反方强制的认知安全研究引擎。动态严谨度分级响应 +3 轮思考预算）；深度通道按固定执行序运行：意图解析 → 三路并行检索 加权排序）→ 反方视野自动曝光',
  );
  // The key after the folded scalar is still a key, not part of the value.
  assert.equal(parsed.order, 10);
});

test('yaml: a blank line inside a folded scalar becomes a newline', () => {
  assert.equal(parseYaml('k: a\n\n  b\n').k, 'a\nb');
  assert.equal(parseYaml('k: a\n\n\n  b\n').k, 'a\n\nb');
});

test('yaml: a folded scalar inside a sequence entry keeps the entry boundary', () => {
  assert.deepEqual(parseYaml('- v1\n  v2\n- v3\n'), ['v1 v2', 'v3']);
  assert.deepEqual(parseYaml('- k: v1\n    v2\n'), [{ k: 'v1 v2' }]);
});

test('yaml: a comment still ends a plain scalar', () => {
  // js-yaml rejects these too: the comment closes the scalar, so the deeper
  // line that follows has nowhere to belong.
  assert.throws(() => parseYaml('k: a # note\n  b\n'), YamlError);
  assert.throws(() => parseYaml('k: a\n  b # note\n  c\n'), YamlError);
  // A comment on the last line is fine — the scalar ends there anyway.
  assert.equal(parseYaml('k: a\n  b\n  c # note\n').k, 'a b c');
});

test('yaml: a flow scalar may contain a colon that is not a separator', () => {
  // pnpm-lock writes `tarball: file:F:/...`; treating every ':' as a key
  // separator made the whole lockfile unreadable.
  assert.deepEqual(
    parseYaml('resolution: {integrity: sha512-abc==, tarball: file:F:/AI工作/x.tgz}\n').resolution,
    { integrity: 'sha512-abc==', tarball: 'file:F:/AI工作/x.tgz' },
  );
  assert.deepEqual(parseYaml('{a:1}\n'), { 'a:1': null });
  assert.deepEqual(parseYaml('{"a":1}\n'), { a: 1 });
});

// ─────────────────────────────────────────────────────────────────────────────
// The scanner
// ─────────────────────────────────────────────────────────────────────────────

test('scan: a call site inside a string literal is not a call site', () => {
  const source = 'const text = "tools.register(defineTool({ name: \'ghost\' }))";\nexport const real = 1;';
  const { kinds } = classify(source);
  assert.equal(findCallSites(source, kinds, /\btools\s*\.\s*register\b/).length, 0);
});

test('scan: a nested object property does not shadow the outer one', () => {
  const objectSource = "{ name: 'outer', config: { name: 'inner' } }";
  const { kinds } = classify(objectSource);
  const found = readObjectProperty(objectSource, 'name', kinds);
  assert.equal(found.raw, "'outer'");
});

// ─────────────────────────────────────────────────────────────────────────────
// Composition
// ─────────────────────────────────────────────────────────────────────────────

test('compose: a dropped layer becomes a FAILED row, not a footnote', async () => {
  // A patch layer that does not parse leaves its rows out of the composed tree
  // while everything below it still composes. That is the silent failure the
  // plan names first, so the problem must reach the verdict and the exit code —
  // a footnote in the Markdown report is not enough.
  const brokenLayer = join(ENV, 'broken-overlay.yml');
  writeFileSync(brokenLayer, '- id: x\n  config:\n    a: 1\n   b: 2\n', 'utf8');

  const result = await runFixture({ includeModes: false, overlays: [brokenLayer] });
  const table = result.profiles[0];
  const row = table.rows.find((r) => r.type === 'composition');
  assert.ok(row, 'expected a composition row');
  assert.equal(row.status, 'FAILED');
  assert.equal(table.verdicts.failed > 0, true);
  assert.equal(exitCodeFor(result.summary), 1);

  const text = render(result, 'text');
  assert.match(text, /composition:overlay/);
});

test('compose: layers stack in order with last-write-wins per row', () => {
  const composition = composeProfile({ dshHome: ENV, profile: 'web', installAnchor: ENV });
  assert.equal(composition.ok, true, composition.error?.message);

  // The base bundle introduces `tools`; the fixture's own layer never touches it.
  assert.equal(composition.rows.get('tools').introducedBy, '@deepseek-ai/dsh-base');
  // The user layer replaces the whole config of the `web` row.
  const web = composition.rows.get('web');
  assert.equal(web.config.searchProvider, 'acme-search');
  assert.equal(web.lastTouchedBy, 'profile cordis.patch.yml');
});

test('compose: a platform-gated disabled is conditional, not true and not false', () => {
  const composition = composeProfile({ dshHome: ENV, profile: 'web', installAnchor: ENV });
  const gated = composition.rows.get('platform-only');
  assert.equal(gated.gate, GATE.CONDITIONAL);
  assert.equal(gated.gateExpr, "process.platform === 'win32'");
  assert.equal(classifyGate(true).state, GATE.DISABLED);
  assert.equal(classifyGate(undefined).state, GATE.ENABLED);
});

// ─────────────────────────────────────────────────────────────────────────────
// The plugin ladder
// ─────────────────────────────────────────────────────────────────────────────

test('ladder: a healthy plugin passes L0–L3 and defers L4', async () => {
  // acme-dupe is in scope because the two fixtures deliberately share a tool
  // name: the collision is reported on both, and a test that hid one of them
  // would be asserting about a tree that cannot exist.
  const result = await runFixture({ only: ['acme-tools', 'acme-dupe'] });
  const table = result.profiles[0];
  assert.equal(findRow(table, 'acme-tools', 'L0').status, 'PASS');
  assert.equal(findRow(table, 'acme-tools', 'L1').status, 'PASS');
  assert.match(findRow(table, 'acme-tools', 'L2').evidence, /tool×2/);
  assert.equal(findRow(table, 'acme-tools', 'L4').status, 'UNKNOWN');
  assert.equal(findRow(table, 'acme-tools', 'L4').detail.deferred, true);
  assert.equal(table.verdicts.failed, 0);
  // Every other class of acme-tools artefact is well formed.
  assert.equal(findTypedRow(table, 'acme-tools', 'L3', 'prompt section').status, 'PASS');
  assert.equal(findTypedRow(table, 'acme-dupe', 'L3', 'tool').status, 'DEGRADED');
  assert.equal(findTypedRow(table, 'acme-tools', 'L3', 'tool').evidence.includes('acme_echo: '), true);
});

test('ladder: a plugin registering nothing terminates at L2 as PASS(mounted)', async () => {
  const result = await runFixture({ only: ['acme-sideeffect'] });
  const table = result.profiles[0];
  const l2 = findRow(table, 'acme-sideeffect', 'L2');
  assert.equal(l2.status, 'PASS(mounted)');
  assert.match(l2.evidence, /mount success is the whole contract/);
  // The plan is explicit: L2 is terminal, so nothing beyond it is reported.
  assert.equal(table.rows.some((r) => r.item === 'acme-sideeffect' && r.layer === 'L3'), false);
});

test('ladder: a duplicate tool name is DEGRADED at L3', async () => {
  const result = await runFixture({ only: ['acme-dupe', 'acme-tools'] });
  const table = result.profiles[0];
  const l3 = findTypedRow(table, 'acme-dupe', 'L3', 'tool');
  assert.equal(l3.status, 'DEGRADED');
  assert.match(l3.evidence, /also declared by acme-tools/);
});

test('ladder: a dangling provider reference is DEGRADED', async () => {
  const result = await runFixture({ includeModes: false });
  const table = result.profiles[0];
  const dangling = table.rows.find((r) => r.item === 'web :: fetchProvider');
  assert.equal(dangling.status, 'DEGRADED');
  assert.match(dangling.evidence, /matches no capability id/);

  const bound = table.rows.find((r) => r.item === 'web :: searchProvider');
  assert.equal(bound.status, 'PASS');
  assert.match(bound.evidence, /published by acme-provider/);
});

test('ladder: a static run never claims to have observed a mount', async () => {
  const result = await runFixture({ only: ['acme-broken'] });
  const l1 = findRow(result.profiles[0], 'acme-broken', 'L1');
  // Two L1 rows: the manifest check passes, the mount check is deferred.
  const rows = result.profiles[0].rows.filter((r) => r.item === 'acme-broken' && r.layer === 'L1');
  assert.equal(rows.length, 2);
  assert.equal(rows[1].status, 'UNKNOWN');
  assert.match(rows[1].evidence, /unobservable without executing/);
  assert.equal(l1.status, 'PASS');
});

test('ladder: the mount probe turns an import throw into FAILED', async () => {
  const result = await runFixture({ only: ['acme-broken'], probe: true });
  const rows = result.profiles[0].rows.filter((r) => r.item === 'acme-broken' && r.layer === 'L1');
  const mount = rows.find((r) => r.status === 'FAILED' || r.status === 'UNKNOWN' || /probe/.test(r.evidence));
  assert.ok(mount, 'expected a mount-probe row');
  assert.equal(mount.status, 'FAILED');
  assert.match(mount.evidence, /acme-broken: this plugin cannot be loaded/);
});

test('ladder: the mount probe passes a healthy plugin', async () => {
  const result = await runFixture({ only: ['acme-tools'], probe: true });
  const rows = result.profiles[0].rows.filter((r) => r.item === 'acme-tools' && r.layer === 'L1');
  assert.ok(rows.some((r) => r.status === 'PASS' && /isolated probe process/.test(r.evidence)));
  assert.equal(result.profiles[0].verdicts.failed, 0);
});

test('probe: a peer the harness supplies is UNKNOWN, not a plugin defect', async () => {
  // DSH resolves a plugin's peers (`@deepseek-ai/dsh-settings`, …) through the
  // installation. A probe started from the plugin's directory cannot see them,
  // and calling that a FAILED import accuses working plugins. The probe must
  // recognise the case and defer.
  const base = join(ENV, 'probe-peer');
  const pluginDir = join(base, 'plugin');
  mkdirSync(pluginDir, { recursive: true });
  writeFileSync(join(pluginDir, 'package.json'), JSON.stringify({ name: 'probe-peer', version: '1.0.0', type: 'module', main: 'index.js' }), 'utf8');
  writeFileSync(join(pluginDir, 'index.js'), "import 'harness-only-peer';\nexport const name = 'probe-peer';\n", 'utf8');

  const harnessRoot = join(base, 'harness', 'node_modules');
  const peerDir = join(harnessRoot, 'harness-only-peer');
  mkdirSync(peerDir, { recursive: true });
  writeFileSync(join(peerDir, 'package.json'), JSON.stringify({ name: 'harness-only-peer', version: '9.0.0', type: 'module' }), 'utf8');

  const probeScript = join(HERE, '..', 'probes', 'mount-smoke.mjs');
  const plugin = { name: 'probe-peer', dir: pluginDir };

  const blind = await makeMountProbe({ probeScript, budget: new Budget(), captureDir: base })(plugin);
  assert.equal(blind.ok, false);
  assert.notEqual(blind.inconclusive, true);
  assert.match(blind.error, /Cannot find package 'harness-only-peer'/);

  const aware = await makeMountProbe({
    probeScript, budget: new Budget(), captureDir: base, resolveRoots: [harnessRoot],
  })(plugin);
  assert.equal(aware.ok, false);
  assert.equal(aware.inconclusive, true);
  assert.match(aware.error, /harness-only-peer/);
  assert.match(aware.error, /DSH supplies/);
});

test('scope: platform rows are the environment, not the subject', async () => {
  const scoped = await runFixture({ includeModes: false });
  assert.ok(scoped.profiles[0].skippedPlatform > 0);
  assert.equal(scoped.profiles[0].includePlatform, false);

  const all = await runFixture({ includeModes: false, all: true });
  assert.equal(all.profiles[0].skippedPlatform, 0);
  assert.ok(all.profiles[0].rows.length > scoped.profiles[0].rows.length);
});

// ─────────────────────────────────────────────────────────────────────────────
// Modes
// ─────────────────────────────────────────────────────────────────────────────

test('modes: a well-formed distinct preset passes every layer', async () => {
  const result = await runFixture({ pluginsOnly: true });
  const row = result.modes.rows.find((r) => r.item === 'mode:good' && r.layer === 'L4');
  assert.equal(row.status, 'PASS');
  assert.match(row.evidence, /differs from default/);
});

test('modes: a preset whose composition is missing fails at L1', async () => {
  const result = await runFixture({ pluginsOnly: true });
  const row = result.modes.rows.find((r) => r.item === 'mode:no-comp' && r.layer === 'L1');
  assert.equal(row.status, 'FAILED');
  assert.match(row.evidence, /composition file agent\.cordis\.yml is missing/);
});

test('modes: a preset whose composition does not parse fails at L1', async () => {
  const result = await runFixture({ pluginsOnly: true });
  const row = result.modes.rows.find((r) => r.item === 'mode:bad-yaml' && r.layer === 'L1');
  assert.equal(row.status, 'FAILED');
  assert.match(row.evidence, /not valid YAML/);
});

test('modes: an unresolvable row fails at L2 with the row named', async () => {
  const result = await runFixture({ pluginsOnly: true });
  const row = result.modes.rows.find((r) => r.item === 'mode:unresolvable' && r.layer === 'L2');
  assert.equal(row.status, 'FAILED');
  assert.match(row.evidence, /totally-absent-package/);
});

test('modes: a directory whose name is not a valid id is reported as skipped', async () => {
  const result = await runFixture({ pluginsOnly: true });
  const skipped = result.modes.problems.find((p) => p.kind === 'id-skipped');
  assert.ok(skipped, 'expected an id-skipped problem');
  assert.equal(skipped.id, 'Bad_Id');
});

test('modes: an id shadowed by a higher-precedence root fails at L0', async () => {
  const result = await runFixture({ pluginsOnly: true });
  const row = result.modes.rows.find((r) => r.item === 'mode:shadow-tools (shadowed)' && r.layer === 'L0');
  assert.equal(row.status, 'FAILED');
  assert.match(row.evidence, /silently skipped and the mode never appears/);
});

test('modes: a preset identical to the default fails at L4', async () => {
  const result = await runFixture({ pluginsOnly: true });
  const row = result.modes.rows.find((r) => r.item === 'mode:twin' && r.layer === 'L4');
  assert.equal(row.status, 'FAILED');
  assert.match(row.evidence, /switching to it changes nothing/);
});

test('modes: a conditional disabled row is reported, not resolved', async () => {
  const roots = resolvePresetRoots({ dshHome: ENV, homeDirectory: ENV, installAnchor: ENV, rosterConfig: null });
  const { presets } = discoverPresets({ roots, harnessBase: ENV });
  const good = presets.find((p) => p.id === 'good');
  const health = checkPresetHealth(good, ENV);
  assert.equal(health.broken, null);

  const problem = entryListProblem([{ id: 'x', name: 'ok' }, { name: '' }]);
  assert.match(problem, /row 2 names no plugin/);
});

// ─────────────────────────────────────────────────────────────────────────────
// Budget
// ─────────────────────────────────────────────────────────────────────────────

test('budget: the probe ceiling trips before the work, not after', () => {
  const budget = new Budget({ calls: 2, seconds: 60 });
  assert.equal(budget.spend('a'), true);
  assert.equal(budget.spend('b'), true);
  assert.equal(budget.spend('c'), false);
  assert.equal(budget.snapshot().exhaustedBy.dimension, 'calls');
  assert.equal(budget.snapshot().calls, 2);
});

test('budget: static inspections do not consume the probe ceiling', () => {
  const budget = new Budget({ calls: 1, seconds: 60 });
  for (let i = 0; i < 500; i += 1) budget.inspect('read');
  assert.equal(budget.spend('probe'), true);
  assert.equal(budget.snapshot().inspections, 500);
  assert.equal(budget.snapshot().calls, 1);
});

test('budget: the wall clock stops everything', () => {
  let now = 0;
  const budget = new Budget({ calls: 20, seconds: 10, clock: () => now });
  assert.equal(budget.check(), true);
  now = 11_000;
  assert.equal(budget.check(), false);
  assert.equal(budget.spend('too late'), false);
  assert.equal(budget.snapshot().exhaustedBy.dimension, 'seconds');
});

test('budget: exhausting the budget leaves the rest UNKNOWN rather than failing', async () => {
  const result = await runFixture({ budgetSeconds: 0.001, includeModes: false, all: true });
  const unknowns = result.profiles[0].rows.filter((r) => r.status === 'UNKNOWN');
  assert.ok(unknowns.length > 0);
  assert.equal(result.summary.failed, 0);
});

// ─────────────────────────────────────────────────────────────────────────────
// Reporting and the environment guard
// ─────────────────────────────────────────────────────────────────────────────

test('report: the verdict line follows the plan wording', () => {
  assert.equal(verdictLine({ blocked: false, failed: 0, degraded: 0, unknown: 0, deferred: 0 }), 'VERDICT: ALL PASS');
  assert.match(verdictLine({ blocked: false, failed: 1, degraded: 2, unknown: 0, deferred: 0 }), /1 FAILED \| 2 DEGRADED/);
  assert.match(verdictLine({ blocked: true, blockedReason: 'nope' }), /BLOCKED — nope/);
  assert.match(verdictLine({ blocked: false, failed: 0, degraded: 0, unknown: 0, deferred: 3 }), /3 row\(s\) deferred/);
});

test('report: exit codes distinguish findings from a blocked guard', () => {
  assert.equal(exitCodeFor({ blocked: false, failed: 0, degraded: 0 }), 0);
  assert.equal(exitCodeFor({ blocked: false, failed: 1, degraded: 0 }), 1);
  assert.equal(exitCodeFor({ blocked: false, failed: 0, degraded: 1 }), 1);
  assert.equal(exitCodeFor({ blocked: true, failed: 0, degraded: 0 }), 2);
});

test('report: every format renders without throwing', async () => {
  const result = await runFixture();
  for (const format of ['markdown', 'json', 'junit', 'text']) {
    const text = render(result, format);
    assert.equal(typeof text, 'string');
    assert.ok(text.length > 100, `${format} output is suspiciously short`);
  }
  const junit = renderJUnit(result);
  assert.match(junit, /^<\?xml/);
  assert.match(junit, /<testsuites/);
  JSON.parse(render(result, 'json'));
});

test('report: findings appear in the table, passes are not lost', async () => {
  const result = await runFixture();
  const markdown = render(result, 'markdown');
  assert.match(markdown, /# DSH plugin & mode integrity report/);
  assert.match(markdown, /## Modes \(agent presets\)/);
  assert.match(markdown, /acme-tools/);
  assert.match(markdown, /Full table/);
});

test('guard: a missing installation is BLOCKED, and nothing is inspected', async () => {
  const result = await verify({
    dshHome: join(HERE, 'does-not-exist'),
    install: join(HERE, 'does-not-exist-either'),
    profile: 'web',
  });
  assert.equal(result.summary.blocked, true);
  assert.match(result.summary.blockedReason, /not found/);
  assert.equal(result.profiles.length, 0);
  assert.match(verdictLine(result.summary), /BLOCKED/);
  assert.equal(exitCodeFor(result.summary), 2);
});

// ─────────────────────────────────────────────────────────────────────────────
// Baseline
// ─────────────────────────────────────────────────────────────────────────────

test('baseline: an unchanged state diffs clean', async () => {
  const before = await runFixture();
  const baseline = buildBaseline(before);
  const after = await runFixture();
  const diff = diffBaseline(baseline, after);
  assert.equal(diff.isEmpty, true, JSON.stringify(diff.changes.slice(0, 5)));
});

test('baseline: a vanished mode and a vanished plugin are both caught', async () => {
  const before = await runFixture();
  const baseline = buildBaseline(before);

  // Simulate an update that dropped a mode and renamed a plugin row.
  const after = await runFixture();
  delete after.modes.verified.find((e) => e.preset.id === 'good');
  after.modes.verified = after.modes.verified.filter((e) => e.preset.id !== 'good');
  after.modes.rows = after.modes.rows.filter((r) => r.item !== 'mode:good');
  const composition = after.profiles[0].composition;
  composition.rows.delete('acme-tools');
  composition.rows.set('acme-tools-renamed', { id: 'acme-tools-renamed', name: 'acme-tools-v2', gate: 'enabled', config: null });

  const diff = diffBaseline(baseline, after);
  assert.equal(diff.isEmpty, false);
  assert.ok(diff.changes.some((c) => c.kind === 'mode-removed' && c.item === 'good'));
  assert.ok(diff.changes.some((c) => c.kind === 'plugin-removed' && c.item.endsWith('acme-tools')));
  assert.ok(diff.changes.some((c) => c.kind === 'plugin-added' && c.item.endsWith('acme-tools-renamed')));
});

test('baseline: a version change alone is reported', async () => {
  const before = await runFixture();
  const baseline = buildBaseline(before);
  baseline.dshVersion = '0.0.0-old';
  const after = await runFixture();
  const diff = diffBaseline(baseline, after);
  assert.ok(diff.changes.some((c) => c.kind === 'dsh-version'));
});
