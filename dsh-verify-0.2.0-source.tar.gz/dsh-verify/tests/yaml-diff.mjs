/**
 * Differential test: our built-in YAML reader vs `js-yaml` over every YAML file
 * shipped in the local DSH installation and DSH home.
 *
 * `js-yaml` is a DEV-ONLY oracle here. The verifier itself never imports it.
 *
 * Run: node tests/yaml-diff.mjs [--verbose]
 */

import { readFileSync, existsSync, readdirSync, statSync } from 'node:fs';
import { join, extname } from 'node:path';
import { pathToFileURL } from 'node:url';
import { parseYaml, TaggedValue, YamlError } from '../src/yaml.mjs';

const ORACLE_CANDIDATES = [
  'C:/Users/Flydragon/AppData/Local/npm-cache/_npx/1e7f6d9597241db0/node_modules/js-yaml/package.json',
  join(process.env.DSH_HOME ?? '', 'profiles/web/node_modules/js-yaml/package.json'),
];

const verbose = process.argv.includes('--verbose');

async function loadOracle() {
  for (const candidate of ORACLE_CANDIDATES) {
    if (!candidate || !existsSync(candidate)) continue;
    const pkg = JSON.parse(readFileSync(candidate, 'utf8'));
    const entry = join(candidate, '..', pkg.main ?? 'index.js');
    const mod = await import(pathToFileURL(entry).href);
    return mod.default ?? mod;
  }
  return null;
}

/** js-yaml schema that tolerates DSH's `!!js` tag without evaluating it. */
function makeSchema(yaml) {
  const jsTag = new yaml.Type('tag:yaml.org,2002:js', {
    kind: 'scalar',
    construct: (data) => new TaggedValue('!!js', String(data)),
  });
  return yaml.DEFAULT_SCHEMA.extend([jsTag]);
}

const SKIP_DIRS = new Set(['node_modules', '.git', 'sessions', 'storages', 'attachments', '_docx_extract']);

function collectYaml(root, out = [], depth = 0, limit = 4000) {
  if (!root || !existsSync(root) || out.length >= limit || depth > 8) return out;
  let entries;
  try {
    entries = readdirSync(root, { withFileTypes: true });
  } catch {
    return out;
  }
  for (const entry of entries) {
    if (out.length >= limit) break;
    const full = join(root, entry.name);
    if (entry.isDirectory()) {
      if (SKIP_DIRS.has(entry.name)) continue;
      collectYaml(full, out, depth + 1, limit);
    } else if (entry.isFile()) {
      const ext = extname(entry.name).toLowerCase();
      if (ext === '.yml' || ext === '.yaml') {
        try {
          if (statSync(full).size <= 4 * 1024 * 1024) out.push(full);
        } catch { /* unreadable: skip */ }
      }
    }
  }
  return out;
}

/**
 * Structural comparison that treats every TaggedValue as an opaque leaf.
 *
 * The reference parser stores every scalar as a float64, so an integer beyond
 * 2^53 comes back rounded; this reader keeps the exact digits as a string
 * instead of silently losing them. Same YAML scalar, different representation —
 * compare those numerically rather than reporting a false divergence.
 */
function equivalent(a, b, path = '$') {
  if (a instanceof TaggedValue || b instanceof TaggedValue) {
    if (a instanceof TaggedValue && b instanceof TaggedValue) return a.__tag === b.__tag;
    return false;
  }
  if (a === b) return true;
  if (typeof a === 'string' && typeof b === 'number' && /^[+-]?\d+$/.test(a)) return Number(a) === b;
  if (typeof b === 'string' && typeof a === 'number' && /^[+-]?\d+$/.test(b)) return Number(b) === a;
  if (typeof a === 'number' && typeof b === 'number') return Object.is(a, b) || Math.abs(a - b) < 1e-12;
  if (Array.isArray(a) || Array.isArray(b)) {
    if (!Array.isArray(a) || !Array.isArray(b) || a.length !== b.length) return false;
    return a.every((v, i) => equivalent(v, b[i], `${path}[${i}]`));
  }
  if (a && b && typeof a === 'object' && typeof b === 'object') {
    const ka = Object.keys(a).sort();
    const kb = Object.keys(b).sort();
    if (ka.length !== kb.length || ka.some((k, i) => k !== kb[i])) return false;
    return ka.every((k) => equivalent(a[k], b[k], `${path}.${k}`));
  }
  return false;
}

const dshHome = process.env.DSH_HOME ?? 'C:/Users/Flydragon/.dsh';
const install = 'C:/Users/Flydragon/AppData/Local/npm-cache/_npx/1e7f6d9597241db0/node_modules/@deepseek-ai';

const files = [
  ...collectYaml(dshHome),
  ...collectYaml(install, [], 0, 1500),
];

const yaml = await loadOracle();
if (!yaml) {
  console.error('oracle js-yaml not found; cannot run the differential test');
  process.exit(2);
}
const schema = makeSchema(yaml);

let pass = 0;
let mismatch = 0;
let ourError = 0;
const failures = [];

for (const file of files) {
  let text;
  try {
    text = readFileSync(file, 'utf8');
  } catch {
    continue;
  }

  let mine;
  let mineFailed = null;
  try {
    mine = parseYaml(text);
  } catch (error) {
    mineFailed = error;
  }

  let theirs;
  let theirsFailed = null;
  try {
    theirs = yaml.load(text, { schema });
  } catch (error) {
    theirsFailed = error;
  }

  if (mineFailed && theirsFailed) { pass += 1; continue; }
  if (mineFailed && !theirsFailed) {
    ourError += 1;
    failures.push({ file, kind: 'we-rejected-oracle-accepted', detail: mineFailed.message });
    continue;
  }
  if (!mineFailed && theirsFailed) { pass += 1; continue; }
  if (equivalent(mine, theirs)) { pass += 1; continue; }

  mismatch += 1;
  failures.push({ file, kind: 'value-mismatch', detail: describe(mine, theirs) });
}

function describe(mine, theirs, path = '$', depth = 0) {
  if (equivalent(mine, theirs, path)) return null;
  if (depth > 6) return `${path}: <deep>`;
  if (mine instanceof TaggedValue || theirs instanceof TaggedValue) {
    return `${path}: tag ${mine instanceof TaggedValue ? mine.__tag : 'none'} vs ${theirs instanceof TaggedValue ? theirs.__tag : 'none'}`;
  }
  if (Array.isArray(mine) && Array.isArray(theirs)) {
    if (mine.length !== theirs.length) return `${path}: array length ${mine.length} vs ${theirs.length}`;
    for (let i = 0; i < mine.length; i += 1) {
      const d = describe(mine[i], theirs[i], `${path}[${i}]`, depth + 1);
      if (d) return d;
    }
    return `${path}: arrays differ`;
  }
  if (mine && theirs && typeof mine === 'object' && typeof theirs === 'object') {
    const keys = new Set([...Object.keys(mine), ...Object.keys(theirs)]);
    for (const k of keys) {
      if (!(k in mine)) return `${path}.${k}: missing in ours (oracle=${JSON.stringify(theirs[k])?.slice(0, 60)})`;
      if (!(k in theirs)) return `${path}.${k}: extra in ours (ours=${JSON.stringify(mine[k])?.slice(0, 60)})`;
      const d = describe(mine[k], theirs[k], `${path}.${k}`, depth + 1);
      if (d) return d;
    }
    return `${path}: objects differ`;
  }
  return `${path}: ${JSON.stringify(mine)?.slice(0, 80)} vs ${JSON.stringify(theirs)?.slice(0, 80)}`;
}

console.log(`files tested : ${files.length}`);
console.log(`agree        : ${pass}`);
console.log(`value mismatch: ${mismatch}`);
console.log(`we rejected  : ${ourError}`);
if (verbose || failures.length) {
  console.log('\n--- first 25 divergences ---');
  for (const f of failures.slice(0, 25)) {
    console.log(`\n[${f.kind}] ${f.file}`);
    console.log(`  ${f.detail}`);
  }
}
process.exit(mismatch + ourError === 0 ? 0 : 1);
