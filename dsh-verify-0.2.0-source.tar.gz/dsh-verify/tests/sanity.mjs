/**
 * Static sanity pass over the whole tool: every module must import cleanly, the
 * public surface must resolve, and no source file may still carry the mojibake
 * that a non-UTF-8 round-trip would introduce.
 *
 * Run: `node tests/sanity.mjs`
 */

import { readdirSync, readFileSync } from 'node:fs';
import { join, dirname } from 'node:path';
import { fileURLToPath, pathToFileURL } from 'node:url';

const ROOT = dirname(dirname(fileURLToPath(import.meta.url)));
const SRC = join(ROOT, 'src');

let failures = 0;
const fail = (message) => { failures += 1; console.error(`  FAIL  ${message}`); };
const ok = (message) => console.log(`  ok    ${message}`);

// ── Every module imports ─────────────────────────────────────────────────────
const modules = readdirSync(SRC).filter((f) => f.endsWith('.mjs')).sort();
for (const file of modules) {
  try {
    await import(pathToFileURL(join(SRC, file)).href);
    ok(`src/${file}`);
  } catch (error) {
    fail(`src/${file}: ${error.message}`);
  }
}

// ── The probe is standalone ──────────────────────────────────────────────────
try {
  await import(pathToFileURL(join(ROOT, 'probes', 'mount-smoke.mjs')).href);
  // Importing the probe runs `main()` with no arguments, which emits a
  // "missing --plugin" payload. That is the module loading correctly.
  ok('probes/mount-smoke.mjs');
} catch (error) {
  // `main()` may resolve asynchronously; a rejected import is a real failure.
  fail(`probes/mount-smoke.mjs: ${error.message}`);
}

// ── The public surface ───────────────────────────────────────────────────────
try {
  const api = await import(pathToFileURL(join(SRC, 'index.mjs')).href);
  const required = ['verify', 'render', 'exitCodeFor', 'verdictLine', 'parseYaml', 'Budget', 'STATUS', 'ARTIFACT'];
  for (const name of required) if (!(name in api)) fail(`index.mjs does not export "${name}"`);
  ok(`index.mjs exports ${Object.keys(api).length} names`);
} catch (error) {
  fail(`index.mjs: ${error.message}`);
}

// ── The declared version is one version ──────────────────────────────────────
// `--version`, the report header and the package manifest must never disagree.
try {
  const pkg = JSON.parse(readFileSync(join(ROOT, 'package.json'), 'utf8'));
  const { TOOL } = await import(pathToFileURL(join(SRC, 'verify.mjs')).href);
  if (TOOL.version !== pkg.version) fail(`TOOL.version ${TOOL.version} != package.json ${pkg.version}`);
  else ok(`version ${pkg.version} agrees across manifest and code`);
} catch (error) {
  fail(`version check: ${error.message}`);
}

// ── No non-UTF-8 damage ──────────────────────────────────────────────────────
// A CP936/ANSI round-trip leaves these sequences behind. They are never
// legitimate in this codebase.
const MOJIBAKE = /[\u9225\u9229\u8133\u922B\u922C\u9473\u9418\u93C8\u9515]/;
const walk = (dir) => readdirSync(dir, { withFileTypes: true }).flatMap((entry) => {
  const full = join(dir, entry.name);
  if (entry.isDirectory()) return entry.name === 'env' ? [] : walk(full);
  return /\.(mjs|json|md)$/.test(entry.name) ? [full] : [];
});

for (const file of [...walk(SRC), ...walk(join(ROOT, 'probes')), ...walk(join(ROOT, 'tests')), join(ROOT, 'package.json')]) {
  const text = readFileSync(file, 'utf8');
  if (text.includes('\uFFFD')) fail(`${file}: contains U+FFFD`);
  if (MOJIBAKE.test(text)) fail(`${file}: contains mojibake`);
  if (file.endsWith('.mjs') && /\u2014\S/.test(text)) fail(`${file}: em-dash without a following space`);
}
if (failures === 0) ok('encoding clean');

console.log(failures === 0 ? '\nsanity: PASS' : `\nsanity: ${failures} failure(s)`);
process.exitCode = failures === 0 ? 0 : 1;
