/**
 * Fixture builder.
 *
 * Creates a small but complete harness home under `tests/fixtures/env`: a
 * profile whose bundles compose a handful of purpose-built plugins, and a set
 * of agent presets covering every failure the plan exists to catch.
 *
 * Every fixture is deliberately broken in exactly one way, so a test can assert
 * that this specific break produces this specific verdict.
 *
 * Run directly to (re)generate the tree: `node tests/fixtures/build.mjs`
 */

import { mkdirSync, writeFileSync, rmSync } from 'node:fs';
import { join, dirname } from 'node:path';
import { fileURLToPath } from 'node:url';

const HERE = dirname(fileURLToPath(import.meta.url));
export const ENV = join(HERE, 'env');

/** Write a file, creating its directory. */
function put(relative, content) {
  const path = join(ENV, relative);
  mkdirSync(dirname(path), { recursive: true });
  writeFileSync(path, content, 'utf8');
}

/** A `package.json` with sensible defaults. */
function manifest(name, extra = {}) {
  return `${JSON.stringify({
    name,
    version: '1.0.0',
    type: 'module',
    main: 'lib/index.js',
    exports: { '.': './lib/index.js', './package.json': './package.json' },
    ...extra,
  }, null, 2)}\n`;
}

export function build() {
  rmSync(ENV, { recursive: true, force: true });

  // ── The installation anchor ───────────────────────────────────────────────
  // Its only job is to exist so `locateInstall` finds a `@deepseek-ai/dsh`.
  put('node_modules/@deepseek-ai/dsh/package.json', `${JSON.stringify({
    name: '@deepseek-ai/dsh',
    version: '9.9.9-fixture',
    type: 'module',
    bin: { dsh: 'lib/bin.js' },
  }, null, 2)}\n`);
  put('node_modules/@deepseek-ai/dsh/lib/bin.js', 'process.stdout.write("9.9.9-fixture\\n");\n');

  // A stub of the real tools package, so a fixture plugin's `import { defineTool }`
  // resolves and the mount probe exercises the plugin rather than the fixture.
  put('node_modules/@deepseek-ai/dsh-tools/package.json', manifest('@deepseek-ai/dsh-tools', {
    exports: { '.': './lib/index.js', './package.json': './package.json' },
  }));
  put('node_modules/@deepseek-ai/dsh-tools/lib/index.js', `export function defineTool(spec) { return spec; }
`);

  // A base bundle that contributes rows, one of them platform-gated. The
  // `agent-presets` row is what names the default mode, exactly as the shipped
  // web-app bundle does.
  put('node_modules/@deepseek-ai/dsh-base/package.json', manifest('@deepseek-ai/dsh-base', {
    dsh: { bundle: { patch: 'cordis.patch.yml' } },
  }));
  put('node_modules/@deepseek-ai/dsh-base/cordis.patch.yml', `# Fixture base bundle.
- insert:
    - id: tools
      name: '@deepseek-ai/dsh-tools'
    - id: platform-only
      name: '@deepseek-ai/dsh-tool-bash'
      disabled: !!js process.platform === 'win32'
    - id: agent-presets
      name: '@deepseek-ai/dsh-agent-presets'
      config:
        default: default-mode
`);

  // ── acme-tools: a healthy third-party plugin ──────────────────────────────
  put('node_modules/acme-tools/package.json', manifest('acme-tools', {
    dsh: { bundle: { patch: 'cordis.patch.yml' } },
  }));
  put('node_modules/acme-tools/cordis.patch.yml', `- insert:
    - id: acme-tools
      name: acme-tools
`);
  put('node_modules/acme-tools/lib/index.js', `import { defineTool } from '@deepseek-ai/dsh-tools';

export const name = 'acme-tools';
export const inject = ['tools', 'systemPrompt'];

export function apply(ctx, config) {
  ctx.inject(['tools'], (sctx) => {
    sctx.effect(() => sctx.tools.register(defineTool({
      name: 'acme_echo',
      description: 'Echo a string back.',
      parameters: { text: { type: 'string', description: 'what to echo' } },
    })));
    sctx.effect(() => sctx.tools.register(defineTool({
      name: 'acme_sum',
      description: 'Add two numbers.',
      parameters: {
        a: { type: 'number', description: 'first' },
        b: { type: 'number', description: 'second' },
      },
    })));
  });
  ctx.inject(['systemPrompt'], (sctx) => {
    sctx.effect(() => sctx.systemPrompt.section({
      name: 'acme:guidance',
      order: 400,
      text: 'Prefer acme_echo for trivial round-trips.',
    }));
  });
}
`);

  // ── acme-sideeffect: registers nothing at all ─────────────────────────────
  // The plan's terminal case: mount success is the entire contract.
  put('node_modules/acme-sideeffect/package.json', manifest('acme-sideeffect', {
    dsh: { bundle: { patch: 'cordis.patch.yml' } },
  }));
  put('node_modules/acme-sideeffect/cordis.patch.yml', `- insert:
    - id: acme-sideeffect
      name: acme-sideeffect
`);
  put('node_modules/acme-sideeffect/lib/index.js', `export const name = 'acme-sideeffect';

export function apply(ctx, config) {
  // Warms a cache and registers nothing the harness can name.
  const warm = new Map();
  warm.set('ready', true);
}
`);

  // ── acme-broken: throws during import ─────────────────────────────────────
  // Detected only by the sandbox mount probe; a static run must call it UNKNOWN.
  put('node_modules/acme-broken/package.json', manifest('acme-broken', {
    dsh: { bundle: { patch: 'cordis.patch.yml' } },
  }));
  put('node_modules/acme-broken/cordis.patch.yml', `- insert:
    - id: acme-broken
      name: acme-broken
`);
  put('node_modules/acme-broken/lib/index.js', `export const name = 'acme-broken';

throw new Error('acme-broken: this plugin cannot be loaded (fixture)');

export function apply(ctx, config) {}
`);

  // ── acme-dupe: declares a tool acme-tools already owns ────────────────────
  put('node_modules/acme-dupe/package.json', manifest('acme-dupe', {
    dsh: { bundle: { patch: 'cordis.patch.yml' } },
  }));
  put('node_modules/acme-dupe/cordis.patch.yml', `- insert:
    - id: acme-dupe
      name: acme-dupe
`);
  put('node_modules/acme-dupe/lib/index.js', `import { defineTool } from '@deepseek-ai/dsh-tools';

export const name = 'acme-dupe';
export const inject = ['tools'];

export function apply(ctx, config) {
  ctx.inject(['tools'], (sctx) => {
    sctx.effect(() => sctx.tools.register(defineTool({
      name: 'acme_echo',
      description: 'A second echo, colliding with acme-tools.',
      parameters: { text: { type: 'string', description: 'what to echo' } },
    })));
  });
}
`);

  // ── acme-provider: publishes a capability the config refers to ────────────
  put('node_modules/acme-provider/package.json', manifest('acme-provider', {
    dsh: { bundle: { patch: 'cordis.patch.yml' } },
  }));
  put('node_modules/acme-provider/cordis.patch.yml', `- insert:
    - id: acme-provider
      name: acme-provider
`);
  put('node_modules/acme-provider/lib/index.js', `import { AcmeProvider } from './provider.js';

export const name = 'acme-provider';
export const inject = ['web'];

export function apply(ctx, config) {
  ctx.web.registerSearchProvider(new AcmeProvider());
}
`);
  put('node_modules/acme-provider/lib/provider.js', `export class AcmeProvider {
  id = 'acme-search';
  async search(request) { return { sources: [] }; }
}
`);

  // ── The profile ───────────────────────────────────────────────────────────
  put('profiles/web/package.json', `${JSON.stringify({
    name: 'dsh-profile-web',
    private: true,
    dsh: {
      profile: {
        bundles: ['@deepseek-ai/dsh-base', 'acme-tools', 'acme-sideeffect', 'acme-broken', 'acme-dupe', 'acme-provider'],
      },
    },
  }, null, 2)}\n`);

  // The user layer points `web.searchProvider` at a capability acme-provider
  // publishes — and, at a second key, at one nothing publishes.
  put('profiles/web/cordis.patch.yml', `# Fixture user layer.
- id: web
  config:
    searchProvider: acme-search
    fetchProvider: nobody-publishes-this

- id: acme-tools
  config:
    verbose: true
`);

  // ── Agent presets (modes) ─────────────────────────────────────────────────
  // good: a well-formed, distinct mode.
  put('.agent-presets/good/preset.yml', 'name: Good Mode\ndescription: A well-formed fixture preset.\norder: 10\n');
  put('.agent-presets/good/agent.cordis.yml', `# Fixture preset: distinct from the default.
- id: persona
  name: acme-tools
- id: extra
  name: acme-provider
`);

  // twin: byte-identical composition to the *default* mode, so the L4 diff finds
  // no change at all and the mode is correctly judged not to be a mode.
  put('.agent-presets/twin/preset.yml', 'name: Twin Mode\ndescription: Composition identical to the default mode.\n');
  put('.agent-presets/twin/agent.cordis.yml', `# Fixture preset: identical to default-mode, so switching changes nothing.
- id: persona
  name: acme-sideeffect
`);

  // no-comp: a directory occupying an id with no composition file.
  put('.agent-presets/no-comp/preset.yml', 'name: No Composition\n');

  // bad-yaml: the composition does not parse.
  put('.agent-presets/bad-yaml/agent.cordis.yml', '- id: persona\n  name: acme-tools\n   broken: indentation\n');

  // unresolvable: names a package nothing installed.
  put('.agent-presets/unresolvable/preset.yml', 'name: Unresolvable\n');
  put('.agent-presets/unresolvable/agent.cordis.yml', `- id: persona
  name: acme-tools
- id: ghost
  name: totally-absent-package
`);

  // Bad_Id: the directory name is not a valid preset id, so DSH skips it.
  put('.agent-presets/Bad_Id/agent.cordis.yml', '- id: persona\n  name: acme-tools\n');
  put('.agent-presets/Bad_Id/preset.yml', 'name: Unreachable\n');

  // shadow-tools: exists in the user root, but the shipped root claims the id.
  put('node_modules/@deepseek-ai/dsh-agent-presets/presets/shadow-tools/preset.yml', 'name: Shipped Shadow\n');
  put('node_modules/@deepseek-ai/dsh-agent-presets/presets/shadow-tools/agent.cordis.yml', '- id: persona\n  name: acme-tools\n');
  put('.agent-presets/shadow-tools/preset.yml', 'name: Shadowed User Preset\n');
  put('.agent-presets/shadow-tools/agent.cordis.yml', '- id: persona\n  name: acme-sideeffect\n');

  // default: the deployment default the L4 diff compares against.
  put('node_modules/@deepseek-ai/dsh-agent-presets/presets/default-mode/preset.yml', 'name: Default Mode\n');
  put('node_modules/@deepseek-ai/dsh-agent-presets/presets/default-mode/agent.cordis.yml', '- id: persona\n  name: acme-sideeffect\n');

  return ENV;
}

if (import.meta.url === `file://${process.argv[1]?.replace(/\\/g, '/')}` || process.argv[1]?.endsWith('build.mjs')) {
  const dir = build();
  process.stdout.write(`fixtures written to ${dir}\n`);
}
